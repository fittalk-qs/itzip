// 에디터 만들기:  node build.js   → public/index.html  (+ cloudflare/worker.js 도 같이 다시 만듦)
//
// 고치는 곳은 src/ 예요. public/index.html 은 이걸로 만든 결과라 직접 고치지 마세요.
//   src/editor.html          에디터 화면 (HTML·CSS)
//   src/editor.js            에디터 동작 (스크립트) — 닫는 script 태그는 '<\/script>' 로 써야 함
//   src/template/            만들어지는 분양 사이트의 틀. zip 안에 그대로 들어가는 css/js/fonts
//                            (에디터 안에 통째로 넣어 두고 미리보기·zip 만들기에 씀)
//   src/vendor/jszip.min.js  zip 만들기 라이브러리 (JSZip 3.10.1, 손대지 않음)
//
// 만든 public/index.html 은 사내 서버가 그대로 보여 주고, 마법도구(깃허브 Pages)엔 landing-editor.html 로 이름만 바꿔 올려요.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const R = (...p) => path.join(__dirname, ...p);
const text = (p) => fs.readFileSync(R(p), 'utf8').replace(/\r\n/g, '\n');   // 윈도우에서 줄바꿈이 바뀌어도 똑같이
const listFiles = (dir) => fs.readdirSync(R(dir), { withFileTypes: true })
  .flatMap((e) => (e.isDirectory() ? listFiles(dir + '/' + e.name) : [dir + '/' + e.name]));

// 사이트 틀 → window.TEMPLATE (글꼴은 base64, 경로 이름순)
const T = {
  css: text('src/template/css/landing-style.css'),
  js: text('src/template/js/main.js'),
  pretendardCss: text('src/template/css/pretendard.css'),
  fonts: {}
};
listFiles('src/template/fonts').filter((f) => /\.woff2$/i.test(f)).map((f) => f.slice('src/template/'.length)).sort()
  .forEach((p) => { T.fonts[p] = fs.readFileSync(R('src/template', p)).toString('base64'); });
// 스톡 사진 (메인 원페이지 자동 구성·대지 '스톡에서 고르기'): 파일 이름 = 주제_설명_번호.jpg
T.stock = fs.existsSync(R('src/template/stock')) ? listFiles('src/template/stock').filter((f) => /\.jpe?g$/i.test(f)).sort()
  .map((f) => ({ f: path.basename(f), d: fs.readFileSync(R(f)).toString('base64') })) : [];
// 팀 피그마에서 뽑은 아이콘 (커뮤니티 시설 · 사업개요 항목): 이름 → SVG
T.icons = fs.existsSync(R('src/template/icons.json')) ? JSON.parse(fs.readFileSync(R('src/template/icons.json'), 'utf8')) : {};
// 히어로 배지 메달 바탕 (팀 피그마 00_hero_m, 글자 뺀 것)
T.medal = fs.existsSync(R('src/template/medal.png')) ? fs.readFileSync(R('src/template/medal.png')).toString('base64') : '';

const editorJs = text('src/editor.js'), jszip = text('src/vendor/jszip.min.js').replace(/\n$/, '');
// 스크립트 안에 </script 가 그대로 있으면 HTML이 거기서 끊겨 버림
[['src/editor.js', editorJs], ['src/vendor/jszip.min.js', jszip]].forEach(([name, s]) => {
  if (/<\/script/i.test(s)) throw new Error(name + ' 안에 </script 가 있어요. <\\/script> 로 바꿔 주세요');
});
// 문법 오류는 미리 잡기 (에디터·사이트 스크립트)
[['src/editor.js', editorJs], ['src/template/js/main.js', T.js]].forEach(([name, s]) => {
  try { new vm.Script(s, { filename: name }); } catch (e) { throw new Error(name + ' 문법 오류: ' + e.message); }
});

const html = text('src/editor.html') +
  '<script>' + jszip + '</script>\n' +
  '<script>window.TEMPLATE = ' + JSON.stringify(T).replace(/<\//g, '<\\/') + ';</script>\n' +   // </ 는 전부 <\/ 로 (HTML이 끊기지 않게)
  '<script>' + editorJs + '</script>\n</body>\n</html>\n';
fs.writeFileSync(R('public/index.html'), html);
console.log('public/index.html 만들었어요 (' + (Buffer.byteLength(html) / 1048576).toFixed(2) + 'MB · 글꼴 ' + Object.keys(T.fonts).length + '개)');

// 홈페이지 가져오기 Worker 도 같이 (site-import-core.js 를 고쳤을 수 있으니)
require('./cloudflare/make-worker.js');
