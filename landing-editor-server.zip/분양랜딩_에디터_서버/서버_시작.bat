@echo off
chcp 65001 > nul
title Bunyang Landing Editor Server - keep this window open
rem pushd: works even when opened from a network path (\\FITTALKMAIN\...)
pushd "%~dp0"
rem node: the installed one, otherwise a portable copy in %LOCALAPPDATA%\Programs\node-*
set "NODE=node"
where node > nul 2> nul
if errorlevel 1 (
  set "NODE="
  for /d %%D in ("%LOCALAPPDATA%\Programs\node-*") do if exist "%%D\node.exe" set "NODE=%%D\node.exe"
)
if not defined NODE (
  echo.
  echo [!] Node.js is not installed. Install the LTS version from https://nodejs.org and run this again.
  echo.
  pause
  exit /b 1
)
set PORT=8080
"%NODE%" server.js
popd
pause
