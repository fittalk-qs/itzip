@echo off
chcp 65001 > nul
cd /d "%~dp0"
set PORT=8080
node server.js
pause
