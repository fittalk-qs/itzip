@echo off
chcp 65001 > nul
title Bunyang Landing Editor Server - keep this window open
rem pushd: works even when opened from a network path (\\FITTALKMAIN\...)
pushd "%~dp0"
where node > nul 2> nul
if errorlevel 1 (
  echo.
  echo [!] Node.js is not installed. Install the LTS version from https://nodejs.org and run this again.
  echo.
  pause
  exit /b 1
)
set PORT=8080
node server.js
popd
pause
