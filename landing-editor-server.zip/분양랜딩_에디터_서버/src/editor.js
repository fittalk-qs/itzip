/* 분양 랜딩 에디터
   - 이미지 올리기(파일명 자동 분류) → 섹션·순서·기본 정보 편집 → 미리보기 → zip 내보내기
   - 만든 zip(또는 예전에 손으로 만든 zip)을 다시 불러와 수정할 수 있음
   주의: 이 파일은 editor.html의 <script> 안에 그대로 들어가므로 닫는 script 태그 문자열은 '<\/script>'로 씀 */
(function () {
  'use strict';

  var T = window.TEMPLATE;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var br = function (s) { return esc(s).replace(/\r?\n/g, '<br>'); };
  var natural = function (a, b) { return a.localeCompare(b, 'ko', { numeric: true, sensitivity: 'base' }); };
  var uidN = 0;
  var uid = function () { return 'i' + (++uidN); };
  var pad2 = function (n) { return String(n).padStart(2, '0'); };

  var DEFAULT_DISC = [
    '※본 사이트에 사용된 이미지 및 내용, 문구 등은 소비자의 이해를 돕기 위해 제작 또는 표기된 것으로 실제와 차이가 있습니다.',
    '※본 사이트 상의 개발 및 교통계획에 대한 사항은 추후 관계기관의 사정에 따라 변경 및 취소될 수 있으며, 이는 당사와 무관함을 알려드립니다.',
    '※본 사이트의 내용은 사업주체 및 관계기관의 사정에 따라 변경될 수 있습니다.',
    '※본 사이트는 편집 및 인쇄과정에서 오류 및 오타가 있을 수 있습니다.',
    '※상기 내용 및 이미지는 소비자의 이해를 돕기 위한 것으로 실제와 다를 수 있습니다.'
  ].join('\n');

  // 개인정보 동의문 기본값 (핏톡). 폼의 '내용보기'에 나오는 글. 에디터에서 고칠 수 있음
  var DEFAULT_PRIVACY = [
    '■ 개인정보 수집, 이용, 위탁, 양도 동의',
    '',
    '㈜핏톡은 고객님의 원활한 서비스 이용을 위해 필요한 최소한의 개인정보를 수집하고 있습니다.',
    '',
    '- 개인정보 제공받는 자 : ㈜핏톡',
    '- 직방, 호갱노노는 고객님의 개인정보를 수집하거나 분양상담에 직접 관여하지 않습니다. 제공되는 부동산 정보는 각 콘텐츠 제공업체로부터 받는 정보로 참고용입니다. 정보의 정확성이나 신뢰성을 보증하지 않으며, 서비스 이용의 결과에 대해서 어떠한 법적인 책임을 지지 않습니다.',
    '- 고객님은 개인정보 수집에 동의하지 않을 권리가 있습니다. 다만, 필수 항목에 대한 동의를 거부하실 경우 관심고객 등록이 불가능합니다.',
    '',
    '1. 수집하는 개인정보 항목',
    '관심고객 등록을 통해 다음과 같은 개인정보를 수집합니다.',
    '',
    '- 개인정보 제공 필수 항목 : 이름, 휴대전화번호',
    '- 개인정보 제공 선택 항목 : 주소 (시/도, 시/군/구), 관심 타입, 연령대',
    '',
    '2. 개인정보의 수집 및 이용 목적',
    '수집된 개인정보는 다음의 목적으로 이용됩니다.',
    '',
    '- 이름, 휴대전화번호 : 분양 정보 안내, 상담, 고지사항 전달, 불만 처리, 이벤트 정보 제공',
    '- 관심 타입: 맞춤형 정보 제공',
    '- 연령대: 통계 분석 및 맞춤형 서비스 제공',
    '',
    '3. 개인정보의 보유 및 이용 기간',
    '수집된 개인정보는 원칙적으로 관심고객 등록 시점부터 분양 완료 시까지 보유 및 이용합니다. 단, 마케팅 활용 동의 시에는 별도의 보유 기간을 따릅니다.',
    '',
    '- 파기 절차: 분양 완료 후 별도 DB로 이관하여 일정 기간 보관 후 파기',
    '- 파기 방법: 전자적 파일 형태의 정보는 복구 불가능한 기술적 방법을 사용하여 영구 삭제하며, 종이 문서 형태의 정보는 분쇄하거나 소각합니다.'
  ].join('\n');
  var DEFAULT_THIRD = [
    '주식회사 핏톡(이하 \'회사\')은 「개인정보 보호법」 제17조에 따라 아래와 같이 개인정보를 제3자에게 제공하고자 합니다.',
    '',
    '1. 제공받는 자',
    '- 주식회사 핏톡(FITTALK) 및 해당 분양 현장의 분양대행사',
    '',
    '2. 제공받는 자의 이용 목적',
    '- 분양 상담 진행, 방문 예약 안내, 청약 및 분양 관련 정보 제공',
    '',
    '3. 제공하는 개인정보 항목',
    '- 이름, 휴대전화번호, 문의 내용',
    '',
    '4. 제공받는 자의 보유 및 이용 기간',
    '- 제공일로부터 6개월 또는 상담 종료 시까지'
  ].join('\n');

  // 파일명 자동 분류 → 섹션
  var SECTION_DEFS = {
    event: { label: '이벤트', order: 1.5 },   // 이벤트 배너도 그냥 섹션 (폼 바로 아래)
    intro: { label: '분양안내', order: 2 },
    interior: { label: '인테리어', order: 3 },
    premium: { label: '프리미엄', order: 4 },
    location: { label: '입지환경', order: 5 },
    community: { label: '커뮤니티', order: 6 },
    siteplan: { label: '단지배치', order: 7 },
    etc: { label: '기타', order: 90 },
    video: { label: '홍보영상', order: 97 },
    text: { label: '안내 문구', order: 96 },
    types: { label: '타입안내', order: 98 },
    summary: { label: '사업개요', order: 99 },
    news: { label: '뉴스', order: 99.5 }        // 뉴스·보도자료: 슬라이드, 맨 앞(00) 이미지는 제목
  };

  /* =========================================================
     상태
     ========================================================= */
  var state;
  function freshState() {
    var st = {
      siteName: '', heroTitle: '', titleAuto: true, heroSub: '', phone: '',
      brand: '#001241', brandTouched: false, folder: 'landing_m',
      badgeAlt: '', disclaimers: DEFAULT_DISC,
      privacyText: DEFAULT_PRIVACY, thirdPartyText: DEFAULT_THIRD,   // 개인정보 수집·이용 / 제3자 제공 동의문 (폼 '내용보기')
      onBrandMode: 'auto', onBrandCustom: '#ffffff',     // 메인 색 위 글씨 색
      logoW: 128, logoWTouched: false,
      introMode: 'none',     // 인트로: none(기본) | both(로고+현장명) | logo | text
      titleSize: 42, titleTop: 12.4, subSize: 17, subTop: 6.7, badgeW: 89.3, badgeTop: 32.4,   // 글씨 크기는 375px 휴대폰 기준
      logo: null, heroBg: null, badge: null,
      heroFl: [],            // 히어로 자유 레이어 (대지에서 놓은 글·사각형·이미지). 섹션은 s.fl
      heroLayers: [],        // 히어로에 더 얹는 것: {kind:'image', image, w, top} | {kind:'text', text, font, bold, size, top, color}
      sections: [formItem(), formItem(false, '방문예약', 'reserve-2', 999)], // 기본 폼 2개: 히어로 밑 + 맨 밑 (맨 밑 폼은 메뉴에 안 나옴) {id, key, label, nav, kind:'images'|'form', order, mode:'stack'|'slide', tabs, header, images[], band, autoBand}
      contactHero: true,         // 방문예약 페이지: 폼 아래 히어로
      contactFormBottom: false,  // 방문예약 페이지 맨 아래에도 폼 하나 더
      // 섹션마다 where: 'main' | 'both' | 'contact' (비어 있으면 자동: 첫 메뉴 섹션만 둘 다)
      siteMode: 'single',        // 방식: single(모바일형) | menu(모바일+메뉴형) | pc(PC 최적화: 메뉴형 + 홈·방문예약도 PC에서 넓게)
      heroBgPc: null,            // PC 최적화: PC용 히어로 배경 (가로 이미지)
      menus: [],                 // 대메뉴: {id, name, slug, sections[], children:[{id, name, slug, sections[]}]} (소메뉴가 있으면 대메뉴는 페이지 없음)
      menuContact: true,         // 메뉴 줄 맨 끝 '방문예약'
      pageTitle: true,           // 메뉴 페이지 맨 위 제목
      pageForm: false,           // 메뉴 페이지 맨 밑 방문예약 폼 (기본 해제)
      editing: 'main'            // 4번 섹션 칸이 고치는 페이지 (main 또는 메뉴 페이지 id)
    };
    st.mainSections = st.sections;   // sections = 지금 고치는 목록, mainSections = 메인 원페이지 목록
    return st;
  }
  // 방문예약 폼도 섹션 목록의 한 칸 (끌어서 위치 이동, 메뉴 번호도 그 자리 순서대로)
  // 리드요 폼은 한 페이지에 여러 개 넣을 수 있음 → 폼 칸도 여러 개 가능 (최소 1개)
  function formItem(nav, label, id, order) { return { id: id || 'reserve', key: 'form', label: label || '방문예약', nav: nav !== false, kind: 'form', order: order || 1 }; }
  // 버튼으로 새로 넣는 칸: 맨 끝이 폼이면(맨 밑 방문예약) 그 바로 위에, 아니면 맨 끝에
  function pushSection(sec) {
    var L = state.sections, last = L[L.length - 1];
    if (last && last.kind === 'form' && L.length > 1) L.splice(L.length - 1, 0, sec); else L.push(sec);
    return sec;
  }
  function formId() {
    var id = 'reserve', n = 2;
    while (state.sections.some(function (s) { return s.id === id; })) id = 'reserve-' + (n++);
    return id;
  }
  function formsOf(list) { return list.filter(function (s) { return s.kind === 'form'; }); }
  // 페이지에 들어가는 폼 id: 위에서부터 reserve, reserve-2, reserve-3 …
  function formOutId(k) { return k ? 'reserve-' + (k + 1) : 'reserve'; }
  function newLayer(kind, o) {
    var base = kind === 'image' ? { kind: 'image', image: null, w: 60, top: 55 }
      : { kind: 'text', text: '', font: 'pretendard', bold: true, size: 20, top: 55, color: '#ffffff' };
    return Object.assign(base, o || {});
  }
  var LAYER_FONTS = [['pretendard', '프리텐다드'], ['maru', '마루부리'], ['gmarket', 'G마켓 산스']];
  var LAYER_COLORS = [['#ffffff', '흰색'], ['#1a1a1a', '검정'], ['brand', '메인색']];
  var HERO_DEFAULTS = { titleSize: 42, titleTop: 12.4, subSize: 17, subTop: 6.7, badgeW: 89.3, badgeTop: 32.4 };
  var RANGES = { logoW: 'px', titleSize: 'px', titleTop: '%', subSize: 'px', subTop: '%', badgeW: '%', badgeTop: '%' };
  // 페이지에 실제로 들어가는 섹션인지 (이미지·타입이 있어야 함, 폼은 따로)
  function isMenuMode() { return state.siteMode === 'menu' || state.siteMode === 'pc'; }
  function isPcMode() { return state.siteMode === 'pc'; }
  // 섹션에 'PC 이미지'를 따로 쓸 수 있는 곳: PC 최적화는 모든 페이지, 모바일+메뉴형은 메뉴 페이지만 (sub = 메뉴 페이지)
  function pcSplitOk(sub) { return isPcMode() || (isMenuMode() && !!sub); }
  var renderSub = false;   // renderPage가 지금 메뉴 페이지를 만드는 중인지 (섹션 HTML에서 씀)
  function MAIN() { return state.mainSections || state.sections; }
  // 메뉴 페이지 목록: 소메뉴가 있으면 소메뉴들, 없으면 대메뉴 자신
  function menuPages() {
    var out = [];
    (state.menus || []).forEach(function (m) {
      if (m.children && m.children.length) m.children.forEach(function (c) { out.push({ page: c, parent: m }); });
      else out.push({ page: m, parent: null });
    });
    return out;
  }
  function findPage(id) { var f = menuPages().find(function (x) { return x.page.id === id; }); return f ? f.page : null; }
  function pageBySlug(slug) { return menuPages().find(function (x) { return x.page.slug === slug; }) || null; }
  function allLists() { return [MAIN()].concat(menuPages().map(function (x) { return x.page.sections || []; })); }
  function allSecs() { return [].concat.apply([], allLists()); }
  var RESERVED_SLUG = ['contact', 'img', 'css', 'js', 'fonts', 'video'];
  var SLUG_WORDS = [[/사업|개요/, 'summary'], [/입지|위치|교통/, 'location'], [/프리미엄/, 'premium'], [/동.?호/, 'unit'], [/단지|배치/, 'siteplan'],
    [/커뮤니티/, 'community'], [/평면|타입/, 'type'], [/인테리어|유니트|유닛/, 'interior'], [/모델하우스|홍보관|오시는/, 'gallery'], [/브랜드/, 'brand'], [/분양|일정/, 'info'], [/이벤트/, 'event']];
  function cleanSlug(v) { return String(v || '').toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30); }
  function autoSlug(name) { for (var i = 0; i < SLUG_WORDS.length; i++) if (SLUG_WORDS[i][0].test(name)) return SLUG_WORDS[i][1]; return 'page'; }
  function uniqueSlug(base, self) {
    var used = {};
    menuPages().forEach(function (x) { if (x.page !== self && x.page.slug) used[x.page.slug] = 1; });
    var sl = cleanSlug(base) || 'page';
    if (RESERVED_SLUG.indexOf(sl) >= 0) sl += '-page';
    var b = sl, n = 2;
    while (used[sl]) sl = b + (n++);
    return sl;
  }
  function newPid() { return 'pg' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function newMenuPage(name) { return { id: newPid(), name: name || '새 메뉴', slug: '', slugAuto: true, sections: [] }; }
  function setAutoSlug(p) { p.slug = uniqueSlug(autoSlug(p.name), p); }
  // 처음 메뉴 페이지로 바꿀 때 시작용 메뉴 (두산위브 부천 구조)
  function starterMenus() {
    state.menus = [];
    var page = function (name) { var p = newMenuPage(name); state.menus.push(p); setAutoSlug(p); return p; };
    var group = function (name, kids) {
      var g = newMenuPage(name); g.slug = ''; g.children = []; state.menus.push(g);
      kids.forEach(function (n) { var c = newMenuPage(n); g.children.push(c); setAutoSlug(c); });
    };
    page('사업안내'); group('입지안내', ['입지환경', '프리미엄']); group('단지안내', ['단지배치도', '커뮤니티']); page('평면안내');
  }
  // 4번 섹션 칸이 고칠 페이지 바꾸기 (sections를 그 페이지 목록으로 갈아 끼움)
  function relinkEditing() {
    var p = state.editing && state.editing !== 'main' ? findPage(state.editing) : null;
    if (!p) state.editing = 'main';
    if (p && !p.sections) p.sections = [];
    state.sections = p ? p.sections : state.mainSections;
  }
  // 섹션 묶음: join이면 바로 앞 섹션에 이어지는 내용. 이름·메뉴 번호·보이는 페이지는 묶음 맨 앞(머리) 하나
  function fixJoins(L) { L.forEach(function (x, i) { if (x.join && (i === 0 || x.kind === 'form' || L[i - 1].kind === 'form')) x.join = false; if (x.join) x.nav = false; }); }
  function headOf(L, x) { var i = L.indexOf(x); while (i > 0 && L[i].join) i--; return i < 0 ? x : L[i]; }
  function groupOf(L, x) { var h = headOf(L, x), i = L.indexOf(h), out = [h]; if (i < 0) return out; while (L[i + out.length] && L[i + out.length].join) out.push(L[i + out.length]); return out; }
  function groupFilled(L, h) { return groupOf(L, h).some(filled); }
  // 메뉴 링크가 가리킬 섹션: 묶음에서 내용 있는 첫 섹션 (머리가 비어 있어도 묶음에 내용이 있으면 메뉴에 나옴)
  function navTarget(L, x) { if (x.join || !x.nav) return null; var g = groupOf(L, x); for (var k = 0; k < g.length; k++) if (filled(g[k])) return g[k]; return null; }
  // 묶음 순서를 바꾼 뒤: 맨 앞이 머리(이름·메뉴·보이는 곳), 나머지는 이어지는 내용
  function relead(g, nav, label, where) { g.forEach(function (x, k) { x.join = k > 0; x.nav = k ? false : nav; x.label = label; if (where) x.where = where; }); }
  function moveGroup(L, x, dir) {
    var g = groupOf(L, x), i = L.indexOf(g[0]), n = g.length, at;
    if (dir < 0) { if (i <= 0) return; at = L.indexOf(headOf(L, L[i - 1])); L.splice(i, n); }
    else { if (i + n >= L.length) return; var ng = groupOf(L, L[i + n]); L.splice(i, n); at = L.indexOf(ng[ng.length - 1]) + 1; }
    L.splice.apply(L, [at, 0].concat(g));
  }
  function filled(s) {
    if (s.kind === 'video') return s.vsrc === 'file' ? !!s.vfile : !!s.yt;
    if (s.kind === 'text') return (s.texts || []).some(function (t) { return String(t.text || '').trim(); });
    return s.kind === 'images' && (s.images.length > 0 || !!s.header);
  }
  // 유튜브 주소 → 영상 ID (youtu.be/…, watch?v=…, shorts/…, embed/…, live/…, ID만)
  function ytId(u) {
    u = String(u || '').trim();
    if (/^[A-Za-z0-9_-]{11}$/.test(u)) return u;
    var m = u.match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/|v\/))([A-Za-z0-9_-]{11})/);
    return m ? m[1] : '';
  }
  function newTextItem(o) {
    return Object.assign({ text: '', font: 'pretendard', bold: true, size: 22, color: '#1a1a1a', align: 'center', lh: 1.45, gap: 12 }, o || {});
  }
  function textSection(o) {
    return newSection(Object.assign({
      id: uniqueId('s-text'), kind: 'text', key: 'text', label: '안내 문구', nav: false, order: 96,
      texts: [newTextItem({ font: 'gmarket', size: 26 }), newTextItem({ bold: false, size: 15, color: '#555555', lh: 1.6 })],
      bg: '#ffffff', padY: 48
    }, o || {}));
  }
  var TX_COLORS = [['#1a1a1a', '검정'], ['#ffffff', '흰색'], ['brand', '메인색']];
  var TX_BGS = [['#ffffff', '흰색'], ['brand', '메인색'], ['#1a1a1a', '검정']];
  var TX_ALIGNS = [['left', '왼쪽'], ['center', '가운데'], ['right', '오른쪽']];
  function txColor(c) { return c === 'brand' ? 'var(--brand)' : (normHex(c) || '#1a1a1a'); }
  function videoSection(o) {
    return newSection(Object.assign({
      id: uniqueId('s-video'), kind: 'video', key: 'video', label: '홍보영상', nav: true, order: 97,
      vsrc: 'youtube', ytUrl: '', yt: '', ratio: '16:9', vfile: null, poster: null, posterAuto: true, autoplay: false
    }, o || {}));
  }
  function isVideoFile(f) { return /^video\//.test(f.type) || /\.(mp4|webm|mov|m4v|avi|mkv)$/i.test(f.name); }
  function videoType(name, t) { return /webm/i.test(t || '') || /\.webm$/i.test(name) ? 'video/webm' : 'video/mp4'; }
  // 영상 파일 읽기: 크기·길이 + 1초 장면을 표지로
  async function loadVideo(blob, name) {
    var type = videoType(name, blob.type), url = URL.createObjectURL(blob);
    var v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; v.playsInline = true; v.src = url;
    await new Promise(function (res, rej) { v.onloadedmetadata = res; v.onerror = function () { rej(new Error(name + ' 을(를) 읽지 못했어요 (mp4·webm만 돼요)')); }; });
    var file = { id: uid(), name: name, blob: blob, type: type, url: url, w: v.videoWidth || 1920, h: v.videoHeight || 1080, duration: v.duration || 0, size: blob.size };
    var poster = null;
    try {
      v.currentTime = Math.min(1, (isFinite(v.duration) && v.duration ? v.duration : 2) / 2);
      await new Promise(function (res) { v.onseeked = res; setTimeout(res, 4000); });
      var W = Math.min(1280, file.w), c = canvas(W, Math.round(W * file.h / file.w));
      c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
      poster = await loadImg(await toBlob(c, 'image/jpeg', 0.85), name.replace(/\.[^.]+$/, '') + '_poster.jpg');
    } catch (e) { poster = null; }
    v.removeAttribute('src'); v.load();
    return { file: file, poster: poster };
  }
  var mmss = function (sec) { sec = Math.round(sec || 0); return Math.floor(sec / 60) + ':' + pad2(sec % 60); };
  // 섹션이 들어가는 페이지: main(메인만) | both(둘 다) | contact(방문예약 페이지만)
  function whereOf(s) {
    if (s.kind === 'form') return 'main';
    if (s.where) return s.where;
    var first = MAIN().find(function (x) { return x.nav && filled(x); });
    return first === s ? 'both' : 'main';
  }
  function onPage(s, isC) { var w = whereOf(s); return isC ? w !== 'main' : w !== 'contact'; }
  // 처음 직접 고르는 순간 자동값을 전부 그대로 굳힘 (순서를 바꿔도 안 바뀌게)
  function freezeWhere() { MAIN().forEach(function (s) { if (s.kind !== 'form' && !s.where) s.where = whereOf(s); }); }
  // 슬라이드 화살표 위치용 위쪽 띠 높이 (0 = 띠 없음 → 화살표 가운데)
  function bandOf(s) { return s.band != null ? s.band : (s.autoBand || 0); }
  function onBrand() {
    var b = normHex(state.brand) || '#001241';
    if (state.onBrandMode === 'white') return '#ffffff';
    if (state.onBrandMode === 'dark') return '#1a1a1a';
    if (state.onBrandMode === 'custom') return normHex(state.onBrandCustom) || '#ffffff';
    return lum(b) < 150 ? '#ffffff' : '#1a1a1a';
  }
  function setLogo(l) {
    state.logo = l;
    if (l && !state.logoWTouched) { var a = l.w / l.h; state.logoW = a < 3 ? clamp(Math.round(46 * a), 60, 128) : 128; }
  }
  state = freshState();
  var pv = { device: 'mobile', page: 'main', intro: false, keepScroll: true, fit: true, zoom: 1, scrollSel: false };

  /* =========================================================
     색 계산
     ========================================================= */
  function normHex(v) {
    var m = String(v || '').trim().match(/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i);
    if (!m) return null;
    var h = m[1].length === 3 ? m[1].split('').map(function (c) { return c + c; }).join('') : m[1];
    return '#' + h.toLowerCase();
  }
  function hexRgb(hex) { var n = parseInt(hex.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function rgbHex(r, g, b) { return '#' + [r, g, b].map(function (v) { return Math.round(v).toString(16).padStart(2, '0'); }).join(''); }
  function lum(hex) { var c = hexRgb(hex); return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]; }
  function rgbHsl(c) {
    var r = c[0] / 255, g = c[1] / 255, b = c[2] / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, h = 0, s = 0;
    if (mx !== mn) {
      var d = mx - mn;
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
      h /= 6;
    }
    return [h, s, l];
  }
  function hslHex(h, s, l) {
    var f = function (p, q, t) {
      if (t < 0) t += 1; if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    if (s === 0) return rgbHex(l * 255, l * 255, l * 255);
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    return rgbHex(f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255);
  }
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

  /* =========================================================
     이미지 불러오기·분석
     ========================================================= */
  function mimeOf(name) {
    return /\.png$/i.test(name) ? 'image/png' : /\.webp$/i.test(name) ? 'image/webp' : /\.svg$/i.test(name) ? 'image/svg+xml' : 'image/jpeg';
  }
  function canvas(w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function toBlob(c, type, q) { return new Promise(function (res) { c.toBlob(res, type, q); }); }

  async function loadImg(blob, name) {
    var type = blob.type || mimeOf(name);
    var bmp = await createImageBitmap(blob);
    var c = canvas(1, 1), x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(bmp, Math.min(2, bmp.width - 1), Math.min(2, bmp.height - 1), 1, 1, 0, 0, 1, 1);
    var d = x.getImageData(0, 0, 1, 1).data;
    var im = {
      id: uid(), name: name, blob: blob, type: type, url: URL.createObjectURL(blob),
      w: bmp.width, h: bmp.height, bg: d[3] < 250 ? '#ffffff' : rgbHex(d[0], d[1], d[2]), alt: '',
      alpha: 0, trimAspect: bmp.width / bmp.height
    };
    // 투명 부분 비율과, 투명 여백을 뺀 실제 그림의 가로세로 비율 (로고·배지 자동 판별용)
    if (/png|webp/.test(type)) {
      var W = Math.min(240, bmp.width), H = Math.max(1, Math.round(bmp.height * W / bmp.width));
      var c2 = canvas(W, H), x2 = c2.getContext('2d', { willReadFrequently: true });
      x2.drawImage(bmp, 0, 0, W, H);
      var dd = x2.getImageData(0, 0, W, H).data, tr = 0, minX = W, minY = H, maxX = -1, maxY = -1;
      for (var py = 0; py < H; py++) for (var px = 0; px < W; px++) {
        if (dd[(py * W + px) * 4 + 3] < 128) tr++;
        else { if (px < minX) minX = px; if (px > maxX) maxX = px; if (py < minY) minY = py; if (py > maxY) maxY = py; }
      }
      im.alpha = tr / (W * H);
      if (maxX >= 0) im.trimAspect = (maxX - minX + 1) / (maxY - minY + 1);
    }
    bmp.close();
    return im;
  }

  // 로고: 투명 배경이 없으면 흰색을 지우고, 바깥 여백을 잘라 PNG로
  async function processLogo(blob, name) {
    var src, w, h;
    if ((blob.type || mimeOf(name)) === 'image/svg+xml') {
      var img = new Image();
      img.src = URL.createObjectURL(blob);
      await img.decode();
      var sc = Math.max(1, 720 / (img.naturalWidth || 360));
      w = Math.round((img.naturalWidth || 360) * sc); h = Math.round((img.naturalHeight || 80) * sc);
      src = img;
    } else {
      src = await createImageBitmap(blob); w = src.width; h = src.height;
    }
    var c = canvas(w, h), x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(src, 0, 0, w, h);
    var id = x.getImageData(0, 0, w, h), d = id.data, i, transparent = false;
    for (i = 3; i < d.length; i += 4) { if (d[i] < 250) { transparent = true; break; } }
    if (!transparent) {
      for (i = 0; i < d.length; i += 4) {
        var mn = Math.min(d[i], d[i + 1], d[i + 2]);
        if (mn > 238) d[i + 3] = 0;
        else if (mn > 200) d[i + 3] = Math.round(255 * (238 - mn) / 38);
      }
      x.putImageData(id, 0, 0);
    }
    var minX = w, minY = h, maxX = -1, maxY = -1, y, xx;
    for (y = 0; y < h; y++) for (xx = 0; xx < w; xx++) {
      if (d[(y * w + xx) * 4 + 3] > 10) { if (xx < minX) minX = xx; if (xx > maxX) maxX = xx; if (y < minY) minY = y; if (y > maxY) maxY = y; }
    }
    if (maxX < 0) { minX = 0; minY = 0; maxX = w - 1; maxY = h - 1; }
    var p = 2;
    minX = Math.max(0, minX - p); minY = Math.max(0, minY - p); maxX = Math.min(w - 1, maxX + p); maxY = Math.min(h - 1, maxY + p);
    var cw = maxX - minX + 1, ch = maxY - minY + 1, out = canvas(cw, ch);
    out.getContext('2d').drawImage(c, minX, minY, cw, ch, 0, 0, cw, ch);
    var png = await toBlob(out, 'image/png');
    return { id: 'logo', name: 'logo.png', blob: png, type: 'image/png', url: URL.createObjectURL(png), w: cw, h: ch, bg: '#ffffff', removedWhite: !transparent };
  }

  // 타입 이미지 위쪽 띠 높이 자동 감지 (가로 대비 비율). 띠 아래가 흰색으로 바뀌는 지점
  async function detectBand(im) {
    var bmp = await createImageBitmap(im.blob);
    var W = 200, H = Math.round(bmp.height * W / bmp.width);
    var c = canvas(W, H), x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(bmp, 0, 0, W, H); bmp.close();
    var d = x.getImageData(0, 0, W, H).data;
    var white = function (px, py) { var k = (py * W + px) * 4; return d[k] > 245 && d[k + 1] > 245 && d[k + 2] > 245; };
    for (var y = 1; y < Math.min(H - 3, W * 0.8); y++) {
      if (white(3, y) && white(3, y + 1) && white(3, y + 2) && white(W - 4, y) && white(W - 4, y + 1)) {
        return y < W * 0.05 ? null : y / W;
      }
    }
    return null;
  }

  /* =========================================================
     파일명 분류
     ========================================================= */
  function typeLabel(name) {
    var n = name.replace(/\.[a-z0-9]+$/i, '').replace(/\s*\(\d+\)$/, '').replace(/\s+\d+$/, '');
    var m = n.match(/(?:m_unit|unit|type)[_\- ]+(.+)$/i);
    return m ? m[1].replace(/_/g, ' ').trim().toUpperCase() : '';
  }
  function classify(name) {
    var n = name.toLowerCase();
    if (/logo|로고/.test(n)) return { role: 'logo' };
    if (/^00[_\- ]?hero|badge|배지/.test(n)) return { role: 'badge' };
    if (/이벤트|event|★/.test(n)) return { role: 'section', key: 'event' };
    if (/^01[_\- ]?hero|hero/.test(n)) return { role: 'heroBg' };
    if (/news|뉴스|보도|press/.test(n)) return { role: 'section', key: 'news' };
    var base = n.replace(/\.[a-z0-9]+$/, '').replace(/\s*\(\d+\)$/, ''), idx = /(?:^|[_\- ])(\d{1,2})$/.exec(base);
    if (/^98|type[_\- ]?m\b|type[_\- ]?guide|type[_\- ]?header|타입[_ ]?안내/.test(n) && !(idx && +idx[1] > 0 && idx.index > 0)) return { role: 'typeHeader' };
    if (/m_unit|unit[_\- ]|^type[_\- ]|^image \d+|평면/.test(n)) return { role: 'type', label: typeLabel(name) };
    var words = [[/intro|분양안내/, 'intro'], [/interior|인테리어/, 'interior'], [/premium|프리미엄/, 'premium'], [/location|입지/, 'location'],
      [/community|커뮤니티/, 'community'], [/siteplan|site[_\- ]?plan|단지배치/, 'siteplan'], [/(^|[^a-z])sum(mary)?(?![a-z])|overview|사업개요/, 'summary'], [/type|타입/, 'types']];
    var nums = [[/^02/, 'intro'], [/^03/, 'interior'], [/^04/, 'premium'], [/^05/, 'location'], [/^06/, 'community'], [/^0[78]/, 'siteplan'], [/^99/, 'summary']];
    for (var i = 0; i < words.length; i++) if (words[i][0].test(n)) return { role: 'section', key: words[i][1] };
    for (var j = 0; j < nums.length; j++) if (nums[j][0].test(n)) return { role: 'section', key: nums[j][1] };
    return { role: 'section', key: 'etc' };
  }
  // 이름으로 못 정했을 때: 이미지 모양으로 판별 (아직 빈 자리만 채움)
  function classifyByShape(im) {
    var ratio = im.h / im.w;
    if (im.alpha > 0.05 && im.trimAspect >= 3.5 && !state.logo) return { role: 'logo' };
    if (im.alpha > 0.05 && im.trimAspect >= 1.6 && !state.badge) return { role: 'badge' };
    if (im.alpha <= 0.05 && ratio >= 1.4 && ratio <= 1.8 && !state.heroBg) return { role: 'heroBg' };
    return null;
  }

  function uniqueId(base) {
    var id = base, n = 2;
    while (state.sections.some(function (s) { return s.id === id; }) || id === 's-top' || id === 'reserve') id = base + '-' + (n++);
    return id;
  }
  function insertByOrder(sec) {
    var i = state.sections.findIndex(function (s) { return (s.order == null ? 50 : s.order) > sec.order; });
    if (i < 0) state.sections.push(sec); else state.sections.splice(i, 0, sec);
  }
  function sectionFor(key, order) {
    var s = state.sections.find(function (x) { return x.kind === 'images' && x.key === key; });
    if (s) return s;
    var def = SECTION_DEFS[key] || SECTION_DEFS.etc;
    s = newSection({ key: key, label: def.label, nav: key !== 'etc' && key !== 'event', order: order != null ? order : def.order });
    insertByOrder(s);
    return s;
  }
  function newSection(o) {
    return Object.assign({
      id: uniqueId('s-' + (o.key || 'custom')), key: 'custom', label: '새 섹션', nav: true, kind: 'images', order: 90,
      mode: 'stack', tabs: false, header: null, images: [], band: null, autoBand: null
    }, o);
  }
  // 타입 평면도: 기본은 탭 있는 슬라이드 (섹션 칸에서 '세로로 쌓기'로 바꿀 수 있음)
  function typesSection() {
    var s = state.sections.find(function (x) { return x.kind === 'images' && x.key === 'types'; });
    if (s) return s;
    s = newSection({ id: uniqueId('s-type'), key: 'types', label: '타입안내', order: 98, mode: 'slide', tabs: true });
    insertByOrder(s);
    return s;
  }

  async function addFiles(fileList, opts) {
    opts = opts || {};
    var files = Array.prototype.slice.call(fileList);
    var zips = files.filter(function (f) { return /\.zip$/i.test(f.name); });
    if (zips.length) { await importZip(zips[0]); return; }
    var vids = opts.sec == null ? files.filter(isVideoFile) : [];
    files = files.filter(function (f) { return /^image\//.test(f.type) || /\.(png|jpe?g|webp)$/i.test(f.name); });
    if (vids.length) {
      vids.sort(function (a, b) { return natural(a.name, b.name); });
      var vAdded = 0;
      for (var vi = 0; vi < vids.length; vi++) {
        var vs = videoSection({ vsrc: 'file' });
        if (await setVideoFile(vs, vids[vi])) { insertByOrder(vs); vAdded++; }
      }
      if (vAdded && !files.length) { render(); toast('영상 ' + vAdded + '개를 영상 섹션으로 넣었어요. 왼쪽 목록에서 끌어서 위치를 옮길 수 있어요'); return; }
    }
    if (!files.length) { if (!vids.length) toast('이미지(PNG·JPG·WebP)나 영상(mp4·webm)만 올릴 수 있어요'); return; }
    files.sort(function (a, b) { return natural(a.name, b.name); });
    busy('이미지 읽는 중…');
    var added = 0, placed = [], before = new Set(state.sections);
    var ROLE_NAME = { logo: '로고', badge: '배지', heroBg: '히어로 배경' };
    try {
      for (var i = 0; i < files.length; i++) {
        var f = files[i];
        var im = await loadImg(f, f.name);
        added++;
        if (opts.sec != null) {
          var tgt = state.sections[opts.sec];
          im.label = typeLabel(f.name);
          tgt.images.push(im);
          continue;
        }
        var c = classify(f.name);
        if (c.role === 'section' && c.key === 'etc') c = classifyByShape(im) || c;
        if (ROLE_NAME[c.role]) placed.push(ROLE_NAME[c.role] + ' ← ' + f.name);
        if (c.role === 'logo') setLogo(await processLogo(f, f.name));
        else if (c.role === 'badge') state.badge = im;
        else if (c.role === 'heroBg') state.heroBg = im;
        else if (c.role === 'typeHeader') typesSection().header = im;
        else if (c.role === 'type') { im.label = c.label; typesSection().images.push(im); }
        else {
          var ts = sectionForFile(c.key, f.name);
          if (/(?:^|[_\- ])00$/.test(f.name.replace(/\.[a-z0-9]+$/i, '')) && !ts.header) ts.header = im;   // ..._00 = 그 섹션 제목 이미지
          else ts.images.push(im);
        }
      }
      // 새로 생긴 뉴스 섹션: 슬라이드(탭 없이). 00이 없으면 맨 앞 이미지가 납작하면(제목 띠) 제목으로
      state.sections.filter(function (s) { return !before.has(s) && s.key === 'news' && s.kind === 'images'; }).forEach(function (s) {
        if (!s.header && s.images.length > 2) {
          var r0 = s.images[0].h / s.images[0].w, rest = s.images.slice(1).map(function (im) { return im.h / im.w; }).sort(function (a, b) { return a - b; });
          if (r0 < rest[Math.floor(rest.length / 2)] * 0.75) s.header = s.images.shift();
        }
        if (s.images.length > 1) { s.mode = 'slide'; s.tabs = false; }
      });
    } finally { unbusy(); }
    afterImagesChanged();
    render();
    lastPlaced = placed;
    if (opts.sec == null) autoTitles();   // 이름이 기본값인 섹션은 이미지 제목 글자로 (뒤에서 조용히)
    toast(added + '장을 자리 잡았어요' + (placed.length ? ' (' + placed.map(function (p) { return p.split(' ←')[0]; }).join('·') + ' 포함)' : '') + '. 가운데 ' + (abOn() ? '대지' : '미리보기') + '에서 확인해 주세요.');
  }
  var lastPlaced = [];

  /* =========================================================
     메뉴 이름 자동
     - 파일 이름에 한글 이름이 있으면 그걸로 (04_교육환경_01.jpg → 교육환경). '기타'로 갈 이미지는 이름마다 따로 섹션
     - 이미지 제목 글자 읽기: 섹션 첫 이미지 위쪽에서 크게 쓴 한글 제목 줄을 읽음 (Tesseract.js)
       분양 사이트에 흔한 이름(TITLE_WORDS)은 한 글자 잘못 읽어도 고쳐 줌 (문양안내 → 분양안내)
       글자 읽기 도구는 처음 쓸 때 인터넷(jsdelivr)에서 한 번 받아요. 이미지는 이 컴퓨터 밖으로 안 나가요
     - 이미지를 올리면 이름이 기본값(분양안내·기타 …)인 섹션만 알아서 바꾸고, '이름 자동 채우기'는 고르는 창을 띄움
     ========================================================= */
  var NAME_SKIP = /^(이미지|사진|최종|최종본|수정|수정본|복사본|사본|섹션|페이지|랜딩|상세|모바일|메인|서브|배경|본문|원본|웹|타이틀|제목)$/;
  function fileTitle(name) {
    var n = name.replace(/\.[a-z0-9]+$/i, '').replace(/\s*\(\d+\)$/, ''), site = state.siteName.replace(/\s+/g, '');
    var toks = n.split(/[_\-\s.]+/).map(function (x) { return x.replace(/\d+$/, ''); }).filter(function (x) {
      var hg = (x.match(/[가-힣]/g) || []).length;
      return hg >= 2 && hg === x.length && !NAME_SKIP.test(x) && !(site && site.indexOf(x) >= 0);
    });
    var t = toks.find(function (x) { return TITLE_WORDS.indexOf(x) >= 0; }) || toks[0];   // 현장명_단지안내 → 단지안내
    return t ? t.slice(0, 12) : '';
  }
  var DEFAULT_LABELS = null;
  function isDefaultLabel(s) {
    if (!DEFAULT_LABELS) { DEFAULT_LABELS = ['섹션', '새 섹션', '기타']; Object.keys(SECTION_DEFS).forEach(function (k) { DEFAULT_LABELS.push(SECTION_DEFS[k].label); }); }
    return !s.label || DEFAULT_LABELS.indexOf(s.label) >= 0;
  }
  function fileOrder(name) { var m = /^(\d{1,2})(?=[_\-. ]|$)/.exec(name); return m && +m[1] >= 2 && +m[1] <= 99 ? +m[1] : null; }   // 06_sum → 6
  function sectionForFile(key, name) {
    var t = fileTitle(name);
    if (!t) return sectionFor(key, fileOrder(name));
    if (key === 'etc') {
      var s = state.sections.find(function (x) { return x.kind === 'images' && x.key === 'custom' && !x.join && x.label === t; });
      if (!s) {
        var m = /^(\d{1,2})(?!\d)/.exec(name), o = m && +m[1] >= 1 && +m[1] <= 95 ? +m[1] + 0.5 : 89;   // 앞 번호대로 자리 (없으면 기타 앞)
        s = newSection({ id: uniqueId('s-custom'), key: 'custom', label: t, nav: true, order: o });
        insertByOrder(s);
      }
      return s;
    }
    var sec = sectionFor(key, fileOrder(name));
    if (!sec.images.length && isDefaultLabel(sec)) sec.label = t;   // 그 섹션 첫 이미지의 이름으로
    return sec;
  }
  function setSecLabel(s, t) {
    s.label = t;
    if (s.key === 'etc') { s.key = 'custom'; s.nav = true; }   // '기타'에 이름이 생기면 보통 섹션으로 (메뉴에 나옴, 다음 '기타' 이미지는 새 기타로)
    if (state.sections.indexOf(s) >= 0) groupOf(state.sections, s).forEach(function (m) { if (m.join) m.label = t; });
  }

  var OCR_SRC = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
  var TITLE_WORDS = ['분양안내', '분양정보', '분양일정', '분양조건', '청약안내', '청약일정', '모집공고', '사업개요', '단지개요', '입지환경', '교통환경', '교육환경', '생활환경', '자연환경',
    '생활인프라', '개발호재', '미래가치', '프리미엄', '브랜드', '단지배치', '단지안내', '단지특화', '동호수배치', '커뮤니티', '조경', '특화설계', '설계특화', '상품특화', '인테리어', '마감재',
    '타입안내', '평면안내', '세대안내', '평면도', '유니트', '시스템', '스마트홈', '홍보영상', '오시는길', '모델하우스', '견본주택', '방문예약', '관심고객', '이벤트', '갤러리', '상품안내',
    '단지특장점', '특장점', '입주안내', '금융혜택', '계약조건', '분양가', '주차', '보안', '친환경', '드론영상'];
  var ocrWorker = null, ocrLoading = null, ocrSeen = new Set(), ocrBusy = false;
  function ocrReady() {
    if (ocrWorker) return Promise.resolve(ocrWorker);
    if (!ocrLoading) ocrLoading = (async function () {
      if (!window.Tesseract) await new Promise(function (ok, no) {
        var sc = document.createElement('script'); sc.src = OCR_SRC; sc.onload = ok;
        sc.onerror = function () { sc.remove(); no(new Error('글자 읽기 도구를 못 받았어요 (인터넷 연결을 확인해 주세요)')); };
        document.head.appendChild(sc);
      });
      ocrWorker = await window.Tesseract.createWorker('kor', 1);
      return ocrWorker;
    })().catch(function (e) { ocrLoading = null; throw e; });
    return ocrLoading;
  }
  function lev(a, b) {
    var p = [], i, j;
    for (j = 0; j <= b.length; j++) p[j] = j;
    for (i = 1; i <= a.length; i++) {
      var q = [i];
      for (j = 1; j <= b.length; j++) q[j] = Math.min(p[j] + 1, q[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      p = q;
    }
    return p[b.length];
  }
  function fixTitle(t) {
    var k = t.replace(/\s+/g, ''), best = '', bd = 9, tie = false;
    if (TITLE_WORDS.indexOf(k) >= 0) return { text: k, dict: true };
    if (k.length >= 3) TITLE_WORDS.forEach(function (w) {
      if (Math.abs(w.length - k.length) > 1) return;
      var d = lev(k, w);
      if (d < bd) { bd = d; best = w; tie = false; } else if (d === bd) tie = true;
    });
    return bd === 1 && !tie ? { text: best, dict: true } : { text: t, dict: false };
  }
  function titleImg(s) { return s.kind === 'images' && !s.join ? s.header || s.images[0] || null : null; }
  // 이미지 위쪽(가로의 0.9배 높이까지)에서 크게 쓴 한글 제목 줄 → {text, dict, conf}
  async function readTitle(im) {
    var w = await ocrReady();
    var bmp = await createImageBitmap(im.blob);
    var W = Math.min(bmp.width, 900), sc = W / bmp.width, H = Math.max(1, Math.round(Math.min(bmp.height, bmp.width * 0.9) * sc));
    var c = canvas(W, H);
    c.getContext('2d').drawImage(bmp, 0, 0, bmp.width, H / sc, 0, 0, W, H); bmp.close();
    var r = await w.recognize(c, {}, { blocks: true, text: false });
    var lines = [];
    (r.data.blocks || []).forEach(function (b) { (b.paragraphs || []).forEach(function (p) { (p.lines || []).forEach(function (l) { lines.push(l); }); }); });
    var cands = lines.map(function (l) {
      var t = String(l.text || '').replace(/[^가-힣A-Za-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim(), k = t.replace(/\s/g, ''), hg = (k.match(/[가-힣]/g) || []).length;
      if (l.confidence < 70 || hg < 2 || hg > 10 || hg / k.length < 0.85) return null;
      var f = fixTitle(t);
      return { text: f.text, dict: f.dict, h: l.bbox.y1 - l.bbox.y0, conf: Math.round(l.confidence) };
    }).filter(Boolean);
    if (!cands.length) return null;
    var maxH = Math.max.apply(null, cands.map(function (x) { return x.h; }));
    var big = cands.filter(function (x) { return x.h >= maxH * 0.6; });
    return big.filter(function (x) { return x.dict; })[0] || big.sort(function (a, b) { return b.h - a.h; })[0];
  }
  var sameLabel = function (a, b) { return String(a || '').replace(/\s+/g, '') === String(b || '').replace(/\s+/g, ''); };
  // 올린 직후: 이름이 기본값인 섹션만, 확실할 때만 바꿈 (인터넷이 없으면 조용히 넘어감)
  async function autoTitles() {
    if (ocrBusy) return;
    var L = state.sections, todo = L.filter(function (s) { var im = titleImg(s); return im && s.key !== 'event' && s.key !== 'news' && isDefaultLabel(s) && !ocrSeen.has(im.id); });
    if (!todo.length) return;
    ocrBusy = true;
    var done = [];
    try {
      for (var i = 0; i < todo.length; i++) {
        var s = todo[i], im = titleImg(s);
        ocrSeen.add(im.id);
        var r = await readTitle(im);
        if (!r || state.sections !== L || L.indexOf(s) < 0 || !isDefaultLabel(s) || sameLabel(r.text, s.label) || (!r.dict && r.conf < 85)) continue;
        done.push(s.label + ' → ' + r.text);
        setSecLabel(s, r.text);
      }
    } catch (e) { /* 글자 읽기 도구를 못 받음: 그대로 둠 */ } finally { ocrBusy = false; }
    if (done.length) { changed({ sections: true, contact: true }); toast('이미지 제목 글자로 메뉴 이름을 바꿨어요: ' + done.join(', ') + ' (Ctrl+Z로 되돌리기)'); }
  }
  // '이름 자동 채우기': 지금 페이지 섹션을 다 읽어서 고르는 창
  var ocrRows = [];
  async function openTitles() {
    if (ocrBusy) { toast('이미지 글자를 읽는 중이에요. 잠깐만요'); return; }
    var L = state.sections, list = L.filter(function (s) { return titleImg(s); });
    if (!list.length) { toast('이미지가 있는 섹션이 없어요'); return; }
    ocrBusy = true;
    modal('<h3>이미지 제목 글자 읽는 중…</h3><div class="progress"><i id="ocr-pg" style="width:4%"></i></div><div class="desc" id="ocr-txt">' + (ocrWorker ? '0 / ' + list.length : '글자 읽기 도구 받는 중 (처음 한 번만)') + '</div>');
    var nums = numMap(L);
    ocrRows = [];
    try {
      await ocrReady();
      for (var i = 0; i < list.length; i++) {
        var s = list[i], r = await readTitle(titleImg(s)), no = nums.get(s);
        ocrRows.push({ s: s, r: r, no: no && no !== '–' ? no : '' });
        var pg = $('#ocr-pg'), tx = $('#ocr-txt');
        if (pg) pg.style.width = Math.round((i + 1) / list.length * 100) + '%';
        if (tx) tx.textContent = (i + 1) + ' / ' + list.length;
      }
    } catch (e) {
      ocrBusy = false;
      modal('<h3>글자를 못 읽었어요</h3><p class="desc">' + esc(e && e.message || e) + '</p><div class="acts"><button class="btn primary" type="button" data-close>닫기</button></div>');
      return;
    }
    ocrBusy = false;
    if (state.sections !== L) { $('#modal').hidden = true; return; }
    var body = ocrRows.map(function (x, k) {
      var sug = x.r ? x.r.text : '', on = !!sug && !sameLabel(sug, x.s.label) && (x.r.dict || x.r.conf >= 85);
      return '<div class="ocr-row"><input type="checkbox" data-ocr="' + k + '"' + (on ? ' checked' : '') + (sug ? '' : ' disabled') + ' aria-label="바꾸기">' +
        '<img class="imp-pic" src="' + titleImg(x.s).url + '" alt="">' +
        '<span class="ocr-old">' + (x.no ? '<b>' + x.no + '</b>' : '') + esc(x.s.label || '섹션') + '</span><span class="ocr-arrow">→</span>' +
        '<input class="inp" data-ocr-v="' + k + '" value="' + esc(sug) + '" placeholder="' + (sug ? '' : '못 읽었어요') + '"></div>';
    }).join('');
    modal('<h3>이미지 제목 글자로 메뉴 이름 채우기</h3>' +
      '<p class="desc" style="margin:0 0 10px">섹션마다 첫 이미지 위쪽의 큰 제목 글자를 읽었어요. 바꿀 것만 체크하세요. 글자가 틀렸으면 고쳐서 넣으면 돼요.</p>' +
      '<div class="ocr-list">' + body + '</div>' +
      '<div class="acts"><button class="btn" type="button" data-close>취소</button><button class="btn primary" type="button" id="ocr-apply">바꾸기</button></div>', 'wide');
  }
  function applyTitles() {
    var n = 0;
    $$('#modal-box [data-ocr]').forEach(function (c) {
      var k = +c.getAttribute('data-ocr'), x = ocrRows[k], v = ($('#modal-box [data-ocr-v="' + k + '"]') || { value: '' }).value.trim().slice(0, 20);
      if (!c.checked || !x || !v || sameLabel(v, x.s.label)) return;
      setSecLabel(x.s, v); n++;
    });
    $('#modal').hidden = true;
    if (n) { changed({ sections: true, contact: true }); toast('메뉴 이름 ' + n + '개를 바꿨어요 (Ctrl+Z로 되돌리기)'); }
  }
  $('#ocr-names').addEventListener('click', openTitles);
  $('#modal-box').addEventListener('input', function (e) { var k = e.target.getAttribute('data-ocr-v'); if (k != null) { var c = $('#modal-box [data-ocr="' + k + '"]'); if (c) { c.disabled = false; c.checked = !!e.target.value.trim(); } } });
  $('#modal-box').addEventListener('click', function (e) { if (e.target.id === 'ocr-apply') applyTitles(); });

  function afterImagesChanged() {
    if (!state.brandTouched) {
      var sug = brandSuggestions().filter(function (h) { return lum(h) < 120; });
      if (sug.length) state.brand = sug[0];
    }
    // 슬라이드 섹션: 첫 이미지의 위쪽 띠 높이 자동 감지 (띠가 없으면 0 → 화살표 가운데)
    allSecs().forEach(function (s) {
      if (s.kind !== 'images' || s.mode !== 'slide' || !s.images.length || s.autoBand !== null || s.detecting) return;
      s.detecting = true;
      detectBand(s.images[0]).then(function (v) {
        s.detecting = false; s.autoBand = v == null ? 0 : v;
        renderSections(); schedulePreview();
      });
    });
  }

  function brandSuggestions() {
    var cnt = new Map();
    var add = function (im) {
      if (!im || !im.bg || lum(im.bg) > 200) return;
      cnt.set(im.bg, (cnt.get(im.bg) || 0) + 1);
    };
    state.sections.forEach(function (s) { (s.images || []).forEach(add); if (s.header) add(s.header); });
    return Array.from(cnt.entries()).sort(function (a, b) { return b[1] - a[1]; }).map(function (e) { return e[0]; }).slice(0, 8);
  }

  function splitTitle(name) {
    name = String(name || '').trim();
    var sp = [];
    for (var i = 0; i < name.length; i++) if (name[i] === ' ') sp.push(i);
    if (!sp.length) return name;
    var mid = name.length / 2;
    var best = sp.reduce(function (a, b) { return Math.abs(b - mid) < Math.abs(a - mid) ? b : a; });
    return name.slice(0, best) + '\n' + name.slice(best + 1);
  }
  function telOf(p) { return 'tel:' + String(p || '').replace(/[^0-9+]/g, ''); }

  /* =========================================================
     페이지 생성 (미리보기·내보내기 공용)
     o = { preview, intro, src(im, pre), dims(im), css }
     ========================================================= */
  var SVG = {
    burger: '<svg class="burger" viewBox="0 0 27 27" aria-hidden="true"><rect x="3" y="5" width="21" height="2" rx="1"/><rect x="3" y="13" width="21" height="2" rx="1"/><rect x="3" y="21" width="21" height="2" rx="1"/></svg>',
    phone: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1C10.61 21 3 13.39 3 4c0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>',
    edit: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>',
    prev: '<svg viewBox="0 0 24 24"><path d="M15.41 16.59 10.83 12l4.58-4.59L14 6l-6 6 6 6z"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>',
    home: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.2 2.5 11.1a1 1 0 0 0 1.3 1.5l.7-.6V20a1 1 0 0 0 1 1h4.5v-5.5h4V21h4.5a1 1 0 0 0 1-1v-8l.7.6a1 1 0 0 0 1.3-1.5L12 3.2z"/></svg>',
    play: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.14v13.72a1 1 0 0 0 1.52.85l10.8-6.86a1 1 0 0 0 0-1.7L9.52 4.29A1 1 0 0 0 8 5.14z"/></svg>'
  };
  var SCRIPT_OPEN = '<script>', SCRIPT_CLOSE = '<\/script>';

  function siteCss() {
    var b = normHex(state.brand) || '#001241', rgb = hexRgb(b), hsl = rgbHsl(rgb);
    var fg = onBrand();
    var block = '/*@SITE*/\n:root {\n' +
      '  --brand: ' + b + ';          /* 메인 색 */\n' +
      '  --brand-rgb: ' + rgb.join(', ') + ';\n' +
      '  --brand-light: ' + hslHex(hsl[0], hsl[1], clamp(hsl[2] + 0.08, 0, 0.9)) + ';\n' +
      '  --brand-dark: ' + hslHex(hsl[0], hsl[1], clamp(hsl[2] - 0.07, 0.03, 1)) + ';\n' +
      '  --on-brand: ' + fg + ';     /* 메인 색 위 글씨 색 */\n' +
      '  --on-brand-rgb: ' + hexRgb(fg).join(', ') + ';\n' +
      '  --on-brand-logo: ' + (lum(fg) > 150 ? 'brightness(0) invert(1)' : 'none') + ';\n' +
      '  --logo-w: ' + Math.round(state.logoW) + 'px;\n' +
      '  --title-size: ' + (state.titleSize / 375).toFixed(4) + ';\n' +
      '  --title-top: ' + Number(state.titleTop).toFixed(1) + '%;\n' +
      '  --sub-size: ' + (state.subSize / 375).toFixed(4) + ';\n' +
      '  --sub-top: ' + Number(state.subTop).toFixed(1) + '%;\n' +
      '  --badge-w: ' + Number(state.badgeW).toFixed(1) + '%;\n' +
      '  --badge-top: ' + Number(state.badgeTop).toFixed(1) + '%;\n' +
      '  --tv-arrow: .117;          /* 슬라이드 기본값 (섹션마다 따로 지정) */\n' +
      '  --tv-band: .235;\n}\n/*@END*/';
    return T.css.replace(/\/\*@SITE\*\/[\s\S]*?\/\*@END\*\//, block);
  }

  function figureHtml(im, label, o, pre, extra) {
    var d = o.dims(im);
    var bg = im.bg && im.bg !== '#ffffff' ? ' style="--bg:' + im.bg + '"' : '';
    return '<figure class="pic reveal' + (extra || '') + '"' + bg + '><img src="' + esc(o.src(im, pre)) + '" width="' + d.w + '" height="' + d.h +
      '" loading="lazy" alt="' + esc(im.alt || label) + '"></figure>';
  }
  function slidesHtml(s, o, pre) {
    var list = s.images.map(function (im) {
      var d = o.dims(im);
      return [im.label || '', Math.round(d.h * 860 / d.w), o.src(im, pre), im.alt || (im.label ? s.label + ' ' + im.label : s.label)];
    });
    var band = bandOf(s);
    var tvAttr = band > 0 ? ' style="--tv-arrow:' + (band / 2).toFixed(3) + ';--tv-band:' + band.toFixed(3) + '"' : '';
    return '  <section class="slides' + (s.key === 'types' ? ' types' : '') + '" id="' + s.id + '">\n' +
      (s.header ? '    ' + figureHtml(s.header, s.label, o, pre) + '\n' : '') +
      (s.tabs ? '    <div class="tabs-wrap">\n      <div class="tabs" role="tablist" aria-label="' + esc(s.label) + ' 선택"><span class="tabs-ink" aria-hidden="true"></span></div>\n    </div>\n' : '') +
      '    <div class="tv' + (band > 0 ? '' : ' tv--mid') + '"' + tvAttr + ' data-types="' + esc(JSON.stringify(list)) + '">\n' +
      '      <div class="tv-vp"><div class="tv-track"></div></div>\n' +
      '      <button class="tv-nav tv-prev" type="button" aria-label="이전">' + SVG.prev + '</button>\n' +
      '      <button class="tv-nav tv-next" type="button" aria-label="다음">' + SVG.next + '</button>\n' +
      '      <div class="tv-count"><b>1</b> / <span>' + list.length + '</span></div>\n' +
      '    </div>\n  </section>';
  }
  function textHtml(s) {
    var items = s.texts.filter(function (t) { return String(t.text || '').trim(); });
    return '  <section class="text-sec" id="' + s.id + '" style="background:' + txColor(s.bg) + ';padding:' + s.padY + 'px 24px" data-bg="' + esc(s.bg) + '" data-pad="' + s.padY + '">\n' +
      items.map(function (t, k) {
        var last = k === items.length - 1;
        return '    <p class="tx reveal hl-' + t.font + '" style="font-size:calc(var(--colw) * ' + (t.size / 375).toFixed(5) + ');color:' + txColor(t.color) +
          ';text-align:' + t.align + ';line-height:' + t.lh + (last ? '' : ';margin-bottom:' + t.gap + 'px') + (t.font === 'pretendard' ? ';font-weight:' + (t.bold ? 800 : 500) : '') + '"' +
          ' data-font="' + t.font + '" data-size="' + t.size + '" data-color="' + esc(t.color) + '" data-align="' + t.align + '" data-lh="' + t.lh + '" data-gap="' + t.gap + '"' + (t.bold ? ' data-bold="1"' : '') + '>' +
          br(t.text.trim()) + '</p>';
      }).join('\n') + '\n  </section>';
  }
  function videoHtml(s, o, pre) {
    var head = s.header ? '    ' + figureHtml(s.header, s.label, o, pre) + '\n' : '';
    var label = esc(s.label.trim() || '영상');
    if (s.vsrc === 'youtube') {
      return '  <section class="video-sec" id="' + s.id + '" data-video="youtube">\n' + head +
        '    <div class="vbox vbox--yt" style="aspect-ratio: ' + (s.ratio === '9:16' ? '9 / 16' : '16 / 9') + '" data-yt="' + esc(s.yt) + '">\n' +
        '      <button class="vbox-play" type="button" aria-label="' + label + ' 재생">\n' +
        '        <img src="https://img.youtube.com/vi/' + esc(s.yt) + '/maxresdefault.jpg" alt="" loading="lazy">\n' +
        '        <span class="vbox-btn" aria-hidden="true">' + SVG.play + '</span>\n' +
        '      </button>\n    </div>\n  </section>';
    }
    var f = s.vfile;
    return '  <section class="video-sec" id="' + s.id + '" data-video="file">\n' + head +
      '    <div class="vbox" style="aspect-ratio: ' + f.w + ' / ' + f.h + '">\n' +
      '      <video src="' + esc(o.src(f, pre)) + '"' + (s.poster ? ' poster="' + esc(o.src(s.poster, pre)) + '"' : '') +
      (s.autoplay ? ' autoplay muted loop playsinline preload="auto" data-autoplay' : ' controls playsinline preload="metadata"') +
      ' aria-label="' + label + '"></video>\n    </div>\n  </section>';
  }
  function sectionHtml(s, o, pre) {
    var h = sectionHtml1(s, o, pre), a = s.anim;
    if (h && a && a.type && a.type !== 'base') h = h.replace(/<section\b/, '<section data-anim="' + a.type + '"' + (a.type !== 'none' && a.dur && a.dur !== 1 ? ' data-ad="' + a.dur + '"' : '') + (a.type !== 'none' && a.rep ? ' data-anim-rep' : ''));
    return h && s.join ? h.replace(/<section\b/, '<section data-join') : h;
  }
  function sectionHtml1(s, o, pre) {
    if (s.kind === 'video') return filled(s) ? videoHtml(s, o, pre) : '';
    if (s.kind === 'text') return filled(s) ? textHtml(s) : '';
    if (s.kind !== 'images' || !filled(s)) return '';
    if (s.mode === 'slide' && s.images.length) return slidesHtml(s, o, pre);
    var all = (s.header ? [s.header] : []).concat(s.images);
    var sfl = flHtml(s.fl, flAr(s), o, pre, '    '), flc = sfl ? 'has-fl' : '';
    if (pcSplitOk(renderSub) && s.pcImages && s.pcImages.length) {   // 휴대폰은 기본(모바일) 이미지, PC(768px~ 넓은 페이지)는 PC 이미지
      return '  <section class="has-pc' + (flc ? ' ' + flc : '') + '" id="' + s.id + '">\n' + all.map(function (im) { return '    ' + figureHtml(im, s.label, o, pre, ' m-only'); })
        .concat(s.pcImages.map(function (im) { return '    ' + figureHtml(im, s.label, o, pre, ' pc-only'); })).join('\n') + (sfl ? '\n' + sfl : '') + '\n  </section>';
    }
    return '  <section' + (flc ? ' class="' + flc + '"' : '') + ' id="' + s.id + '">\n' + all.map(function (im) { return '    ' + figureHtml(im, s.label, o, pre); }).join('\n') + (sfl ? '\n' + sfl : '') + '\n  </section>';
  }
  /* 자유 레이어 (대지에서 놓은 글·사각형·이미지). 칸(host) = 이미지 섹션 또는 히어로
     - 위치·크기는 그 칸 가로 폭에 대한 비율 {x, y, w, h}. 내보낼 때 세로는 칸 높이 비율로 바꿈 (ar = 칸 높이 / 가로)
     - 글자 크기·모서리는 디자인 폭(basis: 메인 375, 메뉴 페이지 그 폭) 기준 px → 칸 폭에 비례 (100cqw)
     - data-fl 에 설정을 통째로 (zip 다시 불러오기용) */
  var flCtx = { tel: '', res: 'contact/', go: false, basis: 375 };
  function flColor(c) { return c === 'brand' ? 'var(--brand)' : c === 'onbrand' ? 'var(--on-brand)' : (normHex(c) || '#111111'); }
  function flAr(host) {
    if (host === 'hero') return state.heroBg ? state.heroBg.h / state.heroBg.w : 1366 / 860;
    var s = host && host.images ? host : null;
    if (!s) return 1;
    var t = (s.header ? s.header.h / s.header.w : 0);
    s.images.forEach(function (im) { t += im.h / im.w; });
    return t || 1;
  }
  function flData(L) { var d = {}; Object.keys(L).forEach(function (k) { if (k !== 'img') d[k] = L[k]; }); return d; }
  function flHtml(list, ar, o, pre, ind) {
    if (!list || !list.length) return '';
    var basis = flCtx.basis || 375;
    var pc = function (v) { return +(v * 100).toFixed(3) + '%'; }, py = function (v) { return +(v / ar * 100).toFixed(3) + '%'; };
    var k = function (px) { return +((px || 0) / basis).toFixed(5); };
    return list.map(function (L) {
      if (L.hidden) return '';
      var st = 'left:' + pc(L.x) + ';top:' + py(L.y) + ';width:' + pc(L.w), cls = 'fl fl-' + L.t + ' reveal', inner = '';
      if (L.t === 'text') {
        if (!String(L.text || '').trim()) return '';
        cls += ' hl-' + (L.font || 'pretendard');
        st += ';--fk:' + k(L.size || 24) + ';color:' + flColor(L.color) + ';text-align:' + (L.align || 'left') + ';line-height:' + (L.lh || 1.3) + ';letter-spacing:' + (L.ls || 0) + 'em' +
          ((L.font || 'pretendard') === 'pretendard' ? ';font-weight:' + (L.weight || 700) : '');
        inner = esc(String(L.text).replace(/\r\n/g, '\n'));
      } else if (L.t === 'rect') {
        st += ';height:' + py(L.h) + ';background:' + flColor(L.fill) + (L.radius ? ';--rk:' + k(L.radius) : '') +
          (L.stroke && L.strokeW ? ';box-shadow:inset 0 0 0 calc(100cqw * ' + k(L.strokeW) + ') ' + flColor(L.stroke) : '');
      } else if (L.t === 'img') {
        if (!L.img) return '';
        var d = o.dims(L.img);
        inner = '<img src="' + esc(o.src(L.img, pre)) + '" width="' + d.w + '" height="' + d.h + '" alt="' + esc(L.alt || '') + '">';
      } else return '';
      if (L.opacity != null && L.opacity < 1) st += ';opacity:' + L.opacity;
      var a = ' class="' + cls + '" style="' + st + '"' + (o.preview ? ' data-flid="' + esc(L.id) + '"' : '') + ' data-fl="' + esc(JSON.stringify(flData(L))) + '"';
      var tag = L.link === 'tel' && flCtx.tel ? '<a href="' + flCtx.tel + '"' + a + '>' : L.link === 'reserve' ? '<a href="' + flCtx.res + '"' + (flCtx.go ? ' data-go-reserve' : '') + a + '>' : '<div' + a + '>';
      return ind + tag + inner + (tag.charAt(1) === 'a' ? '</a>' : '</div>');
    }).filter(Boolean).join('\n');
  }
  function heroHtml(o, pre, withId) {
    var S = state, d = o.dims(S.heroBg), hp = isPcMode() && S.heroBgPc, dp = hp ? o.dims(S.heroBgPc) : null;
    var hfl = flHtml(S.heroFl, d.h / d.w, o, pre, '    ');
    var out = '<section class="hero' + (hp ? ' has-pc' : '') + (hfl ? ' has-fl' : '') + '"' + (withId ? ' id="s-top"' : '') + ' style="aspect-ratio: ' + d.w + ' / ' + d.h + (hp ? '; --ar-pc: ' + dp.w + ' / ' + dp.h : '') + '">\n' +
      '    <div class="hero-bg">' + (hp ? '<picture><source media="(min-width: 768px)" srcset="' + esc(o.src(S.heroBgPc, pre)) + '" width="' + dp.w + '" height="' + dp.h + '">' : '') +
      '<img src="' + esc(o.src(S.heroBg, pre)) + '" width="' + d.w + '" height="' + d.h + '" alt="' + esc(S.siteName) + ' 단지 전경" fetchpriority="high">' + (hp ? '</picture>' : '') + '</div>\n';
    if (S.heroSub.trim()) out += '    <p class="hero-sub a-fade" style="--dur:.5s;--delay:.2s">' + esc(S.heroSub.trim()) + '</p>\n';
    out += '    <h1 class="hero-title a-fade" style="--dur:1s;--delay:.35s">' + br(S.heroTitle.trim() || S.siteName) + '</h1>\n';
    if (S.badge) {
      var b = o.dims(S.badge);
      out += '    <div class="hero-badges">\n      <img class="a-up" src="' + esc(o.src(S.badge, pre)) + '" width="' + b.w + '" height="' + b.h + '" alt="' + esc(S.badgeAlt || '주요 혜택') + '" style="--delay:.6s">\n    </div>\n';
    }
    (S.heroLayers || []).forEach(function (L, k) {
      var delay = '--delay:' + (0.75 + k * 0.1).toFixed(2) + 's';
      if (L.kind === 'image') {
        if (!L.image) return;
        var ld = o.dims(L.image);
        out += '    <div class="hero-layer" style="top:' + L.top + '%;width:' + L.w + '%" data-top="' + L.top + '" data-w="' + L.w + '">\n' +
          '      <img class="a-up" src="' + esc(o.src(L.image, pre)) + '" width="' + ld.w + '" height="' + ld.h + '" alt="' + esc(L.image.alt || '') + '" style="' + delay + '">\n    </div>\n';
      } else {
        if (!String(L.text || '').trim()) return;
        var col = L.color === 'brand' ? 'var(--brand)' : (normHex(L.color) || '#ffffff');
        out += '    <div class="hero-layer hero-layer--text" style="top:' + L.top + '%" data-top="' + L.top + '">\n' +
          '      <p class="a-up hl-' + L.font + '" style="font-size:calc(var(--colw) * ' + (L.size / 375).toFixed(5) + ');color:' + col +
          (L.font === 'pretendard' ? ';font-weight:' + (L.bold ? 800 : 500) : '') + ';' + delay + '" data-size="' + L.size + '" data-font="' + L.font + '" data-color="' + esc(L.color) + '"' + (L.bold ? ' data-bold="1"' : '') + '>' +
          br(L.text.trim()) + '</p>\n    </div>\n';
      }
    });
    return out + (hfl ? hfl + '\n' : '') + '  </section>';
  }

  // page: 'main' | 'contact' | 메뉴 페이지 주소(slug)
  function renderPage(page, o) {
    var S = state, M = MAIN(), menuMode = isMenuMode();
    var isC = page === 'contact';
    var pgx = menuMode && !isC && page !== 'main' ? pageBySlug(page) : null;   // {page, parent}
    var isSub = !!pgx, isMain = !isC && !isSub, pre = isMain ? '' : '../';
    var isPc = isPcMode();
    renderSub = isSub;
    flCtx = { tel: telOf(S.phone), res: isC ? '#reserve' : (isMain ? '' : '../') + 'contact/', go: isC, basis: isSub ? (pgx.page.cw || 1200) : 375 };
    var isWidePage = isPc || (isSub && pgx.page.cw !== 375);   // 375(모바일 이미지)는 홈처럼 좁게, PC 최적화는 모든 페이지 넓게
    var site = esc(S.siteName.trim()), titleHtml = br(S.heroTitle.trim() || S.siteName), sub = esc(S.heroSub.trim());
    var phone = esc(S.phone.trim()), tel = telOf(S.phone);
    var logo = function (cls, alt) {
      if (!S.logo) return '';
      var d = o.dims(S.logo);
      return '<img class="' + cls + '" src="' + esc(o.src(S.logo, pre)) + '" width="' + d.w + '" height="' + d.h + '" alt="' + alt + '">';
    };
    var secs = M.filter(function (s) { return s.kind !== 'form' && onPage(s, isC); });
    var navSecs = secs.filter(function (s) { return !!navTarget(M, s); });
    var list = (formsOf(M).length ? M : [formItem()].concat(M)).filter(function (s) { return onPage(s, isC); });
    var forms = formsOf(list);
    var nav;
    if (!isSub) {   // 메인·방문예약: 그 페이지에 있는 섹션만 (원페이지만이든 메뉴 방식이든 같음)
      var navItems = isC ? navSecs : list.filter(function (s) { return s.kind === 'form' ? s.nav : !!navTarget(M, s); });
      nav = ['  <a href="#s-top" data-nav-top>' + site + '</a>']
        .concat(navItems.map(function (s) {
          return s.kind === 'form' ? '  <a href="#' + formOutId(forms.indexOf(s)) + '">' + esc(s.label.trim() || '방문예약') + '</a>'
            : '  <a href="#' + navTarget(M, s).id + '">' + esc(s.label) + '</a>';
        }))
        .join('\n');
    } else {
      // 메뉴 페이지: 그 페이지 섹션 중 '메뉴'를 켠 것 (00은 이 페이지 맨 위)
      nav = ['  <a href="#top" data-nav-top>' + site + '</a>']
        .concat((pgx.page.sections || []).filter(function (s) { return !!navTarget(pgx.page.sections, s); }).map(function (s) { return '  <a href="#' + navTarget(pgx.page.sections, s).id + '">' + esc(s.label) + '</a>'; }))
        .join('\n');
    }
    // 메뉴 줄: 대메뉴(소메뉴 있으면 누를 때 펼침) + 맨 끝 방문예약
    var menubar = '';
    if (menuMode) {
      var curPage = isSub ? pgx.page : null, curParent = isSub ? pgx.parent : null;
      var plink = function (slug) { return (isMain ? '' : '../') + slug + '/'; };
      var contactLabel = (formsOf(M)[0] && formsOf(M)[0].label.trim()) || '방문예약';
      var defs = [], items = [], subs = [];
      (S.menus || []).forEach(function (m, a) {
        var kids = m.children || [];
        if (kids.length) {
          var open = curParent === m;
          defs.push({ name: m.name, children: kids.map(function (c) { return { name: c.name, slug: c.slug }; }) });
          items.push('      <button class="mb-item mb-group' + (open ? ' is-cur is-open is-home' : '') + '" type="button" aria-expanded="' + open + '" aria-controls="mb-sub-' + a + '">' + esc(m.name) + '<i aria-hidden="true"></i></button>');
          subs.push('    <div class="mb-sub' + (open ? ' is-open' : '') + '" id="mb-sub-' + a + '"><div>\n' + kids.map(function (c, k) {
            var on = curPage === c;
            return '      <a href="' + (on ? '#top' : plink(c.slug)) + '" style="--i:' + k + '"' + (on ? ' class="is-cur" aria-current="page"' : '') + '>' + esc(c.name) + '</a>';
          }).join('\n') + '\n    </div></div>');
        } else {
          var on = curPage === m;
          defs.push({ name: m.name, slug: m.slug });
          items.push('      <a class="mb-item' + (on ? ' is-cur' : '') + '" href="' + (on ? '#top' : plink(m.slug)) + '"' + (on ? ' aria-current="page"' : '') + '>' + esc(m.name) + '</a>');
        }
      });
      if (S.menuContact !== false) items.push('      <a class="mb-item' + (isC ? ' is-cur' : '') + '" href="' + (isC ? '#top' : plink('contact')) + '" data-contact' + (isC ? ' aria-current="page"' : '') + '>' + esc(contactLabel) + '</a>');
      menubar = '  <nav class="menubar" aria-label="메뉴" data-menus="' + esc(JSON.stringify(defs)) + '">\n    <div class="mb-row">\n' + items.join('\n') + '\n    </div>\n' +
        (subs.length ? subs.join('\n') + '\n' : '') + '  </nav>\n\n';
    }

    // 인트로: 로고만 고르고 로고가 없으면 인트로 없음, 둘 다 골랐는데 로고가 없으면 현장명만
    var imode = S.introMode || 'both';
    var introLogo = isMain && !!S.logo && (imode === 'both' || imode === 'logo');
    var introName = isMain && (imode === 'both' || imode === 'text');
    var hasIntro = introLogo || introName;
    var headScript = !hasIntro ? "document.documentElement.className = 'js no-intro';"
      : o.preview ? "document.documentElement.className = 'js " + (o.intro ? 'is-intro' : 'no-intro') + "';"
        : "(function (d) {\n    var c = d.documentElement;\n    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;\n    c.className = 'js ' + (/nointro/.test(location.search) || reduce ? 'no-intro' : 'is-intro');\n  })(document);";
    if (menuMode) {
      headScript = o.preview ? "document.documentElement.className = 'js " + (hasIntro && o.intro ? 'is-intro' : 'no-intro') + (isWidePage ? ' is-wide' : '') + "';"
        : "(function (d) {\n    var c = d.documentElement, s = null, w = false, seen = false;\n    try { s = sessionStorage; w = s.getItem('lp-wide') === '1'; seen = s.getItem('lp-intro') === '1'; } catch (e) {}\n" +
          (hasIntro ? "    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;\n    c.className = 'js ' + (/nointro/.test(location.search) || reduce || seen ? 'no-intro' : 'is-intro') + " + (isPc ? "' is-wide'" : "(w ? ' is-wide' : '')") + ";\n"
            : "    c.className = 'js no-intro' + " + (isPc ? "' is-wide'" : "(w ? ' is-wide' : '')") + ";\n") + "  })(document);";
    }
    var cssTags = o.preview ? '<style>' + o.css + '</style>'
      : '<link rel="stylesheet" href="' + pre + 'css/pretendard.css">\n<link rel="stylesheet" href="' + pre + 'css/landing-style.css">';
    var jsTag = o.board ? SCRIPT_OPEN + T.js + SCRIPT_CLOSE : o.preview ? SCRIPT_OPEN + T.js + SCRIPT_CLOSE + '\n' + PV_NAV + '\n' + PV_EDIT : '<script src="' + pre + 'js/main.js">' + SCRIPT_CLOSE;
    var desc = (sub ? sub + ', ' : '') + site + ' 방문예약' + (phone ? ' ' + phone : '');
    var privacyTpl = function () {
      var p = S.privacyText || '', t = S.thirdPartyText || '';
      return (p.trim() ? '<template data-leadyo-privacy-text>' + esc(p) + '</template>\n' : '') +
        (t.trim() ? '<template data-leadyo-third-party-text>' + esc(t) + '</template>\n' : '') + (p.trim() || t.trim() ? '\n' : '');
    };
    var disc = S.disclaimers.split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean)
      .map(function (l) { return '    <p>' + esc(l) + '</p>'; }).join('\n');
    var moreLink = isC ? '      <a class="hd-menu-more" href="../">전체 내용 보기 →</a>\n' : '      <a class="hd-menu-more" href="contact/">방문 예약하기 →</a>\n';
    var toContact = (isMain ? '' : '../') + 'contact/';
    var reserveBtn = isC ? '<a class="pc-btn" href="#reserve" data-go-reserve>방문예약 등록</a>' : '<a class="pc-btn" href="' + toContact + '">방문예약 등록</a>';
    var barReserve = isC ? '<a class="bar-reserve" href="#reserve" data-go-reserve>' : '<a class="bar-reserve" href="' + toContact + '">';
    // 메뉴 페이지 방식: 넓어질 때 나오는 띠 내용 (원페이지만이면 안 넣음)
    // 넓을 때: 오른쪽 아래 둥근 버튼 (큰 원 = 상담 신청·전화, 둘레에 현장명이 돌아감 / 작은 원 = 방문예약 등록)
    var ring = '• ' + esc((S.siteName.trim() || '상담신청').slice(0, 12)) + ' •';
    var HEADSET = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 0 0-9 9v5a3 3 0 0 0 3 3h1a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H5v-1a7 7 0 0 1 14 0v1h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h1a3 3 0 0 0 3-3v-5a9 9 0 0 0-9-9z"/></svg>';
    var barWide = menuMode ? '  <div class="bar-w">\n    <a class="bw-call" href="' + tel + '" aria-label="상담 신청 ' + phone + '">' +
      '<svg class="bw-ring" viewBox="0 0 132 132" aria-hidden="true"><circle cx="66" cy="66" r="64" fill="#fff" stroke="#2b2b2b" stroke-width="1.2"/>' +
      '<path id="bw-path" d="M66,66 m-56,0 a56,56 0 1,1 112,0 a56,56 0 1,1 -112,0" fill="none"/>' +
      '<text text-anchor="middle"><textPath href="#bw-path" startOffset="36%">' + ring + '</textPath></text>' +
      '<text text-anchor="middle"><textPath href="#bw-path" startOffset="86%">' + ring + '</textPath></text></svg>' +
      '<span class="bw-core">' + HEADSET + '<b>상담신청</b></span></a>\n' +
      '    ' + barReserve.replace('class="bar-reserve"', 'class="bw-res"') + SVG.edit + '방문예약<br>등록</a>\n  </div>\n' : '';
    // 폼 자리: 추가 항목은 감싼 section에 data-fields로 (리드요 폼 div는 비워 둠). 방문예약·메뉴 페이지 폼은 첫 번째 폼의 항목
    var firstForm = formsOf(M)[0] || null;
    var formHtml = function (id, fi) {
      fi = fi || firstForm;
      var fl = fi ? fieldsOut(fi) : [];
      var attrs = fl.length ? ' data-fields="' + esc(JSON.stringify(fl)) + '"' + (fi.hideMemo ? ' data-hide-memo' : '') : '';
      return '<section class="reserve" id="' + id + '"' + attrs + '>\n    <div data-leadyo-form>' + (o.preview ? PV_MOCK_FORM : '') + '</div>\n  </section>';
    };
    // 헤더 왼쪽: 원페이지만이면 메뉴(빠른 이동), 메뉴 페이지 방식이면 '자세히 보기'(메인 원페이지로)
    var leftBtn = menuMode ? '    <a class="hd-btn hd-more" href="' + (isMain ? '#top' : '../') + '">\n      ' + SVG.home + '\n      <span>자세히 보기</span>\n    </a>\n'
      : '    <button class="hd-btn hd-menu-btn" type="button" aria-expanded="false" aria-controls="hd-menu">\n      ' + SVG.burger + '\n      <span>메뉴</span>\n    </button>\n';
    var menuPanel = menuMode ? ''
      : '    <div class="hd-dim" aria-hidden="true"></div>\n    <nav class="hd-menu" id="hd-menu" aria-label="빠른 이동">\n      <ol class="hd-menu-list"></ol>\n' + moreLink + '    </nav>\n';

    var body;
    if (isC) {
      body = '  <div id="s-top">\n    ' + formHtml('reserve').replace(/\n/g, '\n  ') +
        (S.contactHero ? '\n\n    ' + heroHtml(o, pre, false).replace(/\n/g, '\n  ') : '') + '\n  </div>\n\n' +
        secs.map(function (s) { return sectionHtml(s, o, pre); }).filter(Boolean).concat(S.contactFormBottom ? ['  ' + formHtml('reserve-2')] : []).join('\n\n');
    } else if (isSub) {
      body = [S.pageTitle !== false ? '  <h1 class="page-title">' + esc(pgx.page.name) + '</h1>' : '']
        .concat((pgx.page.sections || []).map(function (s) { return sectionHtml(s, o, pre); }))
        .concat(S.pageForm !== false ? ['  ' + formHtml('reserve')] : []).filter(Boolean).join('\n\n');
    } else {
      body = '  ' + heroHtml(o, pre, true) + '\n\n' +
        list.map(function (s) { return s.kind === 'form' ? '  ' + formHtml(formOutId(forms.indexOf(s)), s) : sectionHtml(s, o, pre); }).filter(Boolean).join('\n\n');
    }

    return '<!doctype html>\n<html lang="ko" class="no-js"' + (menuMode ? ' data-mode="menu"' + (isPc ? ' data-pc' + (isSub ? ' data-sub' : '') : '') + (isWidePage ? ' data-wide' + (isSub && pgx.page.cw === 860 ? ' data-cw="860"' : '') : '') : '') + '>\n<head>\n<meta charset="utf-8">\n' +
      '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n' +
      // 아이폰이 글 속 번호(푸터 등)를 멋대로 전화 링크로 바꾸지 않게. tel: 링크는 그대로 걸림
      '<meta name="format-detection" content="telephone=no">\n' +
      '<title>' + (isC ? '방문예약 | ' : isSub ? esc(pgx.page.name) + ' | ' : '') + site + '</title>\n' +
      '<meta name="description" content="' + desc + '">\n' +
      '<meta name="theme-color" content="' + (normHex(S.brand) || '#001241') + '">\n' +
      SCRIPT_OPEN + '\n  ' + headScript + '\n' + SCRIPT_CLOSE + '\n' +
      (o.preview || isSub ? '' : '<link rel="preload" as="image" href="' + esc(o.src(S.heroBg, pre)) + '">\n') +
      cssTags + '\n</head>\n<body>\n\n' +
      (hasIntro ? '<div class="intro' + (introLogo ? '' : ' intro--text') + '" id="intro" aria-hidden="true">\n' +
        (introLogo ? '  ' + logo('intro-logo', '') + '\n' : '') + (introName ? '  <p class="intro-name">' + titleHtml + '</p>\n' : '') + '</div>\n\n' : '') +
      '<div class="pc-bg" aria-hidden="true"></div>\n\n' +
      '<aside class="pc-side pc-left">\n' +
      (sub ? '  <p class="pc-sub">' + sub + '</p>\n' : '') +
      '  <h2 class="pc-title">' + titleHtml + '</h2>\n' +
      '  <div class="pc-call">\n    <span>분양 문의</span>\n    <a href="' + tel + '">' + phone + '</a>\n  </div>\n  ' + reserveBtn + '\n</aside>\n\n' +
      '<nav class="pc-side pc-right" aria-label="섹션 바로가기">\n' + nav + '\n</nav>\n\n' +
      '<div class="app" id="top">\n\n' +
      '  <header class="hd">\n' + leftBtn +
      '    <a class="hd-logo" href="' + (isMain ? '#top' : '../') + '">\n      ' + logo('logo', site) + '\n    </a>\n' +
      (menuMode ? '    <a class="hd-btn hd-tel" href="' + tel + '">\n      ' + SVG.phone + '\n      <span>전화 연결</span>\n      <b class="hd-num">' + phone + '</b>\n    </a>\n'
        : '    <a class="hd-btn" href="' + tel + '">\n      ' + SVG.phone + '\n      <span>전화 연결</span>\n    </a>\n') +
      menuPanel +
      '  </header>\n\n' + menubar + body + '\n\n' +
      '  <footer class="ft">\n' + disc + '\n    <p class="ft-call">상담 문의 : ' + phone + '</p>\n  </footer>\n</div>\n\n' +
      '<nav class="bar" aria-label="빠른 문의">\n  ' + barReserve + '\n    ' + SVG.edit + '\n    방문예약 등록\n  </a>\n' +
      '  <a class="bar-tel" href="' + tel + '">\n    ' + SVG.phone + '\n    ' + phone + '\n  </a>\n' + barWide + '</nav>\n\n' +
      (/data-leadyo-form/.test(body) ? privacyTpl() : '') +
      jsTag + '\n</body>\n</html>\n';
  }

  // 미리보기 안에서 페이지 이동 링크를 가로채서 에디터의 [메인/방문예약] 전환으로
  var PV_FORM_CSS = "[data-leadyo-form]:empty{margin:24px 20px;min-height:140px;border:2px dashed #c5c8d1;border-radius:12px;display:grid;place-items:center;color:#8a8f9c;font-size:14px;font-weight:700}" +
    "[data-leadyo-form]:empty::before{content:'리드요 방문예약 폼이 들어갈 자리'}";
  var PV_NAV = SCRIPT_OPEN + "document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a');if(!a)return;var h=a.getAttribute('href')||'';" +
    "if(/^tel:/.test(h)){e.preventDefault();return;}" +
    "var m=/^(?:\\.\\.\\/)?(?:([a-z0-9-]+)\\/)?(?:index\\.html)?(#.*)?$/.exec(h);" +
    "if(h&&h.charAt(0)!=='#'&&m){e.preventDefault();parent.postMessage({pvNav:m[1]||'main',hash:m[2]||''},'*');}},true);" + SCRIPT_CLOSE;
  // 미리보기 안에서만: 리드요 폼처럼 생긴 예시 폼 (추가 항목 위치 확인용, 내보낸 zip에는 안 들어감)
  var PV_MOCK_FORM = '<div class="lt-form-host pv-mock"><section class="lt-form"><form onsubmit="return false" novalidate>' +
    '<h2 class="lt-form__title">방문예약</h2><div class="lt-form__fields">' +
    '<input type="text" class="lt-input" name="name" placeholder="이름"><div><input type="tel" class="lt-input" name="phone" placeholder="010-1234-5678"></div>' +
    '<label><span class="lt-field__label">방문일</span><input type="date" class="lt-input" name="visit_date"></label>' +
    '<label><span class="lt-field__label">방문시간</span><select class="lt-input" name="visit_time"><option>시간 선택</option></select></label>' +
    '<label><span class="lt-field__label">문의 내용</span><textarea class="lt-input" name="memo" rows="3" placeholder="궁금한 점을 적어 주세요"></textarea></label>' +
    '<div class="lt-form__consent-row"><label class="pv-mock-ck"><input type="checkbox" name="privacy_agreed">개인정보 수집 및 이용에 동의합니다.</label><button type="button" class="lt-form__policy-link" data-pv-pop="privacy">내용보기</button></div>' +
    '<div class="lt-form__consent-row"><label class="pv-mock-ck"><input type="checkbox" name="third_party_agreed">개인정보 제3자 제공 동의합니다.</label><button type="button" class="lt-form__policy-link" data-pv-pop="third">내용보기</button></div>' +
    '<button type="submit" class="pv-mock-btn">방문예약하기</button></div></form></section></div>';
  PV_FORM_CSS += ".pv-mock .lt-form{position:relative}.pv-mock .lt-form__consent-row{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;font-size:13px;line-height:1.5;color:#6b7280}" +
    ".pv-mock textarea.lt-input{height:auto;min-height:84px;padding:12px 14px;line-height:1.5}" +
    ".pv-mock-ck{display:flex;align-items:center;gap:8px}.pv-mock-btn{width:100%;height:50px;margin-top:6px;border:0;border-radius:10px;background:var(--brand);color:var(--on-brand);font:inherit;font-size:16px;font-weight:800}";

  // 추가 항목: 내보낼 때 쓰는 모양 (빈 제목·선택지 없는 선택형은 빼고)
  var FIELD_TYPES = [['short', '단답형'], ['long', '장문형'], ['single', '단일선택'], ['multi', '복수선택'], ['select', '목록선택']];
  var FIELD_POS = [['phone', '연락처 다음'], ['visit', '방문일·시간 다음'], ['memo', '문의 내용 위'], ['consent', '동의 체크 위']];
  function isChoice(t) { return t === 'single' || t === 'multi' || t === 'select'; }
  function fieldsOut(fi) {
    return (fi.fields || []).map(function (f) {
      var opts = (f.options || []).map(function (x) { return String(x).trim(); }).filter(Boolean);
      if (!String(f.label || '').trim() || (isChoice(f.type) && !opts.length)) return null;
      var r = { type: f.type || 'short', label: String(f.label).trim() };
      if (f.required) r.required = true;
      if (String(f.help || '').trim()) r.help = String(f.help).trim();
      if (!isChoice(f.type) && String(f.placeholder || '').trim()) r.placeholder = String(f.placeholder).trim();
      if (isChoice(f.type)) r.options = opts;
      if (f.pos && f.pos !== 'memo') r.pos = f.pos;
      return r;
    }).filter(Boolean);
  }

  // 미리보기 안에서 섹션 누르면 고르기 · 고른 섹션 표시와 떠 있는 버튼 · Ctrl+휠/단축키를 에디터로 넘기기
  function pvEditScript() {
    var SEL = '.app > section[id], .app > figure[id], #s-top > section[id], #s-top';   // 방문예약 페이지: #s-top 안의 폼(id=reserve)은 따로
    var hoverEl = null, selEl = null, oldPos = '';
    var st = document.createElement('style');
    st.textContent = '[data-ed-hover]{outline:1.5px dashed rgba(61,107,255,.8)!important;outline-offset:-2px}' +
      '[data-ed-sel]{outline:2px solid #3d6bff!important;outline-offset:-2px}' +
      '.ed-tag{position:absolute;left:6px;top:6px;z-index:35;height:22px;padding:0 8px;border-radius:6px;background:#3d6bff;color:#fff;font:700 12px/22px "Pretendard Variable",sans-serif;pointer-events:none;white-space:nowrap}' +
      '.ed-tools{position:absolute;right:8px;top:6px;z-index:36;display:flex;align-items:center;gap:2px;padding:4px;border-radius:10px;background:#1c2030;box-shadow:0 8px 24px rgba(0,0,0,.28)}' +
      '.ed-tools button{width:30px;height:30px;display:grid;place-items:center;padding:0;border:0;border-radius:7px;background:none;color:#e9ebf2;cursor:pointer}' +
      '.ed-tools button:hover{background:rgba(255,255,255,.14)}.ed-tools button.del{color:#ff9d92}' +
      '.ed-tools svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}' +
      '.ed-tools i{width:1px;height:18px;margin:0 3px;background:rgba(255,255,255,.2)}' +
      '.pv-pop{position:fixed;inset:0;z-index:90;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(0,0,0,.6)}' +
      '.pv-pop-card{display:flex;flex-direction:column;width:100%;max-width:360px;max-height:80vh;overflow:hidden;border-radius:12px;background:#fff;box-shadow:0 25px 50px -12px rgba(0,0,0,.4)}' +
      '.pv-pop-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid #f3f4f6}.pv-pop-head b{font-size:15px;color:#111827}' +
      '.pv-pop-head button{padding:0;border:0;background:none;font-size:16px;line-height:1;color:#9ca3af;cursor:pointer}' +
      '.pv-pop-body{flex:1;overflow-y:auto;padding:16px;white-space:pre-wrap;word-break:keep-all;font-size:13px;line-height:1.7;color:#4b5563}' +
      '.pv-pop-foot{padding:12px 16px;border-top:1px solid #f3f4f6;text-align:right}' +
      '.pv-pop-foot button{padding:8px 16px;border:1px solid #d1d5db;border-radius:8px;background:#fff;font:inherit;font-size:13px;font-weight:600;color:#374151;cursor:pointer}';
    document.head.appendChild(st);
    var POP = { privacy: ['개인정보 수집 및 이용동의', 'template[data-leadyo-privacy-text]'], third: ['개인정보 제3자 제공 동의', 'template[data-leadyo-third-party-text]'] };
    var openPop = function (k) {
      var p = POP[k] || POP.privacy, tp = document.querySelector(p[1]);
      var box = document.createElement('div'); box.className = 'pv-pop';
      box.innerHTML = '<div class="pv-pop-card"><div class="pv-pop-head"><b></b><button type="button" data-pv-close aria-label="닫기">✕</button></div><div class="pv-pop-body"></div><div class="pv-pop-foot"><button type="button" data-pv-close>닫기</button></div></div>';
      box.querySelector('b').textContent = p[0];
      box.querySelector('.pv-pop-body').textContent = tp ? tp.content.textContent : '(비어 있어요)';
      document.body.appendChild(box);
    };
    var ICON = {
      up: '<path d="M12 19V5M6 11l6-6 6 6"/>', down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
      dup: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
      nav: '<path d="M4 6h16M4 12h16M4 18h10"/>', del: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>'
    };
    var TIP = { up: '위로', down: '아래로', dup: '바로 아래에 복제', nav: '메뉴에 표시 켜기/끄기', del: '삭제' };
    var secOf = function (t) { return t && t.closest ? t.closest(SEL) : null; };
    var post = function (m) { parent.postMessage(m, '*'); };
    var clear = function () {
      if (!selEl) return;
      selEl.removeAttribute('data-ed-sel');
      Array.prototype.forEach.call(selEl.querySelectorAll(':scope > .ed-tag, :scope > .ed-tools'), function (x) { x.remove(); });
      selEl.style.position = oldPos; selEl = null;
    };
    var mark = function (d) {
      clear();
      var el = d.id ? document.getElementById(d.id) : null;
      if (!el) return;
      selEl = el; el.setAttribute('data-ed-sel', ''); el.removeAttribute('data-ed-hover');
      oldPos = el.style.position;
      if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
      if (d.label) { var tg = document.createElement('span'); tg.className = 'ed-tag'; tg.textContent = d.label; el.appendChild(tg); }
      if (d.tools) {
        var tb = document.createElement('div'); tb.className = 'ed-tools';
        ['up', 'down', '|', 'dup', 'nav', '|', 'del'].forEach(function (a) {
          if (a === '|') { tb.appendChild(document.createElement('i')); return; }
          var b = document.createElement('button'); b.type = 'button'; b.setAttribute('data-a', a); b.title = TIP[a];
          if (a === 'del') b.className = 'del';
          b.innerHTML = '<svg viewBox="0 0 24 24">' + ICON[a] + '</svg>'; tb.appendChild(b);
        });
        el.appendChild(tb);
      }
      if (d.scroll) {   // scrollIntoView는 에디터 쪽 칸까지 같이 움직여서, 미리보기 창만 스크롤
        var pad = parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop) || 0;
        window.scrollTo({ top: Math.max(0, el.getBoundingClientRect().top + window.scrollY - pad), behavior: 'smooth' });
      }
    };
    window.addEventListener('message', function (e) { if (e.data && 'edMark' in e.data) mark({ id: e.data.edMark, label: e.data.label, tools: e.data.tools, scroll: e.data.scroll }); });
    document.addEventListener('mouseover', function (e) {
      var s = secOf(e.target);
      if (s === hoverEl) return;
      if (hoverEl) hoverEl.removeAttribute('data-ed-hover');
      hoverEl = s && s !== selEl ? s : null;
      if (hoverEl) hoverEl.setAttribute('data-ed-hover', '');
    });
    document.addEventListener('mouseleave', function () { if (hoverEl) hoverEl.removeAttribute('data-ed-hover'); hoverEl = null; });
    document.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('.ed-tools button');
      if (b) { e.preventDefault(); e.stopPropagation(); post({ edAct: b.getAttribute('data-a'), id: selEl ? selEl.id : '' }); return; }
      var pp = e.target.closest && e.target.closest('[data-pv-pop]');
      if (pp) { openPop(pp.getAttribute('data-pv-pop')); return; }
      var pw = e.target.closest && e.target.closest('.pv-pop');
      if (pw) { if (e.target === pw || e.target.closest('[data-pv-close]')) pw.remove(); return; }
      if (e.target.closest && e.target.closest('a[href], button, input, select, textarea, label, video, iframe')) return;
      var s = secOf(e.target);
      if (s) post({ edSel: s.id });
    }, true);
    window.addEventListener('wheel', function (e) {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      post({ edWheel: { dy: e.deltaY, x: e.clientX, y: e.clientY } });
    }, { passive: false });
    var KEYS = /^(KeyZ|KeyY|KeyC|KeyV|Equal|Minus|Digit0|NumpadAdd|NumpadSubtract|Numpad0)$/;
    var fwd = function (type) {
      return function (e) {
        var t = e.target;
        if (t && t.closest && t.closest('input, textarea, select')) return;
        var mod = e.ctrlKey || e.metaKey, c = e.code;
        if (!((mod && KEYS.test(c)) || (e.shiftKey && c === 'Digit1') || c === 'Space' || c === 'Delete' || c === 'Escape')) return;
        e.preventDefault();
        post({ edKey: { type: type, code: c, ctrl: mod, shift: e.shiftKey, alt: e.altKey } });
      };
    };
    document.addEventListener('keydown', fwd('down'), true);
    document.addEventListener('keyup', fwd('up'), true);
  }
  var PV_EDIT = SCRIPT_OPEN + '(' + pvEditScript.toString() + ')();' + SCRIPT_CLOSE;

  /* =========================================================
     글꼴 (미리보기·에디터 화면용 blob 주소)
     ========================================================= */
  var fontUrl = {};
  function b64Bytes(b64) { var s = atob(b64), a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
  Object.keys(T.fonts).forEach(function (p) { fontUrl[p] = URL.createObjectURL(new Blob([b64Bytes(T.fonts[p])], { type: 'font/woff2' })); });
  var swapFonts = function (css) {
    return css.replace(/url\(\s*['"]?\.\.\/(fonts\/[^'")]+)['"]?\s*\)/g, function (m, p) { return fontUrl[p] ? 'url(' + fontUrl[p] + ')' : m; });
  };
  var pretendardPv = swapFonts(T.pretendardCss);
  // 에디터 화면에도 사이트 글꼴 (글꼴 고르는 버튼을 그 글꼴로 보여 주려고)
  (function () {
    var faces = (T.css.match(/@font-face\s*\{[^}]*\}/g) || []).join('\n');
    var st = document.createElement('style'); st.textContent = pretendardPv + '\n' + swapFonts(faces); document.head.appendChild(st);
  })();

  /* =========================================================
     미리보기
     ========================================================= */
  var pvTimer;
  function schedulePreview(ms) { clearTimeout(pvTimer); pvTimer = setTimeout(renderPreview, ms == null ? 350 : ms); }
  function hasContent() { return !!state.heroBg; }
  function pvEmptyHtml() {
    return MAIN().some(function (x) { return x.kind !== 'form'; }) || state.logo
      ? '<b>히어로 배경 이미지가 있어야 화면이 나와요</b><span>왼쪽 아래 [히어로]에서 배경 이미지를 넣어 주세요.</span>'
      : '<b>현장 폴더 이미지를 한꺼번에 올려 주세요</b><span>로고·히어로·섹션·타입까지 알아서 자리 잡아요. 여기에 끌어다 놓아도 돼요.</span>' +
        '<label class="btn primary" for="file-input">이미지 고르기</label>';
  }
  function renderPreview() {
    if (abOn()) { renderBoards(); return; }
    if (pv.page !== 'main' && pv.page !== 'contact' && !(isMenuMode() && pageBySlug(pv.page))) { pv.page = 'main'; renderPvPages(); }
    var ok = hasContent();
    $('#pv-empty').hidden = ok; $('#pv-frame').hidden = !ok;
    $('#canvas').classList.toggle('is-empty', !ok);
    if (!ok) {
      $('#pv-empty').innerHTML = pvEmptyHtml();
      return;
    }
    var html = renderPage(pv.page, {
      preview: true, intro: pv.intro,
      src: function (im) { return im.url; },
      dims: function (im) { return { w: im.w, h: im.h }; },
      css: pretendardPv + '\n' + swapFonts(siteCss()) + '\n' + PV_FORM_CSS
    });
    var fr = $('#pv-iframe'), y = 0;
    try { y = fr.contentWindow ? fr.contentWindow.scrollY : 0; } catch (e) { y = 0; }
    var keep = pv.keepScroll && !pv.intro;
    fr.onload = function () {
      if (keep && y) { try { fr.contentWindow.scrollTo(0, y); } catch (e) {} }
      postMark(pv.scrollSel); pv.scrollSel = false;
    };
    fr.srcdoc = html;
    pv.intro = false; pv.keepScroll = true;
    layoutPreview();
  }
  // 확대·축소: pv.fit이면 화면에 맞춤, 아니면 pv.zoom 배율. 미리보기 판은 가운데, 크면 스크롤
  var ZOOMS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.9, 1, 1.25, 1.5, 2, 3];
  function pvSize() { return pv.device === 'pc' ? { w: 1440, h: 900 } : { w: 375, h: 812 }; }
  function fitScale() {
    var st = $('#pv-stage'), d = pvSize();
    return clamp(Math.min((st.clientWidth - 64) / d.w, (st.clientHeight - 64) / d.h, 1), 0.2, 1);
  }
  function curScale() { return pv.fit ? fitScale() : pv.zoom; }
  function layoutPreview() {
    var frame = $('#pv-frame'), ifr = $('#pv-iframe'), d = pvSize(), z = curScale();
    ifr.style.width = d.w + 'px'; ifr.style.height = d.h + 'px'; ifr.style.transform = 'scale(' + z + ')';
    frame.style.width = Math.round(d.w * z) + 'px'; frame.style.height = Math.round(d.h * z) + 'px';
    $('#zoom-val').textContent = Math.round(z * 100) + '%';
    $('#zoom-fit').classList.toggle('is-on', !!pv.fit);
    $('#pv-info').textContent = d.w + '×' + d.h + ' · ' + Math.round(z * 100) + '%';
  }
  // 확대·축소 (cx, cy: 화면 기준 고정할 점. 없으면 보이는 가운데)
  function setZoom(z, cx, cy) {
    var st = $('#pv-stage'), frame = $('#pv-frame'), r = st.getBoundingClientRect(), old = curScale();
    z = clamp(Math.round(z * 100) / 100, 0.2, 3);
    if (cx == null) { cx = r.left + st.clientWidth / 2; cy = r.top + st.clientHeight / 2; }
    var px = (st.scrollLeft + cx - r.left - frame.offsetLeft) / old, py = (st.scrollTop + cy - r.top - frame.offsetTop) / old;
    pv.fit = false; pv.zoom = z;
    layoutPreview();
    hintDone();
    st.scrollLeft = frame.offsetLeft + px * z - (cx - r.left);
    st.scrollTop = frame.offsetTop + py * z - (cy - r.top);
  }
  // 확대·이동을 한 번 써 보면 안내 글은 다음부터 안 보임
  function hintDone() {
    var h = $('#cv-hint'); if (!h || h.classList.contains('is-done')) return;
    h.classList.add('is-done');
    try { localStorage.setItem('bunyang-editor-hint', '1'); } catch (e) {}
  }
  try { if (localStorage.getItem('bunyang-editor-hint') === '1') $('#cv-hint').classList.add('is-done'); } catch (e) {}
  function zoomStep(dir) {
    var z = curScale(), next = dir > 0 ? ZOOMS.find(function (v) { return v > z + 0.001; }) : ZOOMS.slice().reverse().find(function (v) { return v < z - 0.001; });
    setZoom(next == null ? z : next);
  }
  function zoomFit() { pv.fit = true; layoutPreview(); var st = $('#pv-stage'); st.scrollLeft = 0; st.scrollTop = 0; }

  /* =========================================================
     패널 그리기
     ========================================================= */
  function setVal(sel, v) { var el = $(sel); if (el && document.activeElement !== el) el.value = v; }
  function renderBasics() {
    setVal('#f-site', state.siteName);
    setVal('#f-title', state.heroTitle);
    setVal('#f-sub', state.heroSub);
    setVal('#f-phone', state.phone);
    setVal('#f-brand', state.brand);
    $('#f-brand-picker').value = normHex(state.brand) || '#001241';
    setVal('#f-folder', state.folder);
    setVal('#f-badge-alt', state.badgeAlt);
    setVal('#f-disc', state.disclaimers);
    setVal('#f-privacy', state.privacyText);
    setVal('#f-third', state.thirdPartyText);
    renderRanges(); renderOnBrand(); renderIntro(); renderMode();
  }
  function renderMode() {
    var mm = isMenuMode();
    $$('#f-mode button, #tb-mode button').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-v') === state.siteMode); });
    $('#mode-note').textContent = mm
      ? (isPcMode() ? 'PC 최적화: 모바일+메뉴형에 더해 홈·방문예약까지 PC에서 넓게 보여요. 히어로와 섹션마다 PC 이미지를 넣으면 PC(가로 768px 이상)에선 그걸로 나오고, 없으면 모바일 이미지가 가운데 좁게 나와요. ' : '') + '모바일+메뉴형: 메인 원페이지는 그대로 두고, 헤더 밑에 메뉴 줄을 달아요. 메뉴마다 따로 된 페이지(주소·이미지·글)를 만들어요. 메뉴 페이지는 PC에서 화면 전체로 넓게 보여요(내용 폭 1200px). 왼쪽 위 버튼은 \'자세히 보기\'(메인으로), PC 오른쪽 메뉴는 그 페이지 섹션으로 이동해요.'
      : '모바일형: 메인 원페이지 하나만 만들어요. 왼쪽 위 메뉴를 누르면 섹션으로 이동해요.';
  }
  var SECS_DESC = null;
  function renderEditBar() {
    var bar = $('#edit-bar');
    var cur = state.editing !== 'main' ? menuPages().find(function (x) { return x.page.id === state.editing; }) : null;
    if (SECS_DESC === null) SECS_DESC = $('#secs-desc').textContent;
    $('#secs-desc').textContent = cur
      ? '\'' + (cur.parent ? cur.parent.name + ' › ' : '') + cur.page.name + '\' 페이지 내용이에요. 왼쪽 목록이나 미리보기에서 섹션을 누르면 여기서 고칠 수 있어요. 맨 위 제목과 맨 밑 폼은 메뉴 페이지 설정대로 들어가요.'
      : SECS_DESC;
    $('#add-form').hidden = !!cur;
    bar.hidden = true;   // 고칠 페이지는 위쪽 페이지 탭으로 골라요
  }
  function editPage(id) {
    state.editing = id;
    relinkEditing();
    var p = state.editing !== 'main' ? findPage(state.editing) : null;
    pv.page = p ? p.slug : 'main'; pv.keepScroll = false;
    curSec = null;
    render();
    setView('sections');
  }
  function menuOf(t) {
    var a = +t.getAttribute('data-m'), c = t.getAttribute('data-c');
    var m = state.menus[a];
    return { m: m, a: a, c: c == null ? null : +c, it: c == null ? m : m.children[+c] };
  }
  function renderMenus() {
    var mm = isMenuMode();
    $('#menus-body').hidden = !mm;
    $('#menus-tag').textContent = mm ? menuPages().length + '쪽' : '';
    if (!mm) return;
    var ed = state.editing;
    var pageLine = function (p, a, c) {
      var n = (p.sections || []).filter(filled).length, at = ' data-m="' + a + '"' + (c != null ? ' data-c="' + c + '"' : ''), on = ed === p.id;
      return '<div class="mp-page' + (on ? ' is-editing' : '') + '"><span class="mp-slug">주소 /<input class="inp" data-act="menu-slug"' + at + ' value="' + esc(p.slug) + '" maxlength="30" aria-label="페이지 주소"></span>' +
        '<span class="mp-count' + (n ? '' : ' is-empty') + '">' + (n ? '섹션 ' + n + '개' : '비어 있음') + '</span>' +
        '<span class="seg small mp-cw" role="group" aria-label="이미지 크기">' + [1200, 860, 375].map(function (w) {
          return '<button type="button" data-act="menu-cw" data-v="' + w + '"' + at + ((p.cw || 1200) === w ? ' class="is-on"' : '') + ' title="' + (w === 375 ? '모바일 이미지 (PC에서도 홈처럼 좁게)' : 'PC에서 내용(이미지) 폭 ' + w + 'px') + '">' + w + '</button>';
        }).join('') + '</span>' +
        '<button class="btn small' + (on ? ' primary' : '') + '" type="button" data-act="menu-edit"' + at + '>' + (on ? '고치는 중' : '내용 고치기') + '</button></div>';
    };
    var tools = function (at, kind) {
      return '<button class="icon" type="button" data-act="menu-up"' + at + ' title="위로">↑</button>' +
        '<button class="icon" type="button" data-act="menu-down"' + at + ' title="아래로">↓</button>' +
        '<button class="icon danger" type="button" data-act="menu-del"' + at + ' title="' + kind + ' 빼기">✕</button>';
    };
    $('#menus').innerHTML = (state.menus || []).map(function (m, a) {
      var kids = m.children || [], at = ' data-m="' + a + '"';
      return '<div class="mp-item"><div class="mp-head"><span class="mp-tag">대메뉴</span>' +
        '<input class="inp" data-act="menu-name"' + at + ' value="' + esc(m.name) + '" maxlength="14" aria-label="대메뉴 이름">' + tools(at, '대메뉴') + '</div>' +
        (kids.length ? '<div class="mp-kids">' + kids.map(function (c, k) {
          var cat = at + ' data-c="' + k + '"';
          return '<div class="mp-kid"><div class="mp-head"><span class="mp-tag sub">소메뉴</span>' +
            '<input class="inp" data-act="menu-name"' + cat + ' value="' + esc(c.name) + '" maxlength="14" aria-label="소메뉴 이름">' + tools(cat, '소메뉴') + '</div>' + pageLine(c, a, k) + '</div>';
        }).join('') + '</div>' : pageLine(m, a, null)) +
        '<div class="mp-foot"><button class="link" type="button" data-act="menu-add-sub"' + at + '>+ 소메뉴 추가</button>' +
        (kids.length ? '<span class="desc">누르면 소메뉴 ' + kids.length + '개가 펼쳐져요</span>' : '<span class="desc">소메뉴가 없으면 누를 때 바로 이 페이지로 가요</span>') + '</div></div>';
    }).join('') || '<div class="desc" style="margin:0">아직 메뉴가 없어요. 아래 \'+ 대메뉴 추가\'로 만들어 주세요.</div>';
    $('#f-menu-contact').checked = state.menuContact !== false;
    $('#f-page-title').checked = state.pageTitle !== false;
    $('#f-page-form').checked = state.pageForm !== false;
  }
  // 보이는 칸 번호를 1부터 차례로 (메뉴 페이지 칸이 숨었다 나타나도)
  function renumberCards() {
    var n = 0;
    $$('#panel > .card').forEach(function (c) { if (c.hidden) return; var no = $('h2 .no', c); if (no) no.textContent = ++n; });
  }
  // 미리볼 페이지: 원페이지만이면 [메인][방문예약], 메뉴 방식이면 고르는 칸
  var CARET = '<svg class="pg-caret" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
  function renderPvPages() {
    var mm = isMenuMode();
    var ok = ['main', 'contact'].concat(mm ? menuPages().map(function (x) { return x.page.slug; }) : []);
    if (ok.indexOf(pv.page) < 0) pv.page = 'main';
    var tab = function (v, name, extra) { return '<button type="button" class="pg' + (v === pv.page ? ' is-on' : '') + '" data-pg="' + esc(v) + '"' + (extra || '') + '>' + esc(name) + '</button>'; };
    var out = [tab('main', '메인'), tab('contact', '방문예약')];
    if (mm) (state.menus || []).forEach(function (m, a) {
      var kids = m.children || [];
      if (!kids.length) { out.push(tab(m.slug, m.name || '새 메뉴')); return; }
      var cur = kids.find(function (c) { return c.slug === pv.page; });
      out.push('<button type="button" class="pg pg-group' + (cur ? ' is-on' : '') + '" data-pg-group="' + a + '" aria-haspopup="menu" title="소메뉴 ' + kids.length + '개">' +
        esc(m.name || '새 메뉴') + (cur ? '<span class="pg-sub">' + esc(cur.name) + '</span>' : '') + CARET + '</button>');
    });
    $('#pg-tabs').innerHTML = out.join('') + '<button type="button" class="pg pg-add" data-pg="+" title="메뉴 페이지 더하기">+ 페이지</button>';
    closePgPop();
  }
  function closePgPop() { var p = $('#pg-pop'); if (p) p.hidden = true; }
  function openPgPop(btn) {
    var m = state.menus[+btn.getAttribute('data-pg-group')], p = $('#pg-pop');
    if (!m || !p) return;
    p.innerHTML = '<div class="pg-pop-head">' + esc(m.name) + '</div>' + (m.children || []).map(function (c) {
      return '<button type="button" class="pg-item' + (c.slug === pv.page ? ' is-on' : '') + '" data-pg="' + esc(c.slug) + '"><b>' + esc(c.name || '새 메뉴') + '</b><span>/' + esc(c.slug) + ' · ' + ((c.sections || []).filter(filled).length ? '섹션 ' + (c.sections || []).filter(filled).length + '개' : '비어 있음') + '</span></button>';
    }).join('');
    var r = btn.getBoundingClientRect();
    p.style.left = Math.round(Math.min(r.left, window.innerWidth - 240)) + 'px'; p.style.top = Math.round(r.bottom + 6) + 'px';
    p.hidden = false;
  }
  function renderIntro() {
    $$('#f-intro button').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-v') === state.introMode); });
    var off = state.introMode === 'none' || (state.introMode === 'logo' && !state.logo);
    var btn = $('#pv-intro');
    btn.disabled = off;
    btn.title = off ? '인트로가 꺼져 있어요 (현장 정보 → 인트로)' : '';
  }
  function renderRanges() {
    Object.keys(RANGES).forEach(function (k) {
      var inp = $('[data-range="' + k + '"]'), out = $('[data-out="' + k + '"]');
      if (inp && document.activeElement !== inp) inp.value = state[k];
      if (out) out.textContent = (RANGES[k] === 'px' ? Math.round(state[k] * 10) / 10 : Number(state[k]).toFixed(1)) + RANGES[k];
    });
  }
  function renderOnBrand() {
    $$('#f-onbrand button').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-v') === state.onBrandMode); });
    var c = $('#f-onbrand-custom');
    c.hidden = state.onBrandMode !== 'custom';
    c.value = normHex(state.onBrandCustom) || '#ffffff';
    var p = $('#ob-prev');
    p.style.background = normHex(state.brand) || '#001241';
    p.style.color = onBrand();
  }
  function renderChips() {
    var cur = normHex(state.brand);
    $('#brand-chips').innerHTML = brandSuggestions().map(function (h) {
      return '<button type="button" class="chip' + (h === cur ? ' is-on' : '') + '" data-act="brand-chip" data-hex="' + h + '" title="' + h + '" style="background:' + h + '"></button>';
    }).join('');
  }
  function renderLogo() {
    var L = state.logo;
    $('#logo-light').innerHTML = L ? '<img src="' + L.url + '" alt="로고">' : '로고 없음';
  }
  function slotHtml(title, im, key, optional) {
    return '<div class="slot" data-drop="slot" data-slot="' + key + '"><div class="cap">' + title + (optional ? ' <span class="desc" style="margin:0">선택</span>' : '') + '</div>' +
      '<div class="pic">' + (im ? '<img src="' + im.url + '" alt="">' : '<span class="empty">없음</span>') + '</div>' +
      '<div class="acts"><label class="btn small">' + (im ? '바꾸기' : '올리기') + '<input type="file" accept="image/*" hidden data-act="slot-set" data-slot="' + key + '"></label>' +
      (im ? '<button class="btn small danger" type="button" data-act="slot-del" data-slot="' + key + '">빼기</button>' : '') + '</div></div>';
  }
  function renderHero() {
    $('#hero-slots').innerHTML = slotHtml(isPcMode() ? '히어로 배경 (모바일)' : '히어로 배경', state.heroBg, 'heroBg', false) +
      slotHtml('배지', state.badge, 'badge', true) +
      (isPcMode() ? slotHtml('PC 히어로 배경 (가로)', state.heroBgPc, 'heroBgPc', true) : '');
  }
  function renderLayers() {
    var nImg = 0, nTxt = 0;
    var range = function (i, k, lab, min, max, step, unit, v) {
      return '<div class="range"><span class="rlab">' + lab + '</span><input type="range" data-layer-range="' + k + '" data-layer="' + i + '" min="' + min + '" max="' + max + '" step="' + step + '" value="' + v + '"><output>' + v + unit + '</output></div>';
    };
    $('#hero-layers').innerHTML = (state.heroLayers || []).map(function (L, i) {
      var isImg = L.kind === 'image';
      var head = '<div class="layer-head"><b>' + (isImg ? '이미지 ' + (++nImg) : '텍스트 ' + (++nTxt)) + '</b><span class="sp"></span>' +
        '<button class="icon" type="button" data-act="layer-up" data-layer="' + i + '" title="위로 (뒤에 깔림)">↑</button>' +
        '<button class="icon" type="button" data-act="layer-down" data-layer="' + i + '" title="아래로 (앞에 얹힘)">↓</button>' +
        '<button class="icon danger" type="button" data-act="layer-del" data-layer="' + i + '" title="빼기">✕</button></div>';
      var body;
      if (isImg) {
        body = '<div class="layer-img" data-drop="layer" data-layer="' + i + '"><div class="pic">' + (L.image ? '<img src="' + L.image.url + '" alt="">' : '<span class="empty">여기로 끌어오기</span>') + '</div>' +
          '<label class="btn small">' + (L.image ? '바꾸기' : '올리기') + '<input type="file" accept="image/*" hidden data-act="layer-img" data-layer="' + i + '"></label></div>' +
          range(i, 'w', '크기', 5, 100, 0.5, '%', L.w) + range(i, 'top', '위아래', 0, 95, 0.1, '%', L.top);
      } else {
        var custom = L.color !== 'brand' && LAYER_COLORS.every(function (c) { return c[0] !== L.color; });
        body = '<textarea class="inp" rows="2" data-layer-key="text" data-layer="' + i + '" placeholder="엔터로 줄바꿈 (예: 선착순 동호지정)">' + esc(L.text) + '</textarea>' +
          '<div class="layer-row"><div class="seg small" role="group" aria-label="글꼴">' + LAYER_FONTS.map(function (f) {
            return '<button type="button" data-act="layer-font" data-v="' + f[0] + '" data-layer="' + i + '" class="lf-' + f[0] + (L.font === f[0] ? ' is-on' : '') + '">' + f[1] + '</button>';
          }).join('') + '</div>' +
          (L.font === 'pretendard' ? '<label class="chk"><input type="checkbox" data-act="layer-bold" data-layer="' + i + '"' + (L.bold ? ' checked' : '') + '>굵게</label>' : '') + '</div>' +
          range(i, 'size', '크기', 10, 64, 0.5, 'px', L.size) + range(i, 'top', '위아래', 0, 95, 0.1, '%', L.top) +
          '<div class="layer-row"><span class="rlab">색</span><div class="seg small" role="group" aria-label="글자 색">' + LAYER_COLORS.map(function (c) {
            return '<button type="button" data-act="layer-color" data-v="' + c[0] + '" data-layer="' + i + '"' + (L.color === c[0] ? ' class="is-on"' : '') + '>' + c[1] + '</button>';
          }).join('') + '<button type="button" data-act="layer-color" data-v="custom" data-layer="' + i + '"' + (custom ? ' class="is-on"' : '') + '>직접</button></div>' +
          (custom ? '<input class="color" type="color" data-layer-key="color" data-layer="' + i + '" value="' + (normHex(L.color) || '#ffffff') + '">' : '') + '</div>';
      }
      return '<div class="layer">' + head + body + '</div>';
    }).join('');
  }
  function thumbHtml(im, i, j) {
    return '<div class="thumb" draggable="true" data-drag="img" data-drop="img" data-sec="' + i + '" data-idx="' + j + '">' +
      '<img src="' + im.url + '" alt="" draggable="false"><span class="nm" title="' + esc(im.name) + '">' + esc(im.name) + '</span>' +
      '<div class="t-acts"><button type="button" data-act="img-left" data-sec="' + i + '" data-idx="' + j + '" title="앞으로">‹</button>' +
      '<button type="button" data-act="img-right" data-sec="' + i + '" data-idx="' + j + '" title="뒤로">›</button>' +
      '<button type="button" data-act="img-del" data-sec="' + i + '" data-idx="' + j + '" title="빼기">✕</button></div></div>';
  }
  function headerSlot(s, i) {
    // 이미지를 끌어다 놓으면 제목 이미지로 (원래 있던 건 맞바꿈), 제목 이미지를 끌어서 목록으로 빼기도 가능
    return '<div class="slot mini" data-drop="header" data-sec="' + i + '"><div class="cap">제목 이미지 <span class="desc" style="margin:0">선택</span></div>' +
      (s.header ? '<div class="pic" draggable="true" data-drag="header" data-sec="' + i + '" title="끌어서 이미지 목록으로 옮길 수 있어요"><img src="' + s.header.url + '" alt="" draggable="false"></div>'
        : '<div class="pic"><span class="empty">여기로 끌어오기</span></div>') +
      '<div class="acts"><label class="btn small">' + (s.header ? '바꾸기' : '올리기') + '<input type="file" accept="image/*" hidden data-act="sec-header" data-sec="' + i + '"></label>' +
      (s.header ? '<button class="btn small danger" type="button" data-act="sec-header-del" data-sec="' + i + '">빼기</button>' : '') + '</div></div>';
  }
  // 섹션 칸 안쪽: 보기 방식 → (제목 이미지) → 이미지 목록 → (슬라이드면 화살표 위치)
  var PICK_IC = {
    img: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/></svg>',
    text: '<svg viewBox="0 0 24 24"><path d="M5 6h14M12 6v13M9 19h6"/></svg>',
    video: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="14" height="14" rx="2"/><path d="M17 10l4-2.5v9L17 14"/></svg>'
  };
  // 섹션 애니메이션 (기본 = 지금처럼 아래에서 살짝 올라오며 나타남)
  var AN_IC = {
    base: '<path d="M12 19V7M7 11l5-5 5 5"/><path d="M5 21h14" opacity=".4"/>', none: '<path d="M6 6l12 12M18 6L6 18"/>',
    fade: '<circle cx="6" cy="6" r="1"/><circle cx="12" cy="6" r="1"/><circle cx="18" cy="6" r="1"/><circle cx="6" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="18" cy="12" r="1"/><circle cx="6" cy="18" r="1"/><circle cx="12" cy="18" r="1"/><circle cx="18" cy="18" r="1"/>',
    scale: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/><rect x="9" y="9" width="6" height="6" rx="1"/>', flip: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M12 2v20" stroke-dasharray="2 2"/>',
    slide: '<path d="M3 7h12M3 12h18M3 17h9"/>', bounce: '<circle cx="9" cy="14" r="5"/><circle cx="15" cy="10" r="5"/>',
    rotate: '<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/>', box: '<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/>',
    flash: '<path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4"/>'
  };
  var ANIMS = [['base', '기본'], ['none', '효과 없음'], ['fade', '페이드인'], ['scale', '스케일'], ['flip', '플립'], ['slide', '슬라이드'], ['bounce', '바운스'], ['rotate', '회전'], ['box', '박스'], ['flash', '플래시']];
  var ANIM_DURS = [0.3, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5];
  var SLIDE_DIRS = [['slide-up', '아래에서'], ['slide-left', '왼쪽에서'], ['slide-right', '오른쪽에서']];
  function animPanel(s, i) {
    var a = s.anim || {}, t = a.type || 'base', key = /^slide/.test(t) ? 'slide' : t, dur = a.dur || 1, di = Math.max(0, ANIM_DURS.indexOf(dur));
    var svg = function (k) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + AN_IC[k] + '</svg>'; };
    return '<div class="anim"><div class="anim-head"><b>애니메이션</b><span>화면에 들어올 때</span></div><div class="anim-grid">' +
      ANIMS.map(function (o) { return '<button type="button" class="anim-btn' + (key === o[0] ? ' is-on' : '') + '" data-act="anim-type" data-v="' + o[0] + '" data-sec="' + i + '">' + svg(o[0]) + o[1] + '</button>'; }).join('') + '</div>' +
      (key === 'slide' ? '<div class="anim-row"><span class="lab">방향</span><div class="seg small">' + SLIDE_DIRS.map(function (d) { return '<button type="button" data-act="anim-dir" data-v="' + d[0] + '" data-sec="' + i + '"' + (t === d[0] ? ' class="is-on"' : '') + '>' + d[1] + '</button>'; }).join('') + '</div></div>' : '') +
      (t === 'base' ? '<p class="note">기본: 아래에서 살짝 올라오며 나타나요 (지금 랜딩 그대로)</p>' : t === 'none' ? '<p class="note">애니메이션 없이 바로 보여요</p>'
        : '<label class="anim-row anim-rep"><span class="lab">반복 설정</span><span class="sw"><input type="checkbox" data-act="anim-rep" data-sec="' + i + '"' + (a.rep ? ' checked' : '') + '><i></i></span></label>' +
          '<div class="range anim-row"><span class="rlab">동작 시간</span><input type="range" min="0" max="8" step="1" value="' + di + '" data-act="anim-dur" data-sec="' + i + '"><output>' + ANIM_DURS[di] + '초</output></div>') +
      '</div>';
  }
  function setAnim(x, patch) {
    var L = state.sections, a = Object.assign({ type: 'base', dur: 1, rep: false }, x.anim || {}, patch);
    groupOf(L, x).forEach(function (m) { m.anim = Object.assign({}, a); });   // 묶음은 같이
  }
  // PC 최적화: 섹션마다 PC 이미지 (세로로 쌓기)
  var pcTab = 'm';
  function pcGrid(s, i) {
    var ims = s.pcImages || [];
    return '<div class="thumbs">' + ims.map(function (im, j) {
      var at = ' data-sec="' + i + '" data-idx="' + j + '"';
      return '<div class="thumb" data-drop="pc-img"' + at + '><img src="' + im.url + '" alt="" draggable="false"><span class="nm" title="' + esc(im.name) + '">' + esc(im.name) + '</span>' +
        '<div class="t-acts"><button type="button" data-act="pc-left"' + at + ' title="앞으로">‹</button><button type="button" data-act="pc-right"' + at + ' title="뒤로">›</button>' +
        '<button type="button" data-act="pc-del"' + at + ' title="빼기">✕</button></div></div>';
    }).join('') + '<label class="thumb add" data-drop="pc-end" data-sec="' + i + '">+ PC 사진<input type="file" accept="image/*" multiple hidden data-act="pc-add" data-sec="' + i + '"></label></div>' +
      (isPcMode() && state.editing === 'main'
        ? '<p class="note">PC 화면(가로 768px 이상)에선 모바일 이미지 대신 이 이미지가 나와요. 가로 1200px 넘는 큰 이미지를 넣어 주세요. 비워 두면 모바일 이미지가 가운데 좁게 나와요.</p>'
        : '<p class="note">PC 넓은 화면(가로 768px 이상)에선 기본 이미지 대신 이 이미지가 나와요. 휴대폰용·PC용 이미지가 따로 있을 때 써요 (기본 이미지엔 휴대폰용). 비워 두면 PC에서도 기본 이미지가 나와요.</p>');
  }
  function pickBody(s, i) {
    return '<div class="sec-pick"><p class="pick-q">이 섹션에 무엇을 넣을까요?</p><div class="pick-grid">' +
      '<label class="pick" data-drop="img-end" data-sec="' + i + '">' + PICK_IC.img + '<b>이미지</b><span>파일 고르기 · 여기로 끌어다 놓기</span><input type="file" accept="image/*" multiple hidden data-act="sec-add" data-sec="' + i + '"></label>' +
      '<button class="pick" type="button" data-act="sec-to" data-v="text" data-sec="' + i + '">' + PICK_IC.text + '<b>글</b><span>제목·안내 문구</span></button>' +
      '<button class="pick" type="button" data-act="sec-to" data-v="video" data-sec="' + i + '">' + PICK_IC.video + '<b>영상</b><span>유튜브 링크 · mp4</span></button>' +
      '</div></div>';
  }
  function sectionBody(s, i, multi) {
    if (!s.images.length && !s.header && !s.join && !multi && !(s.pcImages || []).length) return pickBody(s, i);
    var slide = s.mode === 'slide';
    var pcOn = pcSplitOk(state.editing !== 'main') && !slide;
    var mLab = isPcMode() && state.editing === 'main' ? '모바일 이미지 ' : '기본 이미지 ';
    var pcSeg = pcOn ? '<div class="seg small pc-tabs" role="group" aria-label="이미지 종류"><button type="button" data-act="pc-tab" data-v="m"' + (pcTab === 'm' ? ' class="is-on"' : '') + '>' + mLab + s.images.length + '</button>' +
      '<button type="button" data-act="pc-tab" data-v="pc"' + (pcTab === 'pc' ? ' class="is-on"' : '') + '>PC 이미지 ' + (s.pcImages || []).length + '</button></div>' : '';
    if (pcOn && pcTab === 'pc') return pcSeg + pcGrid(s, i);
    var out = pcSeg + '<div class="sec-opts"><div class="seg small" role="group" aria-label="보기 방식">' +
      '<button type="button" data-act="sec-mode" data-v="stack" data-sec="' + i + '"' + (slide ? '' : ' class="is-on"') + '>세로로 쌓기</button>' +
      '<button type="button" data-act="sec-mode" data-v="slide" data-sec="' + i + '"' + (slide ? ' class="is-on"' : '') + '>슬라이드</button></div>' +
      (slide ? '<label class="chk"><input type="checkbox" data-act="sec-tabs" data-sec="' + i + '"' + (s.tabs ? ' checked' : '') + '>탭 이름 보이기</label>' : '') + '</div>';
    if (slide || s.header) {
      out += '<div class="sec-header">' + headerSlot(s, i) + '<div class="desc" style="margin:0">' +
        (slide ? '제목 이미지는 위에 고정되고, 아래 이미지들이 좌우로 넘어가요.' + (s.tabs ? ' 탭에 보일 이름을 적어 주세요 (빨간 칸은 비었거나 겹침).' : '')
          : '제목 이미지가 맨 위에 먼저 나와요.') + '</div></div>';
    }
    if (slide && s.tabs) {
      var labels = s.images.map(function (im) { return (im.label || '').trim(); });
      out += '<div class="type-list">' + (s.images.map(function (im, j) {
        var bad = !labels[j] || labels.indexOf(labels[j]) !== j;
        return '<div class="type-row" data-drop="img" data-sec="' + i + '" data-idx="' + j + '">' +
          '<img src="' + im.url + '" alt="" draggable="true" data-drag="img" data-sec="' + i + '" data-idx="' + j + '" title="끌어서 순서 변경 · ' + esc(im.name) + '">' +
          '<input class="inp' + (bad ? ' bad' : '') + '" data-act="img-label" data-sec="' + i + '" data-idx="' + j + '" value="' + esc(im.label || '') + '" placeholder="탭 이름 (예: 84A)">' +
          '<div class="acts"><button class="icon" type="button" data-act="img-left" data-sec="' + i + '" data-idx="' + j + '" title="위로">↑</button>' +
          '<button class="icon" type="button" data-act="img-right" data-sec="' + i + '" data-idx="' + j + '" title="아래로">↓</button>' +
          '<button class="icon danger" type="button" data-act="img-del" data-sec="' + i + '" data-idx="' + j + '" title="빼기">✕</button></div></div>';
      }).join('') || '<div class="sec-empty">이미지가 없어요.</div>') + '</div>' +
        '<div class="row" style="margin-top:8px"><label class="btn small" data-drop="img-end" data-sec="' + i + '">+ 이미지 추가<input type="file" accept="image/*" multiple hidden data-act="sec-add" data-sec="' + i + '"></label></div>';
    } else {
      out += (filled(s) ? '' : '<div class="sec-empty">이미지가 없어요. 비어 있으면 페이지에서 빠져요.</div>') +
        '<div class="thumbs">' + s.images.map(function (im, j) { return thumbHtml(im, i, j); }).join('') +
        '<label class="thumb add" data-drop="img-end" data-sec="' + i + '">+ 사진<input type="file" accept="image/*" multiple hidden data-act="sec-add" data-sec="' + i + '"></label></div>';
    }
    if (slide) {
      var auto = s.autoBand ? (s.autoBand * 100).toFixed(1) : '';
      var note = s.band != null ? (s.band > 0 ? '직접 입력' : '띠 없음 → 화살표 가운데') : s.detecting ? '감지 중…' : auto ? '자동 감지' : '띠 없음 → 화살표 가운데';
      out += '<div class="band">이미지 위쪽 띠 높이 <input class="inp" type="number" step="0.1" min="0" max="80" data-act="band" data-sec="' + i + '" value="' +
        (s.band != null ? (s.band * 100).toFixed(1) : '') + '" placeholder="' + (auto || '0') + '">% <span class="desc" style="margin:0">' + note + ' · 0이면 화살표가 가운데</span></div>';
    }
    return out;
  }
  function textBody(s, i) {
    var seg = function (act, list, cur, j, extra) {
      return '<div class="seg small" role="group">' + list.map(function (o) {
        return '<button type="button" data-act="' + act + '" data-v="' + o[0] + '" data-sec="' + i + '"' + (j != null ? ' data-idx="' + j + '"' : '') + ' class="' + (extra ? extra(o[0]) : '') + (cur === o[0] ? ' is-on' : '') + '">' + o[1] + '</button>';
      }).join('') + '</div>';
    };
    var range = function (k, j, lab, min, max, step, unit, v) {
      return '<div class="range"><span class="rlab">' + lab + '</span><input type="range" data-tx-range="' + k + '" data-sec="' + i + '"' + (j != null ? ' data-idx="' + j + '"' : '') +
        ' min="' + min + '" max="' + max + '" step="' + step + '" value="' + v + '"><output>' + v + unit + '</output></div>';
    };
    var bgCustom = s.bg !== 'brand' && TX_BGS.every(function (c) { return c[0] !== s.bg; });
    var out = '<div class="tx-sec-opts"><div class="layer-row"><span class="rlab">배경</span>' + seg('txs-bg', TX_BGS.concat([['custom', '직접']]), bgCustom ? 'custom' : s.bg) +
      (bgCustom ? '<input class="color" type="color" data-tx-key="bg" data-sec="' + i + '" value="' + (normHex(s.bg) || '#ffffff') + '">' : '') + '</div>' +
      range('padY', null, '위아래 여백', 0, 120, 2, 'px', s.padY) + '</div>';
    out += '<div class="layers">' + s.texts.map(function (t, j) {
      var custom = t.color !== 'brand' && TX_COLORS.every(function (c) { return c[0] !== t.color; });
      return '<div class="layer"><div class="layer-head"><b>글 ' + (j + 1) + '</b><span class="sp"></span>' +
        '<button class="icon" type="button" data-act="tx-up" data-sec="' + i + '" data-idx="' + j + '" title="위로">↑</button>' +
        '<button class="icon" type="button" data-act="tx-down" data-sec="' + i + '" data-idx="' + j + '" title="아래로">↓</button>' +
        '<button class="icon danger" type="button" data-act="tx-del" data-sec="' + i + '" data-idx="' + j + '" title="빼기">✕</button></div>' +
        '<textarea class="inp" rows="2" data-tx-key="text" data-sec="' + i + '" data-idx="' + j + '" placeholder="엔터로 줄바꿈">' + esc(t.text) + '</textarea>' +
        '<div class="layer-row">' + seg('tx-font', LAYER_FONTS, t.font, j, function (v) { return 'lf-' + v; }) +
        (t.font === 'pretendard' ? '<label class="chk"><input type="checkbox" data-act="tx-bold" data-sec="' + i + '" data-idx="' + j + '"' + (t.bold ? ' checked' : '') + '>굵게</label>' : '') + '</div>' +
        range('size', j, '크기', 10, 64, 0.5, 'px', t.size) + range('lh', j, '줄 간격', 1, 2.2, 0.05, '', t.lh) + range('gap', j, '아래 간격', 0, 60, 1, 'px', t.gap) +
        '<div class="layer-row"><span class="rlab">정렬</span>' + seg('tx-align', TX_ALIGNS, t.align, j) + '</div>' +
        '<div class="layer-row"><span class="rlab">색</span>' + seg('tx-color', TX_COLORS.concat([['custom', '직접']]), custom ? 'custom' : t.color, j) +
        (custom ? '<input class="color" type="color" data-tx-key="color" data-sec="' + i + '" data-idx="' + j + '" value="' + (normHex(t.color) || '#1a1a1a') + '">' : '') + '</div></div>';
    }).join('') + '</div>' +
      '<div class="row" style="margin-top:8px"><button class="btn small" type="button" data-act="tx-add" data-sec="' + i + '">+ 글 추가</button></div>';
    return out;
  }
  function ytStatus(s) {
    if (!s.ytUrl.trim()) return '<span class="desc" style="margin:0">유튜브 주소를 붙여 넣으세요 (youtu.be/… · youtube.com/watch?v=… · 쇼츠 주소도 돼요)</span>';
    if (/vimeo\.com/i.test(s.ytUrl)) return '<span class="vid-bad">비메오는 사이트에서 재생이 안 돼요. 유튜브 링크나 영상 파일(mp4)로 넣어 주세요</span>';
    if (!s.yt) return '<span class="vid-bad">유튜브 주소를 확인해 주세요</span>';
    return '<span class="vid-ok">영상 ID ' + esc(s.yt) + ' · 사이트엔 youtube-nocookie 주소로 들어가요</span>';
  }
  function videoBody(s, i) {
    var yt = s.vsrc === 'youtube';
    var out = '<div class="sec-opts"><div class="seg small" role="group" aria-label="영상 넣는 방법">' +
      '<button type="button" data-act="vid-src" data-v="youtube" data-sec="' + i + '"' + (yt ? ' class="is-on"' : '') + '>유튜브 링크</button>' +
      '<button type="button" data-act="vid-src" data-v="file" data-sec="' + i + '"' + (yt ? '' : ' class="is-on"') + '>영상 파일</button></div></div>';
    if (yt) {
      out += '<div class="vid-yt"><input class="inp" data-act="vid-url" data-sec="' + i + '" value="' + esc(s.ytUrl) + '" placeholder="https://youtu.be/…">' +
        '<div class="vid-row"><div class="vid-thumb" data-vid-thumb="' + i + '">' + (s.yt ? '<img src="https://img.youtube.com/vi/' + esc(s.yt) + '/hqdefault.jpg" alt="">' : '<span class="empty">미리보기</span>') + '</div>' +
        '<div class="vid-side"><div class="vid-status" data-vid-status="' + i + '">' + ytStatus(s) + '</div>' +
        '<div class="seg small" role="group" aria-label="화면 비율"><button type="button" data-act="vid-ratio" data-v="16:9" data-sec="' + i + '"' + (s.ratio !== '9:16' ? ' class="is-on"' : '') + '>가로 16:9</button>' +
        '<button type="button" data-act="vid-ratio" data-v="9:16" data-sec="' + i + '"' + (s.ratio === '9:16' ? ' class="is-on"' : '') + '>세로 9:16 (쇼츠)</button></div></div></div>' +
        '<div class="note">누르면 그 자리에서 재생돼요. 에디터 미리보기에선 유튜브가 재생을 막을 수 있는데, 올린 사이트에선 돼요.</div></div>';
    } else {
      var f = s.vfile, big = f && f.size > 15 * 1048576;
      out += '<div class="vid-file" data-drop="vfile" data-sec="' + i + '">' +
        '<div class="vid-thumb">' + (f ? '<video src="' + f.url + '"' + (s.poster ? ' poster="' + s.poster.url + '"' : '') + ' muted playsinline preload="metadata"></video>' : '<span class="empty">여기로 영상 파일 끌어오기</span>') + '</div>' +
        '<div class="vid-side">' + (f ? '<div class="vid-info"><b title="' + esc(f.name) + '">' + esc(f.name) + '</b><span' + (big ? ' class="vid-bad"' : '') + '>' + (f.size / 1048576).toFixed(1) + 'MB · ' + mmss(f.duration) + ' · ' + f.w + '×' + f.h + '</span></div>' : '<div class="desc" style="margin:0">mp4·webm만 돼요 (zip 전체 20MB 안)</div>') +
        '<label class="btn small">' + (f ? '영상 바꾸기' : '영상 올리기') + '<input type="file" accept="video/mp4,video/webm" hidden data-act="vid-file" data-sec="' + i + '"></label></div></div>' +
        (big ? '<div class="note vid-bad">영상이 커서 zip이 20MB를 넘을 수 있어요. 유튜브에 올려서 링크로 넣거나 영상을 줄여 주세요.</div>' : '') +
        (f ? '<div class="vid-row"><div class="seg small" role="group" aria-label="재생 방식">' +
          '<button type="button" data-act="vid-play" data-v="0" data-sec="' + i + '"' + (s.autoplay ? '' : ' class="is-on"') + '>눌러서 재생</button>' +
          '<button type="button" data-act="vid-play" data-v="1" data-sec="' + i + '"' + (s.autoplay ? ' class="is-on"' : '') + '>자동 재생 (소리 없이 반복)</button></div>' +
          '<span class="vid-poster">표지 ' + (s.poster ? '<img src="' + s.poster.url + '" alt="">' : '없음') +
          '<label class="link">바꾸기<input type="file" accept="image/*" hidden data-act="vid-poster" data-sec="' + i + '"></label>' +
          (s.posterAuto ? '' : '<button class="link" type="button" data-act="vid-poster-auto" data-sec="' + i + '">첫 장면으로</button>') + '</span></div>' : '');
    }
    out += '<div class="sec-header">' + headerSlot(s, i) + '<div class="desc" style="margin:0">제목 이미지를 넣으면 영상 위에 먼저 나와요.</div></div>';
    return out;
  }
  async function setVideoFile(s, file) {
    if (!/\.(mp4|webm)$/i.test(file.name) && !/^video\/(mp4|webm)$/.test(file.type)) { toast('mp4·webm 영상만 넣을 수 있어요 (리드요 규칙)'); return false; }
    busy('영상 읽는 중…');
    try { var lv = await loadVideo(file, file.name); s.vsrc = 'file'; s.vfile = lv.file; s.poster = lv.poster; s.posterAuto = true; }
    catch (err) { toast(err.message || String(err)); return false; }
    finally { unbusy(); }
    return true;
  }
  var SVG_COPY = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" fill="currentColor"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z"/></svg>';
  var KIND_LABEL = { images: '섹션', text: '섹션', video: '섹션', form: '방문예약 폼' };
  var PART_LABEL = { images: '사진', text: '글', video: '영상' };
  var PART_IC = {
    up: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>',
    down: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M6 13l6 6 6-6"/></svg>'
  };
  // 묶음에 더 넣기 버튼 (사진·글·영상). at: 이 섹션 바로 뒤에
  function partAdd(i, cls) {
    return '<div class="part-add' + (cls ? ' ' + cls : '') + '"><span class="part-add-lab">이 섹션에 더 넣기</span>' +
      '<label class="btn small">+ 사진<input type="file" accept="image/*" multiple hidden data-act="part-img" data-sec="' + i + '"></label>' +
      '<button class="btn small" type="button" data-act="part-add" data-v="text" data-sec="' + i + '">+ 글</button>' +
      '<button class="btn small" type="button" data-act="part-add" data-v="video" data-sec="' + i + '">+ 영상</button></div>';
  }
  function renderSections() {
    fixJoins(state.sections);
    var no = 0, forms = formsOf(state.sections), many = forms.length > 1, sel = curSecIn();
    var grp = sel ? groupOf(state.sections, curSec) : [], last = grp[grp.length - 1];
    $('#panel').classList.toggle('has-sel', sel);
    $('#secs-title').textContent = sel ? KIND_LABEL[curSec.kind] || '섹션' : '섹션';
    $('#secs').innerHTML = state.sections.length ? state.sections.map(function (s, i) {
      var inGrp = grp.indexOf(s) >= 0;
      if (s.join) {
        return '<div class="sec is-part' + (inGrp ? ' is-cur' : '') + (s === curSec && grp.length > 1 ? ' is-focus' : '') + '" data-sec="' + i + '"><div class="part-head">' +
          '<span class="part-kind">' + (PART_LABEL[s.kind] || '내용') + '</span><span class="sp"></span>' +
          '<button class="icon" type="button" data-act="part-up" data-sec="' + i + '" title="위로">' + PART_IC.up + '</button>' +
          '<button class="icon" type="button" data-act="part-down" data-sec="' + i + '" title="아래로">' + PART_IC.down + '</button>' +
          '<button class="icon danger" type="button" data-act="part-del" data-sec="' + i + '" title="이 내용 빼기">✕</button></div>' +
          '<div class="sec-body">' + (s.kind === 'video' ? videoBody(s, i) : s.kind === 'text' ? textBody(s, i) : sectionBody(s, i)) + '</div>' +
          (inGrp && s === last ? partAdd(i) + animPanel(grp[0], state.sections.indexOf(grp[0])) : '') + '</div>';
      }
      if (s.kind === 'form') {
        var k = forms.indexOf(s);
        return '<div class="sec is-form' + (s === curSec ? ' is-cur' : '') + '" data-drop="sec" data-sec="' + i + '"><div class="sec-head">' +
          '<span class="grip" draggable="true" data-drag="sec" data-sec="' + i + '" title="끌어서 위치 변경">⋮⋮</span>' +
          '<span class="sec-no' + (s.nav ? '' : ' off') + '" title="메뉴 번호">' + (s.nav ? pad2(++no) : '–') + '</span>' +
          '<input class="inp" data-act="sec-label" data-sec="' + i + '" value="' + esc(s.label) + '" aria-label="메뉴 이름">' +
          '<label class="chk"><input type="checkbox" data-act="sec-nav" data-sec="' + i + '"' + (s.nav ? ' checked' : '') + '>메뉴</label>' +
          '<button class="icon" type="button" data-act="sec-up" data-sec="' + i + '" title="위로">↑</button>' +
          '<button class="icon" type="button" data-act="sec-down" data-sec="' + i + '" title="아래로">↓</button>' +
          '<button class="icon" type="button" data-act="sec-copy" data-sec="' + i + '" title="복사 (Ctrl+C) → 넣을 자리에서 Ctrl+V">' + SVG_COPY + '</button>' +
          (many ? '<button class="icon danger" type="button" data-act="sec-del" data-sec="' + i + '" title="이 폼 빼기">✕</button>' : '') +
          '</div><div class="sec-body">' + formBody(s, i, k, many) + '</div></div>';
      }
      var onPg = state.editing !== 'main';
      var cOnly = !onPg && whereOf(s) === 'contact';
      var num = cOnly ? '방' : s.nav ? pad2(++no) : '–', pend = s.nav && !cOnly && !groupFilled(state.sections, s), multi = inGrp && grp.length > 1;
      return '<div class="sec' + (cOnly ? ' is-contact' : '') + (inGrp ? ' is-cur' : '') + (multi ? ' is-head' : '') + (s === curSec && multi ? ' is-focus' : '') + '" data-drop="sec" data-sec="' + i + '"><div class="sec-head">' +
        '<span class="grip" draggable="true" data-drag="sec" data-sec="' + i + '" title="끌어서 순서 변경">⋮⋮</span>' +
        '<span class="sec-no' + (num === '–' ? ' off' : '') + (pend ? ' is-pend' : '') + '" title="' + (cOnly ? '방문예약 페이지에만 나와요 (보이는 페이지에서 변경)' : pend ? '내용을 넣으면 이 번호로 메뉴에 나와요' : '메뉴 번호') + '">' + num + '</span>' +
        '<input class="inp" data-act="sec-label" data-sec="' + i + '" value="' + esc(s.label) + '" aria-label="메뉴 이름">' +
        '<label class="chk" title="' + (onPg ? '이 페이지 PC 오른쪽 메뉴에 나와요' : '메뉴에 나와요') + '"><input type="checkbox" data-act="sec-nav" data-sec="' + i + '"' + (s.nav ? ' checked' : '') + '>메뉴</label>' +
        '<button class="icon" type="button" data-act="sec-up" data-sec="' + i + '" title="위로">↑</button>' +
        '<button class="icon" type="button" data-act="sec-down" data-sec="' + i + '" title="아래로">↓</button>' +
        '<button class="icon" type="button" data-act="sec-copy" data-sec="' + i + '" title="복사 (Ctrl+C) → 넣을 자리에서 Ctrl+V">' + SVG_COPY + '</button>' +
        '<button class="icon danger" type="button" data-act="sec-del" data-sec="' + i + '" title="섹션 삭제">✕</button>' +
        '</div>' + (onPg ? '' : '<div class="sec-where"><span class="lab">보이는 페이지</span><div class="seg small" role="group" aria-label="보이는 페이지">' +
          WHERE.map(function (o) { return '<button type="button" data-act="sec-where" data-v="' + o[0] + '" data-sec="' + i + '"' + (whereOf(s) === o[0] ? ' class="is-on"' : '') + '>' + o[1] + '</button>'; }).join('') + '</div></div>') +
        (multi ? '<div class="part-head is-first"><span class="part-kind">' + (PART_LABEL[s.kind] || '내용') + '</span><span class="sp"></span>' +
          '<button class="icon" type="button" data-act="part-down" data-sec="' + i + '" title="아래로">' + PART_IC.down + '</button>' +
          '<button class="icon danger" type="button" data-act="part-del" data-sec="' + i + '" title="이 내용 빼기">✕</button></div>' : '') +
        '<div class="sec-body">' + (s.kind === 'video' ? videoBody(s, i) : s.kind === 'text' ? textBody(s, i) : sectionBody(s, i, multi)) + '</div>' +
        (inGrp && s === last && !(s.kind === 'images' && !s.images.length && !s.header && grp.length === 1) ? partAdd(i) : '') +
        (inGrp && s === last && (filled(s) || grp.length > 1) ? animPanel(grp[0], state.sections.indexOf(grp[0])) : '') + '</div>';
    }).join('') : '<div class="desc" style="margin:0">아직 섹션이 없어요. 이미지를 올리면 자동으로 생겨요.</div>';
  }
  var WHERE = [['main', '메인만'], ['both', '둘 다'], ['contact', '방문예약만']];
  function renderContact() {
    var rows = MAIN().filter(function (s) { return !s.join && groupFilled(MAIN(), s); }).map(function (s) {
      var w = whereOf(s), i = MAIN().indexOf(s);
      return '<div class="where-row"><span class="where-name">' + esc(s.label) + '</span><div class="seg small" role="group" aria-label="' + esc(s.label) + ' 보이는 곳">' +
        WHERE.map(function (o) { return '<button type="button" data-act="sec-where" data-v="' + o[0] + '" data-sec="' + i + '"' + (w === o[0] ? ' class="is-on"' : '') + '>' + o[1] + '</button>'; }).join('') +
        '</div></div>';
    }).join('');
    $('#contact-opts').innerHTML =
      '<label class="chk" style="display:flex;margin:4px 0 10px"><input type="checkbox" data-act="contact-hero"' + (state.contactHero ? ' checked' : '') + '> 폼 아래에 히어로</label>' +
      (rows ? '<div class="where-list">' + rows + '</div>' : '<div class="desc" style="margin:0">섹션이 생기면 여기서 고를 수 있어요.</div>') +
      '<label class="chk" style="display:flex;margin:12px 0 6px"><input type="checkbox" data-act="contact-form-bottom"' + (state.contactFormBottom ? ' checked' : '') + '> 맨 아래에도 방문예약 폼 하나 더</label>';
  }

  function checks() {
    var S = state, out = [], M = MAIN();
    var add = function (lvl, msg) { out.push({ lvl: lvl, msg: msg }); };
    if (S.siteName.trim()) add('ok', '현장명: ' + S.siteName.trim()); else add('err', '현장명을 입력해 주세요');
    flChecks(add);
    if (S.heroBg) add('ok', '히어로 배경 이미지'); else add('err', '히어로 배경 이미지가 없어요 (01_hero)');
    if (isPcMode()) {
      if (S.heroBgPc) add('ok', 'PC 히어로 배경 (가로)'); else add('warn', 'PC 히어로 배경이 없어요. PC에선 모바일 히어로가 가운데 좁게 나와요 (히어로 → PC 히어로 배경)');
      var noPc = MAIN().filter(function (x) { return x.kind === 'images' && x.mode !== 'slide' && filled(x) && !(x.pcImages || []).length; });
      if (noPc.length) add('warn', 'PC 이미지 없는 섹션: ' + noPc.map(function (x) { return x.label; }).join(', ') + ' (PC에선 모바일 이미지가 가운데 좁게 나와요)');
      else add('ok', '섹션 PC 이미지: 다 있어요');
    }
    if (S.logo) add(S.logo.removedWhite ? 'warn' : 'ok', S.logo.removedWhite ? '로고: 흰 배경을 지워서 썼어요. 가장자리가 어색하면 투명 PNG로 바꿔 주세요' : '로고');
    else add('err', '로고를 올려 주세요');
    var p = S.phone.trim();
    if (!p) add('err', '대표번호를 입력해 주세요');
    else if (!/^(\d{4}-?\d{4}|0\d{1,2}-?\d{3,4}-?\d{4})$/.test(p)) add('warn', '대표번호 형식을 확인해 주세요: ' + p);
    else add('ok', '대표번호: ' + p);
    if (!/^[A-Za-z0-9_\-]+$/.test(S.folder)) add('err', 'zip 안 폴더 이름은 영문·숫자·_·- 만 쓸 수 있어요');
    if (!normHex(S.brand)) add('err', '메인 색을 #001241 같은 형식으로 입력해 주세요');
    if (S.badge) add('ok', '히어로 배지'); else add('warn', '히어로 배지가 없어요 (없어도 만들 수 있어요)');
    var layers = S.heroLayers || [];
    if (layers.length) {
      var emptyL = layers.filter(function (L) { return L.kind === 'image' ? !L.image : !String(L.text || '').trim(); });
      add(emptyL.length ? 'warn' : 'ok', '히어로에 더 얹은 것: ' + layers.map(function (L) {
        return L.kind === 'image' ? '이미지' : '텍스트 \'' + (String(L.text || '').trim().split('\n')[0].slice(0, 12) || '빈 칸') + '\'';
      }).join(', ') + (emptyL.length ? ' (비어 있는 ' + emptyL.length + '개는 빠져요)' : ''));
    }
    var INTRO = { both: '로고 + 현장명', logo: '로고만', text: '현장명만', none: '없음' };
    if (S.introMode === 'logo' && !S.logo) add('warn', '인트로: 로고만 골랐는데 로고가 없어서 인트로 없이 나가요');
    else if (S.introMode === 'both' && !S.logo) add('warn', '인트로: 로고가 없어서 현장명만 나와요');
    else add('ok', '인트로: ' + (INTRO[S.introMode] || INTRO.both));
    M.forEach(function (s) {
      if (s.kind === 'text') {
        var nt = (s.texts || []).filter(function (t) { return String(t.text || '').trim(); }).length;
        add(nt ? 'ok' : 'warn', s.label + ': ' + (nt ? '글 ' + nt + '개' : '글이 비어 있어서 빠져요'));
        return;
      }
      if (s.kind !== 'video') return;
      if (s.vsrc === 'youtube') {
        if (s.yt) add('ok', s.label + ': 유튜브 영상 ' + s.yt + (s.ratio === '9:16' ? ' (세로)' : '') + ' · youtube-nocookie 주소로 들어가요');
        else if (s.ytUrl.trim()) add('err', s.label + ': ' + (/vimeo/i.test(s.ytUrl) ? '비메오는 안 돼요. 유튜브 링크나 mp4로 넣어 주세요' : '유튜브 주소를 확인해 주세요'));
        else add('warn', s.label + ': 영상이 비어 있어서 빠져요');
      } else if (s.vfile) {
        var mb = s.vfile.size / 1048576;
        add(mb > 15 ? 'warn' : 'ok', s.label + ': 영상 파일 ' + mb.toFixed(1) + 'MB · ' + mmss(s.vfile.duration) + ' · ' + (s.autoplay ? '자동 재생' : '눌러서 재생') + (mb > 15 ? ' (zip 20MB를 넘을 수 있어요)' : ''));
      } else add('warn', s.label + ': 영상이 비어 있어서 빠져요');
    });
    var imgSecs = M.filter(function (s) { return s.kind === 'images'; });
    var empty = imgSecs.filter(function (s) { return !filled(s); });
    var total = imgSecs.reduce(function (n, s) { return n + s.images.length + (s.header ? 1 : 0); }, 0);
    if (total) add('ok', '섹션 ' + (imgSecs.length - empty.length) + '개 · 이미지 ' + total + '장'); else add('err', '섹션 이미지가 없어요');
    if (empty.length) add('warn', '비어 있어서 빠지는 섹션: ' + empty.map(function (s) { return s.label; }).join(', '));
    M.forEach(function (s) {
      if (s.kind !== 'images' || s.mode !== 'slide' || !s.images.length) return;
      if (!s.tabs) { add('ok', s.label + ': 슬라이드 ' + s.images.length + '장'); return; }
      var labels = s.images.map(function (im) { return (im.label || '').trim(); });
      if (labels.some(function (l) { return !l; })) add('err', s.label + ': 탭 이름이 빈 칸이 있어요 (그 섹션을 눌러서 적어 주세요)');
      else if (labels.some(function (l, k) { return labels.indexOf(l) !== k; })) add('err', s.label + ': 탭 이름이 겹쳐요 (그 섹션을 눌러서 고쳐 주세요)');
      else add('ok', s.label + ': 슬라이드 ' + s.images.length + '장 (' + labels.join(', ') + ')');
    });
    var nav = M.filter(function (s) { return s.nav && filled(s) && onPage(s, false); }).length;
    var forms = formsOf(M);
    var navForms = forms.filter(function (f) { return f.nav; }).map(function (f) { return ' + ' + (f.label.trim() || '방문예약'); }).join('');
    var where = forms.map(function (f) {
      var before = M.slice(0, M.indexOf(f)).filter(filled);
      return before.length ? '\'' + before[before.length - 1].label + '\' 다음' : '히어로 바로 아래';
    });
    add('ok', (isMenuMode() ? 'PC 오른쪽 메뉴: ' : '메뉴: ') + '00 현장명 + 섹션 ' + nav + '개' + navForms);
    forms.forEach(function (fm, fk) {
      var all = fm.fields || [], ok = fieldsOut(fm);
      if (!all.length) return;
      if (ok.length < all.length) add('warn', '방문예약 폼' + (forms.length > 1 ? ' ' + (fk + 1) : '') + ': 추가 항목 ' + (all.length - ok.length) + '개는 질문이나 선택지가 비어서 빠져요');
      if (ok.length) add('ok', '방문예약 폼' + (forms.length > 1 ? ' ' + (fk + 1) : '') + ' 추가 항목: ' + ok.map(function (x) { return x.label; }).join(', ') + (fm.hideMemo ? ' (문의 내용 칸 숨김)' : '') + ' · 답은 리드요 \'문의 내용\'에 담겨요');
    });
    if (!(S.privacyText || '').trim()) add('warn', '개인정보 수집·이용 동의문이 비어 있어요 (개인정보 동의문 칸)');
    else add('ok', '개인정보 동의문: 수집·이용' + ((S.thirdPartyText || '').trim() ? ' + 제3자 제공' : '') + ' 글이 폼 \'내용보기\'에 들어가요');
    add('ok', '방문예약 폼' + (forms.length > 1 ? ' ' + forms.length + '개' : '') + ' 위치: ' + (where.join(', ') || '히어로 바로 아래'));
    add('ok', '방문예약 페이지: 폼' + (S.contactHero ? ' → 히어로' : '') + M.filter(function (s) { return filled(s) && onPage(s, true); }).map(function (s) { return ' → ' + s.label; }).join('') + (S.contactFormBottom ? ' → 폼' : ''));
    var cOnly = M.filter(function (s) { return filled(s) && whereOf(s) === 'contact'; });
    if (cOnly.length) add('ok', '메인엔 없고 방문예약 페이지에만: ' + cOnly.map(function (s) { return s.label; }).join(', '));
    if (isMenuMode()) {
      var mp = menuPages();
      if (!(S.menus || []).length) add('warn', '메뉴 페이지 방식인데 메뉴가 없어요 (메뉴 페이지 칸에서 + 대메뉴 추가)');
      else add('ok', '메뉴: ' + S.menus.map(function (m) { return m.name + (m.children && m.children.length ? '(' + m.children.map(function (c) { return c.name; }).join(', ') + ')' : ''); }).join(' · ') + (S.menuContact !== false ? ' · 방문예약' : ''));
      mp.forEach(function (x) {
        var nm = (x.parent ? x.parent.name + ' › ' : '') + x.page.name, n = (x.page.sections || []).filter(filled).length;
        if (!x.page.name.trim()) add('warn', '이름이 빈 메뉴가 있어요');
        var pcN = (x.page.sections || []).reduce(function (t, sx) { return t + (sx.kind === 'images' && sx.mode !== 'slide' ? (sx.pcImages || []).length : 0); }, 0);
        add(n ? 'ok' : 'warn', nm + ' (/' + x.page.slug + '): ' + (n ? '섹션 ' + n + '개' + (pcN ? ' · PC 이미지 ' + pcN + '장 따로' : '') : '비어 있어요 (내용 고치기로 이미지·글을 넣어 주세요)'));
        var minW = x.page.cw === 375 ? 0 : x.page.cw === 860 ? 800 : 1000;
        var small = (x.page.sections || []).reduce(function (t, sx) { return t + (sx.images || []).filter(function (im) { return im.w < minW; }).length + (sx.header && sx.header.w < minW ? 1 : 0); }, 0);
        if (small) add('warn', nm + ': 가로 ' + minW + 'px 안 되는 이미지 ' + small + '장 (메뉴 페이지는 PC에서 넓게 보여서 흐릿할 수 있어요. PC용 큰 이미지 권장)');
      });
      var slugs = mp.map(function (x) { return x.page.slug; });
      if (slugs.some(function (v, k) { return slugs.indexOf(v) !== k; })) add('err', '주소가 겹치는 메뉴 페이지가 있어요');
    }
    return out;
  }
  function renderChecks() {
    var cs = checks(), bad = cs.filter(function (c) { return c.lvl !== 'ok'; }).length, errN = cs.filter(function (c) { return c.lvl === 'err'; }).length;
    $('#checks').innerHTML = cs.map(function (c) { return '<li class="' + c.lvl + '">' + esc(c.msg) + '</li>'; }).join('');
    var bd = $('#checks-badge'); bd.hidden = !bad; bd.textContent = bad; bd.classList.toggle('is-err', !!errN);
    var cv = $('#cv-checks'); cv.hidden = !bad || !hasContent(); cv.textContent = '확인할 것 ' + bad + '개'; cv.classList.toggle('is-err', !!errN);
    $('#tb-site').textContent = state.siteName.trim() || '현장명 없음';
  }

  function render() {
    renderBasics(); renderChips(); renderLogo(); renderHero(); renderLayers(); renderMenus(); renderEditBar(); renderSections(); renderContact(); renderChecks(); renderPvPages(); renumberCards(); renderTree();
    schedulePreview(120); scheduleAutosave(); scheduleUndo(); teamSiteCheck();
  }
  function changed(opts) {
    opts = opts || {};
    if (opts.sections) renderSections();
    if (opts.contact || opts.sections) { renderContact(); renderPvPages(); if (isMenuMode()) renderMenus(); }
    if (opts.chips) renderChips();
    renderOnBrand(); renderIntro();
    renderChecks(); renderTree();
    if (!(opts.keepBoards && abOn())) schedulePreview(opts.fast ? 120 : 400);
    scheduleAutosave(); scheduleUndo(); teamSiteCheck();
  }

  /* =========================================================
     되돌리기 / 다시 하기 (Ctrl+Z · Ctrl+Shift+Z)
     상태를 글자(JSON)로 찍어 두고, 이미지·영상 파일(blob)은 원래 객체를 가리켜만 둠 (메모리 아낌)
     ========================================================= */
  var UNDO_MAX = 50, UNDO_SKIP = ['sections', 'editing'];   // sections는 지금 고치는 목록의 별칭, editing은 화면 상태라 단계로 안 침
  var undoStack = [], redoStack = [], undoCur = null, undoT = null;
  function freeze(root, skip) {
    var held = [];
    var json = JSON.stringify(root, function (k, v) {
      if (k === 'detecting' || k === 'dbKey') return undefined;
      if (skip && this === root && skip.indexOf(k) >= 0) return undefined;
      if (v && typeof v === 'object' && v.blob instanceof Blob) {
        var o = { $f: held.push(v) - 1 };
        Object.keys(v).forEach(function (x) { if (x !== 'blob' && x !== 'url' && x !== 'dbKey') o[x] = v[x]; });
        return o;
      }
      return v;
    });
    return { json: json, held: held };
  }
  // fresh: 붙여넣기용 (이미지 id 새로)
  function thaw(fz, fresh) {
    return JSON.parse(fz.json, function (k, v) {
      if (v && typeof v === 'object' && v.$f != null) {
        var src = fz.held[v.$f];
        delete v.$f; v.blob = src.blob; v.url = src.url;
        if (src.dbKey) v.dbKey = src.dbKey;
        if (fresh) v.id = uid();
        return v;
      }
      return v;
    });
  }
  function undoSnap() { return freeze(state, UNDO_SKIP); }
  // 글자 치기·슬라이더·색 고르기는 멈춘 뒤 한 단계로, 버튼·끌어 옮기기는 바로 한 단계
  function scheduleUndo() {
    var el = document.activeElement, slow = !!el && (el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable || (el.tagName === 'INPUT' && !/^(checkbox|radio|button|submit|file)$/i.test(el.type)));
    clearTimeout(undoT); undoT = setTimeout(captureUndo, slow ? 500 : 0); renderUndo();
  }
  function captureUndo() {
    clearTimeout(undoT); undoT = null;
    var snap = undoSnap();
    if (!undoCur) undoCur = snap;
    else if (snap.json !== undoCur.json) {
      undoStack.push(undoCur);
      if (undoStack.length > UNDO_MAX) undoStack.shift();
      undoCur = snap; redoStack = [];
    }
    renderUndo();
  }
  // 저장본·zip을 불러오면 되돌리기는 거기서부터 새로
  function undoReset() { clearTimeout(undoT); undoT = null; undoStack = []; redoStack = []; undoCur = undoSnap(); renderUndo(); }
  function undoStep(dir) {
    if (undoT) captureUndo();   // 방금 고친 것까지 한 단계로 묶고 나서
    var from = dir < 0 ? undoStack : redoStack, to = dir < 0 ? redoStack : undoStack;
    if (!from.length) { toast(dir < 0 ? '더 되돌릴 게 없어요' : '다시 할 게 없어요'); return; }
    to.push(undoCur);
    undoCur = from.pop();
    var editing = state.editing, keepId = curSec ? curSec.id : null;
    state = Object.assign(freshState(), thaw(undoCur));
    state.editing = editing;   // 고치던 페이지는 그대로 (그 페이지가 없어졌으면 메인)
    relinkEditing();
    curSec = keepId ? state.sections.find(function (x) { return x.id === keepId; }) || null : null;   // 고르던 섹션은 그대로
    render();
    clearTimeout(undoT); undoT = null;
    undoCur = undoSnap();
    renderUndo();
    toast(dir < 0 ? '되돌렸어요' : '다시 했어요');
  }
  function renderUndo() {
    var u = $('#undo-btn'), r = $('#redo-btn');
    if (u) u.disabled = !(undoStack.length || undoT);
    if (r) r.disabled = !redoStack.length;
  }

  /* 섹션 복사 / 붙여넣기: 고른 섹션 바로 아래에 (안 골랐으면 맨 아래 폼 위에). 메뉴 페이지를 바꿔도 복사한 건 남아 있음 */
  var secClip = null, curSec = null;
  function curSecIn() { return !!curSec && state.sections.indexOf(curSec) >= 0; }
  function copySec(sec) {
    var g = groupOf(state.sections, sec);
    secClip = { fz: freeze(g), label: g[0].label || '섹션' };
    renderPasteBtn();
    toast('\'' + secClip.label + '\' 섹션을 복사했어요. 넣을 자리 바로 위 섹션을 누르고 Ctrl+V (다른 메뉴 페이지에도 돼요)');
  }
  function pasteSec() {
    if (!secClip) return;
    var got = thaw(secClip.fz, true), list = Array.isArray(got) ? got : [got], sec = list[0], L = state.sections;
    list.forEach(function (m) { m.id = m.kind === 'form' ? formId() : uniqueId(String(m.id || '').replace(/-\d+$/, '') || 's-custom'); });
    if (curSecIn()) { var cg = groupOf(L, curSec); L.splice.apply(L, [L.indexOf(cg[cg.length - 1]) + 1, 0].concat(list)); }
    else list.forEach(function (m, k) { if (!k) pushSection(m); else L.splice(L.indexOf(list[k - 1]) + 1, 0, m); });
    curSec = sec;
    changed({ sections: true, contact: true });
    selectSec(sec, true);
    toast('\'' + (sec.label || '섹션') + '\' 섹션을 붙여넣었어요');
  }
  function renderPasteBtn() {
    var b = $('#paste-sec');
    if (!b) return;
    b.hidden = !secClip;
    if (secClip) b.textContent = '붙여넣기 · ' + secClip.label;
  }
  // 누른 섹션 = 붙여넣을 기준 (Ctrl+C도 이 섹션)
  function markCurSec(card) {
    var nx = card ? state.sections[+card.getAttribute('data-sec')] || null : null;
    if (nx === curSec) return;
    curSec = nx;
    $$('#secs .sec').forEach(function (el) { el.classList.toggle('is-cur', el === card); });
    renderTree(); postMark(false);
  }
  function isTyping(el) {
    if (!el || !el.tagName) return false;
    if (el.isContentEditable || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') return true;
    return el.tagName === 'INPUT' && !/^(checkbox|radio|range|color|file|button|submit)$/i.test(el.type);
  }
  function undoKeys(e) {
    if (!(e.ctrlKey || e.metaKey) || e.altKey || !$('#modal').hidden) return;
    var k = e.code;   // 한글 입력 상태에서도 같은 키 (e.key는 'ㅋ'이 됨)
    if (k !== 'KeyZ' && k !== 'KeyY' && k !== 'KeyC' && k !== 'KeyV') return;
    if (isTyping(e.target)) return;   // 글 쓰는 칸 안에서는 그 칸의 기본 동작 (글자 되돌리기·복사·붙여넣기)
    if (k === 'KeyZ' || k === 'KeyY') { e.preventDefault(); undoStep(k === 'KeyY' || e.shiftKey ? 1 : -1); return; }
    if (e.shiftKey) return;
    if (k === 'KeyC') {
      if (String(window.getSelection() || '').trim() || !curSecIn()) return;   // 글자를 고른 상태면 글자 복사
      e.preventDefault(); copySec(curSec);
    } else if (secClip) { e.preventDefault(); pasteSec(); }
  }
  document.addEventListener('keydown', undoKeys);

  /* =========================================================
     입력 이벤트
     ========================================================= */
  var panel = $('#panel');

  panel.addEventListener('input', function (e) {
    var t = e.target, key = t.getAttribute('data-key'), act = t.getAttribute('data-act');
    if (key) {
      state[key] = t.value;
      if (key === 'heroTitle') state.titleAuto = !t.value.trim();
      if (key === 'siteName' && state.titleAuto) { state.heroTitle = splitTitle(t.value); setVal('#f-title', state.heroTitle); }
      if (key === 'brand') { state.brandTouched = true; var h = normHex(t.value); if (h) $('#f-brand-picker').value = h; changed({ chips: true }); return; }
      changed();
      return;
    }
    if (t.id === 'f-brand-picker') { state.brand = t.value; state.brandTouched = true; setVal('#f-brand', t.value); changed({ chips: true, fast: true }); return; }
    if (t.hasAttribute('data-layer-range') || t.hasAttribute('data-layer-key')) {
      var L = state.heroLayers[+t.getAttribute('data-layer')], lk = t.getAttribute('data-layer-range') || t.getAttribute('data-layer-key');
      if (t.hasAttribute('data-layer-range')) { L[lk] = parseFloat(t.value); t.nextElementSibling.textContent = t.value + (lk === 'size' ? 'px' : '%'); }
      else L[lk] = t.value;
      changed({ fast: true }); return;
    }
    var rk = t.getAttribute('data-range');
    if (rk) { state[rk] = parseFloat(t.value); if (rk === 'logoW') state.logoWTouched = true; renderRanges(); changed({ fast: true }); return; }
    if (t.id === 'f-onbrand-custom') { state.onBrandCustom = t.value; changed({ fast: true }); return; }
    var si = +t.getAttribute('data-sec'), s = state.sections[si];
    if (act === 'sec-label') { s.label = t.value; groupOf(state.sections, s).forEach(function (m) { if (m.join) m.label = t.value; }); changed({ contact: true }); renderTree(); return; }
    if (t.hasAttribute('data-tx-range') || t.hasAttribute('data-tx-key')) {
      var txi = t.getAttribute('data-idx'), TT = txi == null ? s : s.texts[+txi];
      var txk = t.getAttribute('data-tx-range') || t.getAttribute('data-tx-key');
      if (t.hasAttribute('data-tx-range')) { TT[txk] = parseFloat(t.value); t.nextElementSibling.textContent = t.value + (txk === 'lh' ? '' : 'px'); }
      else TT[txk] = t.value;
      changed({ contact: txk === 'text' }); return;
    }
    if (act === 'vid-url') {
      s.ytUrl = t.value; s.yt = /vimeo\.com/i.test(t.value) ? '' : ytId(t.value);
      if (/\/shorts\//.test(t.value)) s.ratio = '9:16';
      var st = $('[data-vid-status="' + si + '"]'), th = $('[data-vid-thumb="' + si + '"]');
      if (st) st.innerHTML = ytStatus(s);
      if (th) th.innerHTML = s.yt ? '<img src="https://img.youtube.com/vi/' + esc(s.yt) + '/hqdefault.jpg" alt="">' : '<span class="empty">미리보기</span>';
      $$('[data-act="vid-ratio"][data-sec="' + si + '"]').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-v') === s.ratio); });
      changed({ contact: true }); return;
    }
    if (act === 'img-label') {
      s.images[+t.getAttribute('data-idx')].label = t.value;
      var labels = s.images.map(function (im) { return (im.label || '').trim(); });
      $$('[data-act="img-label"][data-sec="' + si + '"]').forEach(function (inp, j) { inp.classList.toggle('bad', !labels[j] || labels.indexOf(labels[j]) !== j); });
      changed(); return;
    }
    if (act === 'band') { var v = parseFloat(t.value); s.band = isNaN(v) ? null : clamp(v, 0, 80) / 100; changed(); return; }
  });

  panel.addEventListener('change', async function (e) {
    var t = e.target, act = t.getAttribute('data-act');
    if (t.id === 'file-input') { await addFiles(t.files); t.value = ''; return; }
    if (t.id === 'logo-input') {
      if (!t.files[0]) return;
      busy('로고 정리 중…');
      try { setLogo(await processLogo(t.files[0], t.files[0].name)); } finally { unbusy(); }
      t.value = ''; renderLogo(); renderRanges(); changed(); return;
    }
    var si = +t.getAttribute('data-sec'), s = state.sections[si];
    if (act === 'sec-nav') { s.nav = t.checked; changed({ sections: true }); return; }
    if (act === 'sec-add' && t.files.length) { await addFiles(t.files, { sec: si }); t.value = ''; return; }
    if (act === 'part-img' && t.files.length) { var pf = Array.prototype.slice.call(t.files); t.value = ''; await partImages(s, pf); return; }
    if (act === 'layer-img' && t.files[0]) {
      state.heroLayers[+t.getAttribute('data-layer')].image = await loadImg(t.files[0], t.files[0].name);
      t.value = ''; renderLayers(); changed({ fast: true }); return;
    }
    if (act === 'layer-bold') { state.heroLayers[+t.getAttribute('data-layer')].bold = t.checked; changed({ fast: true }); return; }
    if (act === 'slot-set' && t.files[0]) {
      var im = await loadImg(t.files[0], t.files[0].name);
      state[t.getAttribute('data-slot')] = im;
      t.value = ''; renderHero(); changed({ contact: true, fast: true }); return;
    }
    if (act === 'sec-tabs') { s.tabs = t.checked; changed({ sections: true }); return; }
    if (act === 'tx-bold') { s.texts[+t.getAttribute('data-idx')].bold = t.checked; changed({ fast: true }); return; }
    if (act === 'vid-file' && t.files[0]) { var vf = t.files[0]; t.value = ''; if (await setVideoFile(s, vf)) changed({ sections: true, contact: true }); return; }
    if (act === 'vid-poster' && t.files[0]) { s.poster = await loadImg(t.files[0], t.files[0].name); s.posterAuto = false; t.value = ''; changed({ sections: true }); return; }
    if (act === 'sec-header' && t.files[0]) {
      s.header = await loadImg(t.files[0], t.files[0].name);
      t.value = ''; changed({ sections: true, chips: true }); return;
    }
    if (act === 'contact-hero') { state.contactHero = t.checked; changed(); return; }
    if (act === 'contact-form-bottom') { state.contactFormBottom = t.checked; changed(); return; }
  });

  // 슬라이드 첫 이미지가 바뀌면 띠 높이를 다시 감지
  var redetect = function (s) { if (s.mode === 'slide') { s.autoBand = null; afterImagesChanged(); } };
  var move = function (arr, from, to) { if (to < 0 || to >= arr.length) return; arr.splice(to, 0, arr.splice(from, 1)[0]); };
  panel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]');
    if (!b || b.tagName === 'INPUT') return;
    var act = b.getAttribute('data-act'), si = +b.getAttribute('data-sec'), j = +b.getAttribute('data-idx'), s = state.sections[si];
    if (act === 'go-privacy') { setView('privacy'); return; }
    if (/^lf-/.test(act) || act === 'sec-to' || /^part-/.test(act) || /^anim-/.test(act) || /^pc-/.test(act)) return;   // 폼 추가 항목·섹션 내용 고르기·묶음·애니메이션·PC 이미지는 따로
    if (act === 'sec-where') s = MAIN()[si];   // 5번 칸은 늘 메인 원페이지 섹션
    switch (act) {
      case 'brand-chip': state.brand = b.getAttribute('data-hex'); state.brandTouched = true; renderBasics(); changed({ chips: true, fast: true }); return;
      case 'sec-copy': copySec(s); return;
      case 'sec-up': moveGroup(state.sections, s, -1); break;
      case 'sec-down': moveGroup(state.sections, s, 1); break;
      case 'sec-del': if (!deleteSec(s)) return; break;
      case 'img-left': move(s.images, j, j - 1); if (j <= 1) redetect(s); break;
      case 'img-right': move(s.images, j, j + 1); if (j === 0) redetect(s); break;
      case 'img-del': s.images.splice(j, 1); if (j === 0) redetect(s); break;
      case 'sec-mode': s.mode = b.getAttribute('data-v'); afterImagesChanged(); break;
      case 'vid-src': s.vsrc = b.getAttribute('data-v'); break;
      case 'tx-font': s.texts[j].font = b.getAttribute('data-v'); break;
      case 'tx-align': s.texts[j].align = b.getAttribute('data-v'); break;
      case 'tx-color': var tc = b.getAttribute('data-v'); s.texts[j].color = tc === 'custom' ? '#2f6fed' : tc; break;
      case 'txs-bg': var bgv = b.getAttribute('data-v'); s.bg = bgv === 'custom' ? '#f4f1ea' : bgv; break;
      case 'tx-up': move(s.texts, j, j - 1); break;
      case 'tx-down': move(s.texts, j, j + 1); break;
      case 'tx-del': s.texts.splice(j, 1); break;
      case 'tx-add':
        var lastT = s.texts[s.texts.length - 1];
        s.texts.push(newTextItem(lastT ? { font: lastT.font, bold: lastT.bold, size: lastT.size, color: lastT.color, align: lastT.align, lh: lastT.lh } : {}));
        break;
      case 'vid-ratio': s.ratio = b.getAttribute('data-v'); break;
      case 'vid-play': s.autoplay = b.getAttribute('data-v') === '1'; break;
      case 'vid-poster-auto':
        if (s.vfile) { loadVideo(s.vfile.blob, s.vfile.name).then(function (lv) { s.poster = lv.poster; s.posterAuto = true; changed({ sections: true }); }); }
        return;
      case 'sec-where':
        freezeWhere(); s.where = b.getAttribute('data-v');
        groupOf(MAIN(), s).forEach(function (m) { m.where = s.where; });   // 묶음은 같이
        if (s.where === 'contact' && pv.page !== 'contact') {   // 방문예약만으로 바꾸면 미리보기도 그 페이지로
          pv.page = 'contact';
          renderPvPages();
        }
        break;
      case 'sec-header-del': s.header = null; break;
      case 'layer-font': case 'layer-color': case 'layer-up': case 'layer-down': case 'layer-del':
        var li = +b.getAttribute('data-layer'), LL = state.heroLayers[li], v = b.getAttribute('data-v');
        if (act === 'layer-font') LL.font = v;
        else if (act === 'layer-color') LL.color = v === 'custom' ? (LL.color === 'brand' ? normHex(state.brand) || '#ffffff' : '#ffd84d') : v;
        else if (act === 'layer-del') state.heroLayers.splice(li, 1);
        else move(state.heroLayers, li, act === 'layer-up' ? li - 1 : li + 1);
        renderLayers(); changed({ fast: true }); return;
      case 'slot-del': state[b.getAttribute('data-slot')] = null; renderHero(); changed({ contact: true, fast: true }); return;
      default: return;
    }
    changed({ sections: true, chips: true, fast: true });
  });

  function setMode(v) {
    var was = state.siteMode;
    state.siteMode = v;
    if (isMenuMode() && !(state.menus || []).length) starterMenus();
    if (!isMenuMode() && state.editing !== 'main') { editPage('main'); return; }
    if (!isMenuMode() && pv.page !== 'main' && pv.page !== 'contact') pv.page = 'main';
    render();
    if (v !== 'single' && was === 'single') setView('menus');   // 처음 켜면 메뉴 만드는 칸을 보여 줌
    if (v === 'pc' && was !== 'pc') toast('PC 최적화: PC에서 모든 페이지가 넓게 보여요. 섹션마다 PC 이미지를 넣으면 PC에선 그걸로 나와요');
  }
  $('#f-mode').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) setMode(b.getAttribute('data-v')); });
  $('#tb-mode').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) setMode(b.getAttribute('data-v')); });
  $('#menu-card').addEventListener('input', function (e) {
    var t = e.target; if (t.getAttribute('data-act') !== 'menu-name') return;
    var r = menuOf(t); r.it.name = t.value;
    if (r.it.slugAuto !== false && !(r.it.children && r.it.children.length)) {   // 주소를 직접 안 바꿨으면 이름 따라 바뀜
      setAutoSlug(r.it);
      var sl = t.closest('.mp-kid, .mp-item').querySelector('[data-act="menu-slug"]');
      if (sl) sl.value = r.it.slug;
    }
    renderEditBar(); renderPvPages(); changed();
  });
  $('#menu-card').addEventListener('change', function (e) {
    var t = e.target;
    if (t.id === 'f-menu-contact') { state.menuContact = t.checked; changed(); return; }
    if (t.id === 'f-page-title') { state.pageTitle = t.checked; changed(); return; }
    if (t.id === 'f-page-form') { state.pageForm = t.checked; changed(); return; }
    if (t.getAttribute('data-act') !== 'menu-slug') return;
    var r = menuOf(t);
    r.it.slug = uniqueSlug(t.value || autoSlug(r.it.name), r.it); r.it.slugAuto = false; t.value = r.it.slug;
    if (state.editing === r.it.id) pv.page = r.it.slug;
    renderEditBar(); renderPvPages(); changed();
  });
  $('#menu-card').addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]'); if (!b || b.tagName === 'INPUT') return;
    var act = b.getAttribute('data-act'); if (!/^menu-/.test(act)) return;
    var r = menuOf(b), list = r.c == null ? state.menus : r.m.children, idx = r.c == null ? r.a : r.c;
    if (act === 'menu-cw') { r.it.cw = +b.getAttribute('data-v'); renderMenus(); changed(); return; }
    if (act === 'menu-edit') { editPage(r.it.id); var sc = $('#secs'); if (sc) sc.closest('.card').scrollIntoView({ block: 'start', behavior: 'smooth' }); return; }
    if (act === 'menu-up') move(list, idx, idx - 1);
    else if (act === 'menu-down') move(list, idx, idx + 1);
    else if (act === 'menu-del') {
      var inner = (r.it.children || []).concat([r.it]), n = inner.reduce(function (t, p) { return t + (p.sections || []).filter(filled).length; }, 0);
      if (n && !confirm('"' + r.it.name + '"과(와) 안에 넣은 섹션 ' + n + '개를 뺄까요?')) return;
      if (inner.some(function (p) { return p.id === state.editing; })) state.editing = 'main';
      list.splice(idx, 1);
      if (r.c != null && !r.m.children.length) { r.m.sections = []; r.m.slugAuto = true; setAutoSlug(r.m); }   // 소메뉴가 다 빠지면 대메뉴가 다시 페이지
    } else if (act === 'menu-add-sub') {
      var m = r.m; m.children = m.children || [];
      if (!m.children.length) {
        // 대메뉴가 페이지였으면 그 내용을 첫 소메뉴로 옮김 (넣은 게 없으면 빈 소메뉴 하나)
        var had = (m.sections || []).some(filled);
        var first = had ? { id: m.id + 'c', name: m.name, slug: m.slug, slugAuto: m.slugAuto, sections: m.sections } : newMenuPage('소메뉴 1');
        if (state.editing === m.id) state.editing = first.id;
        m.sections = []; m.slug = '';
        m.children.push(first);
        if (!had) setAutoSlug(first);
      } else { var c = newMenuPage('소메뉴 ' + (m.children.length + 1)); m.children.push(c); setAutoSlug(c); }
    }
    relinkEditing();
    render();
  });
  $('#add-menu').addEventListener('click', function () {
    var p = newMenuPage('새 메뉴'); state.menus.push(p); setAutoSlug(p);
    render();
    var inp = $$('#menus [data-act="menu-name"]').pop(); if (inp) { inp.focus(); inp.select(); }
  });
  $('#edit-bar').addEventListener('change', function (e) { if (e.target.id === 'edit-page') editPage(e.target.value); });
  $('#edit-bar').addEventListener('click', function (e) { if (e.target.id === 'edit-main') editPage('main'); });
  $('#f-intro').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    state.introMode = b.getAttribute('data-v');
    renderIntro(); renderChecks();
    if (!$('#pv-intro').disabled) $('#pv-intro').click();   // 고른 인트로를 바로 보여 주기
    else schedulePreview(120);
  });
  $('#f-onbrand').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    state.onBrandMode = b.getAttribute('data-v');
    changed({ fast: true });
  });
  $('#hero-reset').addEventListener('click', function () {
    Object.keys(HERO_DEFAULTS).forEach(function (k) { state[k] = HERO_DEFAULTS[k]; });
    renderRanges(); changed({ fast: true });
  });
  $('#privacy-reset').addEventListener('click', function () {
    if (!confirm('개인정보 동의문 두 개를 핏톡 기본 문구로 되돌릴까요?')) return;
    state.privacyText = DEFAULT_PRIVACY; state.thirdPartyText = DEFAULT_THIRD;
    setVal('#f-privacy', state.privacyText); setVal('#f-third', state.thirdPartyText);
    changed(); toast('핏톡 기본 문구로 되돌렸어요');
  });
  $('#title-auto').addEventListener('click', function () {
    state.heroTitle = splitTitle(state.siteName); state.titleAuto = true; renderBasics(); changed();
  });
  $('#paste-sec').addEventListener('click', pasteSec);
  $('#undo-btn').addEventListener('click', function () { undoStep(-1); });
  $('#redo-btn').addEventListener('click', function () { undoStep(1); });
  panel.addEventListener('mousedown', function (e) {
    if (!e.target.closest) return;
    var card = e.target.closest('#secs .sec');
    if (card) markCurSec(card);
  });
  panel.addEventListener('focusin', function (e) { var card = e.target.closest && e.target.closest('#secs .sec'); if (card) markCurSec(card); });
  $('#add-sec').addEventListener('click', function () {
    var ns = pushSection(newSection({ id: uniqueId('s-custom') }));
    changed({ sections: true });
    selectSec(ns, true);
    var el = $('#secs .sec.is-cur [data-act="sec-label"]'); if (el) el.select();
  });
  $('#add-layer-img').addEventListener('change', async function (e) {
    var f = e.target.files[0]; if (!f) return;
    state.heroLayers.push(newLayer('image', { image: await loadImg(f, f.name) }));
    e.target.value = ''; renderLayers(); changed({ fast: true });
  });
  $('#add-layer-text').addEventListener('click', function () {
    state.heroLayers.push(newLayer('text'));
    renderLayers(); changed({ fast: true });
    var ta = $$('#hero-layers textarea').pop(); if (ta) ta.focus();
  });
  $('#add-text').addEventListener('click', function () {
    var ts = textSection();
    pushSection(ts);
    changed({ sections: true });
    selectSec(ts, true);
    var ta = $('#secs .sec.is-cur textarea'); if (ta) ta.focus();
  });
  $('#add-video').addEventListener('click', function () {
    var v = videoSection();
    pushSection(v);
    changed({ sections: true });
    selectSec(v, true);
    var inp = $('#secs .sec.is-cur [data-act="vid-url"]'); if (inp) inp.focus();
  });
  $('#add-form').addEventListener('click', function () {
    var f = formItem(false, '방문예약', formId());
    pushSection(f);
    changed({ sections: true });
    selectSec(f, true);
    toast('폼 칸을 하나 더 넣었어요. 왼쪽 목록에서 끌어서 원하는 위치로 옮기세요');
  });

  // 끌어서 옮기기 (섹션 / 이미지 / 타입)
  var drag = null;
  panel.addEventListener('dragstart', function (e) {
    var el = e.target.closest && e.target.closest('[data-drag]');
    if (!el) return;
    drag = { kind: el.getAttribute('data-drag'), sec: +el.getAttribute('data-sec'), idx: +el.getAttribute('data-idx') };
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', drag.kind);
    if (drag.kind === 'sec') e.dataTransfer.setDragImage(el.closest('.sec'), 20, 20);
  });
  var dropTarget = function (e) {
    if (!drag || !e.target.closest) return null;
    if (drag.kind === 'sec') return e.target.closest('[data-drop="sec"]');   // 섹션은 칸 안 어디에 놓아도
    var t = e.target.closest('[data-drop]');
    if (!t) return null;
    var k = t.getAttribute('data-drop');
    if (drag.kind === 'sec' && k === 'sec') return t;
    if (drag.kind === 'img' || drag.kind === 'header') {
      if (k === 'img' || k === 'img-end') return t;
      if (k === 'sec' && state.sections[+t.getAttribute('data-sec')].kind === 'images') return t;
      if (k === 'header' && !(drag.kind === 'header' && +t.getAttribute('data-sec') === drag.sec)) return t;
      if ((k === 'slot' || k === 'layer') && drag.kind === 'img') return t;
    }
    return null;
  };
  // 바탕화면 파일을 끌고 올 때 놓을 수 있는 칸 표시
  var fileDrag = function (e) { return !drag && e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0; };
  panel.addEventListener('dragover', function (e) {
    if (fileDrag(e)) {
      var ft = e.target.closest && e.target.closest('[data-drop="pc-end"], [data-drop="pc-img"], [data-drop="header"], [data-drop="slot"], [data-drop="vfile"], [data-drop="layer"], .logo-box, [data-drop="img-end"], [data-drop="img"], .sec.is-cur .sec-body');
      if (ft && ft.classList.contains('sec-body')) { var fs0 = state.sections[+ft.closest('.sec').getAttribute('data-sec')]; if (!fs0 || fs0.kind !== 'images') ft = null; }
      $$('.is-drag-over').forEach(function (x) { if (x !== ft) x.classList.remove('is-drag-over'); });
      if (ft) { e.preventDefault(); ft.classList.add('is-drag-over'); }
      return;
    }
    var t = dropTarget(e);
    if (!t) return;
    e.preventDefault();
    $$('.is-drag-over').forEach(function (x) { if (x !== t) x.classList.remove('is-drag-over'); });
    t.classList.add('is-drag-over');
  });
  panel.addEventListener('dragleave', function (e) {
    var t = e.target.closest && e.target.closest('.is-drag-over');
    if (t && !t.contains(e.relatedTarget)) t.classList.remove('is-drag-over');
  });
  panel.addEventListener('drop', async function (e) {
    // 바탕화면에서 파일을 히어로·배지·이벤트 칸이나 로고 칸에 바로 떨어뜨린 경우
    if (!drag && e.dataTransfer && e.dataTransfer.files.length) {
      var slotEl = e.target.closest && e.target.closest('[data-drop="slot"]');
      var logoEl = e.target.closest && e.target.closest('.logo-box');
      var vidEl = e.target.closest && e.target.closest('[data-drop="vfile"]');
      if (vidEl) {
        e.preventDefault();
        if (await setVideoFile(state.sections[+vidEl.getAttribute('data-sec')], e.dataTransfer.files[0])) changed({ sections: true, contact: true });
        return;
      }
      var layEl = e.target.closest && e.target.closest('[data-drop="layer"]');
      if (layEl) {
        e.preventDefault();
        var lf = e.dataTransfer.files[0];
        state.heroLayers[+layEl.getAttribute('data-layer')].image = await loadImg(lf, lf.name);
        renderLayers(); changed({ fast: true });
        return;
      }
      var pcEl = e.target.closest && e.target.closest('[data-drop="pc-end"], [data-drop="pc-img"]');
      if (pcEl) {
        e.preventDefault();
        $$('.is-drag-over').forEach(function (x) { x.classList.remove('is-drag-over'); });
        await addPcImages(state.sections[+pcEl.getAttribute('data-sec')], Array.prototype.slice.call(e.dataTransfer.files));
        return;
      }
      var secEl = e.target.closest && e.target.closest('[data-drop="img-end"], [data-drop="img"], .sec.is-cur .sec-body');
      var secFor = secEl ? state.sections[+(secEl.getAttribute('data-sec') || (secEl.closest('.sec') || secEl).getAttribute('data-sec'))] : null;
      if (secFor && secFor.kind === 'images' && !(e.target.closest('[data-drop="header"]'))) {
        e.preventDefault();
        $$('.is-drag-over').forEach(function (x) { x.classList.remove('is-drag-over'); });
        await addFiles(e.dataTransfer.files, { sec: state.sections.indexOf(secFor) });
        selectSec(secFor, false);
        return;
      }
      var hdrEl = e.target.closest && e.target.closest('[data-drop="header"]');
      if (hdrEl) {
        e.preventDefault();
        var hf = e.dataTransfer.files[0];
        state.sections[+hdrEl.getAttribute('data-sec')].header = await loadImg(hf, hf.name);
        changed({ sections: true, chips: true, fast: true });
        return;
      }
      if (slotEl || logoEl) {
        e.preventDefault();
        var file = e.dataTransfer.files[0];
        if (logoEl) { setLogo(await processLogo(file, file.name)); renderLogo(); renderRanges(); }
        else { state[slotEl.getAttribute('data-slot')] = await loadImg(file, file.name); renderHero(); }
        changed({ contact: true, fast: true });
        return;
      }
    }
    var t = dropTarget(e);
    $$('.is-drag-over').forEach(function (x) { x.classList.remove('is-drag-over'); });
    if (!t) return;
    e.preventDefault();
    var k = t.getAttribute('data-drop'), ts = +t.getAttribute('data-sec'), ti = +t.getAttribute('data-idx');
    if (drag.kind === 'img' && k === 'layer') {
      state.heroLayers[+t.getAttribute('data-layer')].image = state.sections[drag.sec].images.splice(drag.idx, 1)[0];
      drag = null; renderLayers();
      changed({ sections: true, chips: true, fast: true });
      return;
    }
    if (drag.kind === 'img' && k === 'slot') {
      // 섹션 이미지를 히어로·배지·이벤트 칸으로 옮기기
      state[t.getAttribute('data-slot')] = state.sections[drag.sec].images.splice(drag.idx, 1)[0];
      drag = null;
      renderHero();
      changed({ sections: true, chips: true, fast: true });
      return;
    }
    if (k === 'header') {
      // 제목 이미지 칸에 놓기: 원래 제목 이미지가 있으면 끌어온 자리와 맞바꿈
      var src = state.sections[drag.sec], dst = state.sections[ts], old = dst.header, got;
      if (drag.kind === 'img') {
        got = src.images.splice(drag.idx, 1)[0];
        if (old) src.images.splice(drag.idx, 0, old);
        if (drag.idx === 0) redetect(src);
      } else { got = src.header; src.header = old || null; }
      dst.header = got;
    } else if (drag.kind === 'sec') move(state.sections, drag.sec, ts);
    else if (drag.kind === 'img' || drag.kind === 'header') {
      var fromSec = state.sections[drag.sec], to = state.sections[ts].images, im;
      if (drag.kind === 'header') { im = fromSec.header; fromSec.header = null; }
      else { im = fromSec.images.splice(drag.idx, 1)[0]; }
      var at = k === 'img' ? ti : to.length;
      if (drag.kind === 'img' && k === 'img' && ts === drag.sec && drag.idx < ti) at--;
      at = Math.max(0, Math.min(at, to.length));
      to.splice(at, 0, im);
      if (at === 0) redetect(state.sections[ts]);
    }
    drag = null;
    changed({ sections: true, chips: true, fast: true });
  });
  panel.addEventListener('dragend', function () { drag = null; $$('.is-drag-over').forEach(function (x) { x.classList.remove('is-drag-over'); }); });

  // 업로드 영역 (클릭은 label이 처리, 여기선 파일 끌어다 놓기)
  var dz = $('#drop');
  ['dragenter', 'dragover'].forEach(function (ev) {
    dz.addEventListener(ev, function (e) { if (drag) return; e.preventDefault(); dz.classList.add('is-over'); });
  });
  ['dragleave', 'drop'].forEach(function (ev) { dz.addEventListener(ev, function () { dz.classList.remove('is-over'); }); });
  dz.addEventListener('drop', function (e) { if (drag) return; e.preventDefault(); addFiles(e.dataTransfer.files); });
  // 화면 아무 데나 파일을 떨어뜨려도 브라우저가 파일을 열지 않게
  window.addEventListener('dragover', function (e) { if (!drag) e.preventDefault(); });
  window.addEventListener('drop', function (e) {
    if (drag || e.defaultPrevented) return;
    e.preventDefault();
    if (e.dataTransfer && e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
  });

  /* =========================================================
     미리보기 조작
     ========================================================= */
  function seg(id, key) {
    $('#' + id).addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      $$('#' + id + ' button').forEach(function (x) { x.classList.toggle('is-on', x === b); });
      pv[key] = b.getAttribute('data-v'); pv.keepScroll = false; pv.fit = true;
      renderPreview();
    });
  }
  seg('pv-device', 'device');
  $('#pv-intro').addEventListener('click', function () {
    if (pv.page !== 'main') { pv.page = 'main'; renderPvPages(); }
    pv.intro = true; renderPreview();
  });
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || e.source !== ($('#pv-iframe') || {}).contentWindow) return;
    if (d.pvNav) { goPage(d.pvNav); return; }
    if (d.edSel != null) {
      if (d.edSel === 's-top') { setView('hero'); return; }
      if (pv.page === 'contact' && /^reserve/.test(d.edSel)) { setView('contact'); return; }   // 방문예약 페이지 맨 위·맨 아래 폼
      var hit = secById(d.edSel);
      if (hit) selectSec(hit, false);
      else if (state.editing !== 'main' && /^reserve/.test(d.edSel)) setView('menus');
      return;
    }
    if (d.edAct) { var t = secById(d.id); if (t) secAct(d.edAct, t); return; }
    if (d.edWheel) {
      var fr = $('#pv-frame').getBoundingClientRect(), z = curScale();
      setZoom(z * Math.exp(-d.edWheel.dy * 0.0022), fr.left + d.edWheel.x * z, fr.top + d.edWheel.y * z);
      return;
    }
    if (d.edKey) onKey({ type: d.edKey.type, code: d.edKey.code, ctrlKey: d.edKey.ctrl, metaKey: false, shiftKey: d.edKey.shift, altKey: d.edKey.alt, repeat: false, target: document.body, fromFrame: true, preventDefault: function () {} });
  });
  window.addEventListener('resize', function () { if (hasContent()) layoutPreview(); });

  /* =========================================================
     화면 구성 (피그마처럼): 왼쪽 섹션 목록 · 가운데 미리보기 · 오른쪽 설정
     view: 오른쪽에 보일 칸 (sections = 고른 섹션, 나머지는 칸 하나씩)
     ========================================================= */
  var view = 'upload';
  function setView(v, scroll) {
    view = v;
    panel.setAttribute('data-view', v);
    $$('#side-nav [data-view]').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-view') === v); });
    if (v !== 'sections' && curSec) { curSec = null; renderSections(); }
    renderTree();
    postMark(!!scroll);
    panel.scrollTop = 0;
  }
  function selectSec(sec, scroll) {
    curSec = sec || null;
    view = 'sections';
    panel.setAttribute('data-view', 'sections');
    $$('#side-nav [data-view]').forEach(function (b) { b.classList.remove('is-on'); });
    renderSections(); renderTree();
    postMark(!!scroll);
    var fe = curSec && groupOf(state.sections, curSec).length > 1 ? $('#secs .sec.is-focus') : null;
    panel.scrollTop = fe && fe.offsetTop > 120 ? fe.offsetTop - 70 : 0;
  }
  // 섹션 번호 (메뉴 01, 02 … / 방문예약만 '방' / 메뉴에 없으면 –): 섹션 칸과 같은 규칙
  function numMap(list) {
    var m = new Map(), no = 0, onPg = list !== MAIN();
    list.forEach(function (x) {
      if (x.kind === 'form') { m.set(x, x.nav ? pad2(++no) : '–'); return; }
      m.set(x, x.join ? '' : !onPg && whereOf(x) === 'contact' ? '방' : x.nav ? pad2(++no) : '–');
    });
    return m;
  }
  function idOf(x) { return x.kind === 'form' ? formOutId(formsOf(state.sections).indexOf(x)) : x.id; }
  function secById(id) {
    if (!id) return null;
    var L = state.sections, hit = L.find(function (x) { return x.kind !== 'form' && x.id === id; });
    if (hit) return hit;
    if (pv.page === 'main' && /^reserve(-\d+)?$/.test(id)) return formsOf(L)[id === 'reserve' ? 0 : +id.split('-')[1] - 1] || null;
    return null;
  }
  // 미리보기에 고른 것 표시 (+ 떠 있는 버튼). scroll이면 그 섹션으로 스크롤
  function postMark(scroll) {
    var fr = $('#pv-iframe');
    if (!fr || !fr.contentWindow || !hasContent()) return;
    var d = { edMark: null, label: '', tools: false, scroll: !!scroll };
    if (view === 'hero' && state.editing === 'main') { d.edMark = 's-top'; d.label = '히어로'; }
    else if (view === 'sections' && curSecIn() && !(curSec.kind === 'form' && pv.page !== 'main')) {
      var hd = headOf(state.sections, curSec), no = numMap(state.sections).get(hd);
      d.edMark = idOf(curSec); d.label = (no && no !== '–' ? no + ' ' : '') + (hd.label || '섹션') + (curSec.join ? ' · ' + (PART_LABEL[curSec.kind] || '') : ''); d.tools = true;
    }
    try { fr.contentWindow.postMessage(d, '*'); } catch (e) {}
  }
  function deleteSec(x) {
    var L = state.sections, g = groupOf(L, x), n = g.reduce(function (t, m) { return t + (m.kind === 'images' ? m.images.length + (m.header ? 1 : 0) : 0); }, 0);
    if (x.kind === 'form' && formsOf(L).length < 2) { toast('방문예약 폼은 최소 한 개는 있어야 해요'); return false; }
    if ((n || g.length > 1) && !confirm('"' + g[0].label + '" 섹션' + (g.length > 1 ? '(내용 ' + g.length + '개)' : '') + (n ? '과 이미지 ' + n + '장' : '') + '을 뺄까요?')) return false;
    L.splice(L.indexOf(g[0]), g.length);
    return true;
  }
  // 미리보기 위 떠 있는 버튼 · 단축키
  function secAct(act, x) {
    var L = state.sections, i = L.indexOf(x);
    if (i < 0) return;
    x = headOf(L, x);
    if (act === 'up') moveGroup(L, x, -1);
    else if (act === 'down') moveGroup(L, x, 1);
    else if (act === 'nav') x.nav = !x.nav;
    else if (act === 'dup') { copySec(x); curSec = x; pasteSec(); return; }
    else if (act === 'del') { if (!deleteSec(x)) return; curSec = null; changed({ sections: true, contact: true }); return; }
    curSec = x;
    changed({ sections: true, contact: true });
  }
  // 페이지 탭 (메인·방문예약·메뉴 페이지): 미리보기와 고치는 목록을 같이 바꿈
  function goPage(v) {
    var x = v !== 'main' && v !== 'contact' ? pageBySlug(v) : null;
    pv.keepScroll = false;
    pv.page = x ? v : v === 'contact' ? 'contact' : 'main';
    var ed = x ? x.page.id : 'main';
    curSec = null;
    if (state.editing !== ed) { state.editing = ed; relinkEditing(); render(); }
    else { renderPvPages(); renderSections(); renderPreview(); }
    setView(pv.page === 'contact' ? 'contact' : view === 'contact' || view === 'upload' ? 'sections' : view);
  }
  $('#pg-tabs').addEventListener('click', function (e) {
    var g = e.target.closest('[data-pg-group]');
    if (g) { var p = $('#pg-pop'); if (!p.hidden && p.getAttribute('data-for') === g.getAttribute('data-pg-group')) closePgPop(); else { openPgPop(g); p.setAttribute('data-for', g.getAttribute('data-pg-group')); } return; }
    var b = e.target.closest('[data-pg]'); if (!b) return;
    var v = b.getAttribute('data-pg');
    if (v !== '+') { goPage(v); return; }
    setView('menus');
    if (isMenuMode()) $('#add-menu').click();
    else toast('메뉴 방식을 \'원페이지 + 메뉴 페이지\'로 바꾸면 페이지를 더할 수 있어요');
  });
  $('#pg-pop').addEventListener('click', function (e) { var b = e.target.closest('[data-pg]'); if (!b) return; closePgPop(); goPage(b.getAttribute('data-pg')); });
  document.addEventListener('mousedown', function (e) { if (!e.target.closest || !e.target.closest('#pg-pop, [data-pg-group]')) closePgPop(); });
  window.addEventListener('resize', closePgPop);
  $('#pg-tabs').addEventListener('scroll', closePgPop);
  $('#side-nav').addEventListener('click', function (e) {
    var b = e.target.closest('[data-view]'); if (!b) return;
    var v = b.getAttribute('data-view');
    if (v === 'hero' && state.editing !== 'main') goPage('main');
    setView(v, v === 'hero');
  });
  $('#cv-checks').addEventListener('click', function () { setView('checks'); });

  // ---- 왼쪽 섹션 목록 ----
  var TI = {
    img: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/></svg>',
    text: '<svg viewBox="0 0 24 24"><path d="M5 6h14M12 6v13M9 19h6"/></svg>',
    video: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="14" height="14" rx="2"/><path d="M17 10l4-2.5v9L17 14"/></svg>',
    form: '<svg viewBox="0 0 24 24"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
    hero: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M9 13h6"/></svg>',
    eye: '<svg viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    eyeOff: '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.6 6.6A17 17 0 0 0 2 12s3.6 7 10 7a9.6 9.6 0 0 0 4.4-1"/></svg>'
  };
  function treeThumb(x) {
    var im = x.kind === 'images' ? x.images[0] || x.header : x.kind === 'video' ? x.poster : null;
    if (im) return '<img class="tr-pic" src="' + im.url + '" alt="">';
    var k = x.kind === 'images' ? 'img' : x.kind === 'video' ? 'video' : x.kind === 'text' ? 'text' : 'form';
    return '<span class="tr-pic tr-ic' + (x.kind === 'form' ? ' is-form' : '') + '">' + TI[k] + '</span>';
  }
  function treeMeta(x, onMain) {
    var w = onMain && x.kind !== 'form' ? whereOf(x) : '', wl = w === 'contact' ? ' · 방문예약만' : w === 'both' ? ' · 둘 다' : '';
    if (x.kind === 'images') {
      var n = x.images.length + (x.header ? 1 : 0);
      return n ? n + '장' + ((isPcMode() || (pcSplitOk(state.editing !== 'main') && (x.pcImages || []).length)) && x.mode !== 'slide' ? ' · PC ' + (x.pcImages || []).length : '') + (x.mode === 'slide' ? x.tabs ? ' · 탭 슬라이드' : ' · 슬라이드' : '') + wl : '<em>내용을 넣어 주세요</em>';
    }
    if (x.kind === 'video') return (filled(x) ? x.vsrc === 'file' ? '영상 파일' : '유튜브' : '<em>영상을 넣어 주세요</em>') + wl;
    if (x.kind === 'text') {
      var t = (x.texts || []).map(function (y) { return String(y.text || '').trim(); }).filter(Boolean)[0];
      return t ? esc(t.split('\n')[0].slice(0, 18)) + wl : '<em>글이 비어 있어요</em>';
    }
    var fc = fieldsOut(x).length;
    return '리드요 폼' + (fc ? ' · 추가 항목 ' + fc : '');
  }
  function treeFixed(kind, no, pic, name, sub, on) {
    return '<div class="tr tr-fixed' + (on ? ' is-on' : '') + '" data-tr="' + kind + '"><span class="tr-no">' + no + '</span>' + pic +
      '<span class="tr-t"><b>' + name + '</b><small>' + sub + '</small></span></div>';
  }
  function renderTree() {
    var el = $('#tree');
    if (!el) return;
    var onPg = state.editing !== 'main', isC = pv.page === 'contact', L = state.sections, nums = numMap(L), pg = onPg ? findPage(state.editing) : null, rows = [];
    $('#tree-title').textContent = isC ? '방문예약 페이지' : pg ? (pg.name || '메뉴') + ' 페이지' : '메인 페이지';
    var heroPic = state.heroBg ? '<img class="tr-pic" src="' + state.heroBg.url + '" alt="">' : '<span class="tr-pic tr-ic">' + TI.hero + '</span>';
    var formPic = '<span class="tr-pic tr-ic is-form">' + TI.form + '</span>';
    if (isC) {
      rows.push(treeFixed('contact', '폼', formPic, '방문예약 폼', '맨 위 · 첫 번째 폼 항목', view === 'contact'));
      if (state.contactHero) rows.push(treeFixed('hero', '00', heroPic, '히어로', '폼 아래', view === 'hero'));
    } else if (!onPg) rows.push(treeFixed('hero', '00', heroPic, '히어로', '배경 · 배지 · 제목', view === 'hero'));
    else if (state.pageTitle !== false) rows.push(treeFixed('menus', 'T', '<span class="tr-pic tr-ic">' + TI.text + '</span>', esc(pg ? pg.name : ''), '페이지 제목', false));
    fixJoins(L);
    var cg = curSecIn() && view === 'sections' ? groupOf(L, curSec) : [];
    L.forEach(function (x, i) {
      if (isC && x.kind === 'form') return;
      var dim = isC && whereOf(x) === 'main', no = nums.get(x);
      if (x.join) {
        rows.push('<div class="tr tr-sub' + (cg.indexOf(x) >= 0 ? ' is-on' : '') + (dim ? ' is-dim' : '') + '" data-tr="sec" data-i="' + i + '"><span class="tr-no"></span>' + treeThumb(x) +
          '<span class="tr-t"><b>' + (PART_LABEL[x.kind] || '내용') + '</b><small>' + treeMeta(x, false) + '</small></span></div>');
        return;
      }
      var g = groupOf(L, x);
      var pendT = x.nav && x.kind !== 'form' && !groupFilled(L, x);
      rows.push('<div class="tr' + (cg.indexOf(x) >= 0 ? ' is-on' : '') + (g.length > 1 ? ' tr-head' : '') + (dim ? ' is-dim' : '') + '" draggable="true" data-tr="sec" data-i="' + i + '">' +
        '<span class="tr-no' + (no === '–' ? ' off' : '') + (pendT ? ' is-pend' : '') + '"' + (pendT ? ' title="내용을 넣으면 이 번호로 메뉴에 나와요"' : '') + '>' + no + '</span>' + treeThumb(x) +
        '<span class="tr-t"><b>' + esc(x.label || (x.kind === 'form' ? '방문예약 폼' : '섹션')) + '</b><small>' + (dim ? '메인에만 나와요' : g.length > 1 ? g.map(function (m) { return m.kind === 'images' ? '사진 ' + (m.images.length + (m.header ? 1 : 0)) : PART_LABEL[m.kind]; }).join(' · ') : treeMeta(x, !onPg)) + '</small></span>' +
        '<button type="button" class="tr-eye' + (x.nav ? '' : ' off') + '" data-tr-act="nav" data-i="' + i + '" title="' + (x.nav ? '메뉴에 나와요 (누르면 빼기)' : '메뉴에 안 나와요 (누르면 넣기)') + '">' + (x.nav ? TI.eye : TI.eyeOff) + '</button></div>');
    });
    if (onPg && state.pageForm !== false) rows.push(treeFixed('menus', '폼', formPic, '방문예약 폼', '맨 밑 · 첫 번째 폼 항목', false));
    rows = flTreeRows(rows, L, isC, onPg);
    if (isC && state.contactFormBottom) rows.push(treeFixed('contact', '폼', formPic, '방문예약 폼', '맨 밑', false));
    if (!L.some(function (x) { return x.kind !== 'form'; })) rows.push('<p class="tr-empty">' + (onPg ? '아래 섹션 추가에서 이미지·글·영상을 넣어 이 페이지를 채워요.' : '이미지를 올리면 섹션이 자동으로 생겨요.') + '</p>');
    el.innerHTML = rows.join('');
  }
  var tree = $('#tree');
  tree.addEventListener('click', function (e) {
    var act = e.target.closest('[data-tr-act]');
    if (act) { var x = state.sections[+act.getAttribute('data-i')]; x.nav = !x.nav; changed({ sections: true, contact: true }); return; }
    var r = e.target.closest('[data-tr]'); if (!r) return;
    var k = r.getAttribute('data-tr');
    if (k === 'sec') selectSec(state.sections[+r.getAttribute('data-i')], true);
    else if (k === 'fl') abSelectFl(r.getAttribute('data-host'), r.getAttribute('data-id'), true);
    else setView(k, k === 'hero');
  });
  // 목록에서 끌어서 순서 바꾸기 · 오른쪽 이미지를 목록의 섹션 위에 놓으면 그 섹션으로 옮기기
  var trDrag = null;
  var trClear = function () { $$('#tree .drop-before, #tree .drop-after, #tree .drop-into, #tree .is-drag').forEach(function (x) { x.classList.remove('drop-before', 'drop-after', 'drop-into', 'is-drag'); }); };
  tree.addEventListener('dragstart', function (e) {
    var r = e.target.closest && e.target.closest('[data-tr="sec"]'); if (!r) return;
    trDrag = +r.getAttribute('data-i');
    e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'sec');
    r.classList.add('is-drag');
  });
  tree.addEventListener('dragover', function (e) {
    var r = e.target.closest && e.target.closest('[data-tr="sec"]'); if (!r) return;
    if (fileDrag(e) && trDrag == null) {
      if (state.sections[+r.getAttribute('data-i')].kind !== 'images') return;
      e.preventDefault();
      $$('#tree .drop-into').forEach(function (x) { if (x !== r) x.classList.remove('drop-into'); });
      r.classList.add('drop-into');
      return;
    }
    if (trDrag != null) {
      e.preventDefault();
      var bx = r.getBoundingClientRect(), after = e.clientY > bx.top + bx.height / 2;
      $$('#tree .drop-before, #tree .drop-after').forEach(function (x) { if (x !== r) x.classList.remove('drop-before', 'drop-after'); });
      r.classList.toggle('drop-after', after); r.classList.toggle('drop-before', !after);
    } else if (drag && (drag.kind === 'img' || drag.kind === 'header') && state.sections[+r.getAttribute('data-i')].kind === 'images') {
      e.preventDefault();
      $$('#tree .drop-into').forEach(function (x) { if (x !== r) x.classList.remove('drop-into'); });
      r.classList.add('drop-into');
    }
  });
  tree.addEventListener('dragleave', function (e) {
    var r = e.target.closest && e.target.closest('[data-tr]');
    if (r && !r.contains(e.relatedTarget)) r.classList.remove('drop-before', 'drop-after', 'drop-into');
  });
  tree.addEventListener('drop', function (e) {
    var r = e.target.closest && e.target.closest('[data-tr="sec"]');
    var after = r ? r.classList.contains('drop-after') : false;
    trClear();
    if (!r) { trDrag = null; return; }
    var L = state.sections, tgt = L[+r.getAttribute('data-i')];
    if (trDrag != null) {
      e.preventDefault();
      var mvg = groupOf(L, L[trDrag]), tg = groupOf(L, tgt); trDrag = null;
      if (tg[0] === mvg[0]) return;
      var anchor = after ? tg[tg.length - 1] : tg[0];
      L.splice(L.indexOf(mvg[0]), mvg.length);
      L.splice.apply(L, [L.indexOf(anchor) + (after ? 1 : 0), 0].concat(mvg));
      changed({ sections: true, contact: true });
      return;
    }
    if (trDrag == null && !drag && e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
      if (tgt.kind !== 'images') return;
      e.preventDefault();
      addFiles(e.dataTransfer.files, { sec: L.indexOf(tgt) }).then(function () { selectSec(tgt, true); });
      return;
    }
    if (drag && tgt.kind === 'images') {
      e.preventDefault();
      var src = L[drag.sec], im;
      if (src === tgt && drag.kind === 'img') { drag = null; return; }
      if (drag.kind === 'header') { im = src.header; src.header = null; }
      else { im = src.images.splice(drag.idx, 1)[0]; if (drag.idx === 0) redetect(src); }
      tgt.images.push(im);
      if (tgt.images.length === 1) redetect(tgt);
      drag = null;
      changed({ sections: true, chips: true, contact: true });
      toast('\'' + (tgt.label || '섹션') + '\' 섹션으로 옮겼어요');
    }
  });
  tree.addEventListener('dragend', function () { trDrag = null; trClear(); });

  // ---- 가운데: Ctrl+휠 확대·축소, 스페이스바 누르고 끌기 = 화면 이동 ----
  var stage = $('#pv-stage'), panLayer = $('#cv-pan'), overCanvas = false, panOn = false, panFrom = null;
  $('#canvas').addEventListener('mouseenter', function () { overCanvas = true; });
  $('#canvas').addEventListener('mouseleave', function () { overCanvas = false; });
  stage.addEventListener('wheel', function (e) {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    setZoom(curScale() * Math.exp(-e.deltaY * 0.0022), e.clientX, e.clientY);
  }, { passive: false });
  var panSet = function (on) { panOn = on; panLayer.hidden = !on; if (on) hintDone(); if (!on) { panFrom = null; panLayer.classList.remove('is-grab'); } };
  panLayer.addEventListener('mousedown', function (e) { panFrom = { x: e.clientX, y: e.clientY, l: stage.scrollLeft, t: stage.scrollTop }; panLayer.classList.add('is-grab'); e.preventDefault(); });
  window.addEventListener('mousemove', function (e) { if (!panFrom) return; stage.scrollLeft = panFrom.l - (e.clientX - panFrom.x); stage.scrollTop = panFrom.t - (e.clientY - panFrom.y); });
  window.addEventListener('mouseup', function () { if (panFrom) { panFrom = null; panLayer.classList.remove('is-grab'); } });
  window.addEventListener('blur', function () { panSet(false); });
  $('#zoom-in').addEventListener('click', function () { zoomStep(1); });
  $('#zoom-out').addEventListener('click', function () { zoomStep(-1); });
  $('#zoom-val').addEventListener('click', function () { setZoom(1); });
  $('#zoom-fit').addEventListener('click', zoomFit);
  // 단축키: 되돌리기·복사(아래 onKey가 받음) + 확대·축소 + 스페이스 이동 + Delete 삭제 + Esc 고르기 풀기
  function viewKeys(e) {
    if (abOn() || !$('#modal').hidden || isTyping(e.target)) return false;
    var c = e.code, mod = e.ctrlKey || e.metaKey;
    if (c === 'Space') {
      if (e.type === 'keyup') { if (panOn) { panSet(false); return true; } return false; }
      if (!e.fromFrame && !overCanvas) return false;
      e.preventDefault(); if (!panOn && hasContent()) panSet(true); return true;
    }
    if (e.type !== 'keydown' && e.type !== 'down') return false;
    if (mod && (c === 'Equal' || c === 'NumpadAdd')) { e.preventDefault(); zoomStep(1); return true; }
    if (mod && (c === 'Minus' || c === 'NumpadSubtract')) { e.preventDefault(); zoomStep(-1); return true; }
    if (mod && (c === 'Digit0' || c === 'Numpad0')) { e.preventDefault(); setZoom(1); return true; }
    if (!mod && e.shiftKey && c === 'Digit1') { e.preventDefault(); zoomFit(); return true; }
    if (!mod && c === 'Delete' && view === 'sections' && curSecIn()) { e.preventDefault(); secAct('del', curSec); return true; }
    if (c === 'Escape' && !$('#pg-pop').hidden) { closePgPop(); return true; }
    if (c === 'Escape' && curSec) { curSec = null; renderSections(); renderTree(); postMark(false); return true; }
    return false;
  }
  function onKey(e) {
    if (e.type === 'down') e.type = 'keydown';
    if (e.type === 'up') e.type = 'keyup';
    if (viewKeys(e)) return;
    if (e.type === 'keydown') undoKeys(e);
  }
  document.addEventListener('keydown', function (e) { if (viewKeys(e) && e.code !== 'Space') e.stopImmediatePropagation(); }, true);
  document.addEventListener('keyup', viewKeys);

  // ---- 방문예약 폼 추가 항목 (오른쪽 폼 칸) ----
  var openF = new WeakSet();
  function fieldRow(fd, i, j) {
    var at = ' data-sec="' + i + '" data-idx="' + j + '"', tl = (FIELD_TYPES.find(function (t) { return t[0] === fd.type; }) || FIELD_TYPES[0])[1], op = openF.has(fd);
    return '<div class="lf-item' + (op ? ' is-open' : '') + '">' +
      '<div class="lf-row"><span class="lf-type">' + tl + '</span><input class="inp" data-act="lf-label"' + at + ' value="' + esc(fd.label || '') + '" placeholder="질문 (예: 관심 타입)" aria-label="질문">' +
      '<button class="icon" type="button" data-act="lf-up"' + at + ' title="위로">↑</button><button class="icon" type="button" data-act="lf-down"' + at + ' title="아래로">↓</button>' +
      '<button class="icon' + (op ? ' is-on' : '') + '" type="button" data-act="lf-open"' + at + ' title="설정"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/></svg></button><button class="icon danger" type="button" data-act="lf-del"' + at + ' title="빼기">✕</button></div>' +
      (op ? '<div class="lf-set">' +
        '<div class="lf-set-row"><label class="chk"><input type="checkbox" data-act="lf-req"' + at + (fd.required ? ' checked' : '') + '>필수로 받기</label>' +
        '<label class="lf-pos">위치 <select class="pv-sel" data-act="lf-pos"' + at + '>' + FIELD_POS.map(function (p) { return '<option value="' + p[0] + '"' + ((fd.pos || 'memo') === p[0] ? ' selected' : '') + '>' + p[1] + '</option>'; }).join('') + '</select></label></div>' +
        (isChoice(fd.type)
          ? '<div class="field"><span class="lab">선택지</span><div class="lf-opts">' + (fd.options || []).map(function (o, oi) {
              return '<div class="lf-opt"><input class="inp" data-act="lf-opt"' + at + ' data-o="' + oi + '" value="' + esc(o) + '" placeholder="선택지 ' + (oi + 1) + '"><button class="icon danger" type="button" data-act="lf-opt-del"' + at + ' data-o="' + oi + '" title="빼기">✕</button></div>';
            }).join('') + '</div><button class="link" type="button" data-act="lf-opt-add"' + at + '>+ 선택지 추가</button></div>'
          : '<div class="field"><span class="lab">입력칸 안 흐린 글 (선택)</span><input class="inp" data-act="lf-ph"' + at + ' value="' + esc(fd.placeholder || '') + '" placeholder="예: 김포시"></div>') +
        '<div class="field"><span class="lab">설명 (선택)</span><input class="inp" data-act="lf-help"' + at + ' value="' + esc(fd.help || '') + '" placeholder="질문 아래 작은 글씨"></div>' +
      '</div>' : '') + '</div>';
  }
  function formBody(x, i, k, many) {
    var fs = x.fields || [];
    return '<div class="form-note"><b>방문예약 폼' + (many ? ' ' + (k + 1) : '') + '</b> · 리드요 폼이 들어가는 자리예요. 이름·연락처·방문일 같은 기본 항목은 리드요 관리자에서 정해요.</div>' +
      '<div class="lf-head"><b>추가 항목</b>' + (fs.length ? '<span>' + fs.length + '개</span>' : '') + '</div>' +
      (fs.length ? '<div class="lf-list">' + fs.map(function (fd, j) { return fieldRow(fd, i, j); }).join('') + '</div>'
        : '<p class="lf-empty">관심 타입, 방문 인원처럼 더 받고 싶은 걸 넣어요. 답은 리드요 \'문의 내용\'에 같이 담겨서 접수돼요.</p>') +
      '<div class="lf-add">' + FIELD_TYPES.map(function (t) { return '<button type="button" class="btn small" data-act="lf-add" data-v="' + t[0] + '" data-sec="' + i + '">+ ' + t[1] + '</button>'; }).join('') + '</div>' +
      '<label class="chk lf-hide"><input type="checkbox" data-act="lf-hidememo" data-sec="' + i + '"' + (x.hideMemo ? ' checked' : '') + '>리드요 \'문의 내용\' 칸은 숨기기 (추가 항목 답만 받기)</label>' +
      (k === 0 ? '<p class="note">방문예약 페이지·메뉴 페이지 폼에도 이 첫 번째 폼의 추가 항목이 들어가요.</p>' : '') +
      '<button class="link lf-privacy" type="button" data-act="go-privacy">개인정보 동의문 고치기 →</button>';
  }
  // 묶음: 사진·글·영상 더 넣기 / 순서 / 빼기
  function partAct(act, x, kind) {
    var L = state.sections;
    if (!x || L.indexOf(x) < 0) return;
    var g = groupOf(L, x), h = g[0], nav = h.nav, label = h.label, where = h.where, k = g.indexOf(x);
    if (act === 'part-add') {
      var o = { join: true, nav: false, label: label };
      if (where) o.where = where;
      if (h.anim) o.anim = Object.assign({}, h.anim);
      var nx = kind === 'text' ? textSection(o) : videoSection(o);
      L.splice(L.indexOf(x) + 1, 0, nx);
      changed({ sections: true, contact: true });
      selectSec(nx, false);
      var foc = $(kind === 'text' ? '#secs .sec.is-focus textarea' : '#secs .sec.is-focus [data-act="vid-url"]'); if (foc) { foc.focus(); foc.scrollIntoView({ block: 'center' }); }
      return;
    }
    if (act === 'part-del') {
      var n = x.kind === 'images' ? x.images.length + (x.header ? 1 : 0) : 0;
      if (n && !confirm('이 사진 ' + n + '장을 뺄까요?')) return;
      g.splice(k, 1); L.splice(L.indexOf(x), 1);
      if (g.length) relead(g, nav, label, where);
      curSec = g[Math.max(0, k - 1)] || null;
      changed({ sections: true, contact: true });
      if (curSec) selectSec(curSec, false);
      return;
    }
    var to = k + (act === 'part-up' ? -1 : 1);
    if (to < 0 || to >= g.length) return;
    var i0 = L.indexOf(h);
    g.splice(to, 0, g.splice(k, 1)[0]);
    L.splice.apply(L, [i0, g.length].concat(g));
    relead(g, nav, label, where);
    curSec = x;
    changed({ sections: true, contact: true });
    selectSec(x, false);
  }
  // 묶음에 사진 더 넣기: 마지막이 사진 칸이면 거기에, 아니면 새 사진 칸
  async function partImages(x, files) {
    var L = state.sections, g = groupOf(L, x), h = g[0], tail = L.indexOf(x) === L.indexOf(g[g.length - 1]) ? x : x, tgt = tail;
    if (tgt.kind !== 'images') {
      tgt = newSection({ id: uniqueId('s-custom'), join: true, nav: false, label: h.label });
      if (h.where) tgt.where = h.where;
      L.splice(L.indexOf(x) + 1, 0, tgt);
    }
    await addFiles(files, { sec: L.indexOf(tgt) });
    selectSec(tgt, false);
  }
  async function addPcImages(x, files) {
    files = files.filter(function (f) { return /^image\//.test(f.type) || /\.(png|jpe?g|webp)$/i.test(f.name); }).sort(function (a, b) { return natural(a.name, b.name); });
    if (!files.length) { toast('이미지(PNG·JPG·WebP)만 넣을 수 있어요'); return; }
    busy('PC 이미지 읽는 중…');
    try { x.pcImages = x.pcImages || []; for (var k = 0; k < files.length; k++) x.pcImages.push(await loadImg(files[k], files[k].name)); }
    finally { unbusy(); }
    pcTab = 'pc'; curSec = x;
    changed({ sections: true });
    var small = files.length && x.pcImages.slice(-files.length).filter(function (im) { return im.w < 1000; }).length;
    toast('PC 이미지 ' + files.length + '장을 넣었어요' + (small ? ' (가로 1000px 안 되는 ' + small + '장은 PC에서 흐릿할 수 있어요)' : ''));
  }
  // 빈 섹션을 글·영상 섹션으로 바꾸기 (이름을 바꿔 뒀으면 그 이름 그대로)
  function secTo(x, kind) {
    var L = state.sections, i = L.indexOf(x);
    if (i < 0) return;
    var o = x.label && x.label !== '새 섹션' ? { label: x.label } : {};
    var nx = kind === 'text' ? textSection(o) : videoSection(o);
    if (x.where) nx.where = x.where;
    if (x.join) { nx.join = true; nx.nav = false; nx.label = x.label; }
    L.splice(i, 1, nx);
    changed({ sections: true, contact: true });
    selectSec(nx, true);
    var foc = $(kind === 'text' ? '#secs .sec.is-cur textarea' : '#secs .sec.is-cur [data-act="vid-url"]'); if (foc) foc.focus();
  }
  var lfOf = function (t) { var x = state.sections[+t.getAttribute('data-sec')]; return { s: x, f: x && x.fields ? x.fields[+t.getAttribute('data-idx')] : null }; };
  panel.addEventListener('input', function (e) {
    var t = e.target, act = t.getAttribute('data-act');
    if (act === 'anim-dur') { var ax = state.sections[+t.getAttribute('data-sec')], dv = ANIM_DURS[+t.value] || 1; setAnim(ax, { dur: dv }); t.nextElementSibling.textContent = dv + '초'; changed(); return; }
    if (!act || !/^lf-/.test(act)) return;
    var r = lfOf(t); if (!r.f) return;
    if (act === 'lf-label') r.f.label = t.value;
    else if (act === 'lf-opt') r.f.options[+t.getAttribute('data-o')] = t.value;
    else if (act === 'lf-ph') r.f.placeholder = t.value;
    else if (act === 'lf-help') r.f.help = t.value;
    else return;
    changed(); renderTree();
  });
  panel.addEventListener('change', function (e) {
    var t = e.target, act = t.getAttribute('data-act');
    if (act === 'anim-rep') { setAnim(state.sections[+t.getAttribute('data-sec')], { rep: t.checked }); changed(); return; }
    if (act === 'pc-add' && t.files.length) { addPcImages(state.sections[+t.getAttribute('data-sec')], Array.prototype.slice.call(t.files)); t.value = ''; return; }
    if (!act || !/^lf-/.test(act)) return;
    var r = lfOf(t);
    if (act === 'lf-hidememo') { r.s.hideMemo = t.checked; changed(); return; }
    if (!r.f) return;
    if (act === 'lf-req') r.f.required = t.checked;
    else if (act === 'lf-pos') r.f.pos = t.value;
    else return;
    changed();
  });
  panel.addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]'); if (!b || b.tagName === 'INPUT' || b.tagName === 'SELECT') return;
    var act = b.getAttribute('data-act');
    if (act === 'sec-to') { secTo(state.sections[+b.getAttribute('data-sec')], b.getAttribute('data-v')); return; }
    var bs = state.sections[+b.getAttribute('data-sec')];
    if (act === 'anim-type') { var tv = b.getAttribute('data-v'); setAnim(bs, { type: tv === 'slide' ? 'slide-left' : tv }); changed({ sections: true }); return; }
    if (act === 'anim-dir') { setAnim(bs, { type: b.getAttribute('data-v') }); changed({ sections: true }); return; }
    if (act === 'pc-tab') { pcTab = b.getAttribute('data-v'); renderSections(); return; }
    if (act === 'pc-left' || act === 'pc-right' || act === 'pc-del') {
      var pj = +b.getAttribute('data-idx');
      if (act === 'pc-del') bs.pcImages.splice(pj, 1); else move(bs.pcImages, pj, pj + (act === 'pc-left' ? -1 : 1));
      changed({ sections: true }); return;
    }
    if (act === 'part-add' || act === 'part-up' || act === 'part-down' || act === 'part-del') { partAct(act, state.sections[+b.getAttribute('data-sec')], b.getAttribute('data-v')); return; }
    if (!/^lf-/.test(act)) return;
    var r = lfOf(b), x = r.s, j = +b.getAttribute('data-idx');
    if (!x) return;
    if (act === 'lf-add') {
      var ty = b.getAttribute('data-v'), nf = { type: ty, label: '', required: false, pos: 'memo' };
      if (isChoice(ty)) nf.options = ['', ''];
      (x.fields = x.fields || []).push(nf);
      openF = new WeakSet(); openF.add(nf);   // 설정은 하나만 펼쳐 둠
      changed({ sections: true });
      var inps = $$('#secs .sec.is-cur [data-act="lf-label"]'); if (inps.length) inps[inps.length - 1].focus();
      return;
    }
    var fd = r.f; if (!fd) return;
    if (act === 'lf-open') { if (openF.has(fd)) openF.delete(fd); else { openF = new WeakSet(); openF.add(fd); } renderSections(); return; }
    if (act === 'lf-up') move(x.fields, j, j - 1);
    else if (act === 'lf-down') move(x.fields, j, j + 1);
    else if (act === 'lf-del') x.fields.splice(j, 1);
    else if (act === 'lf-opt-add') { fd.options = fd.options || []; fd.options.push(''); }
    else if (act === 'lf-opt-del') fd.options.splice(+b.getAttribute('data-o'), 1);
    else return;
    changed({ sections: true });
  });

  /* =========================================================
     내보내기
     ========================================================= */
  function asciiName(s) { return String(s || '').replace(/,/g, '').replace(/[^A-Za-z0-9_\-]+/g, '_').replace(/^_+|_+$/g, ''); }
  async function encode(im, mode, maxw) {
    var MAXW = maxw || 860, isJpg = /jpe?g/.test(im.type), isPng = /png/.test(im.type);
    var light = !maxw || im.blob.size < 700 * 1024;   // PC용 큰 이미지는 너무 무거우면 다시 압축
    if (mode !== 'png' && isJpg && im.w <= MAXW && light) return { blob: im.blob, ext: 'jpg', w: im.w, h: im.h };
    if (mode === 'png' && isPng && im.w <= MAXW) return { blob: im.blob, ext: 'png', w: im.w, h: im.h };
    var bmp = await createImageBitmap(im.blob);
    var w = Math.min(bmp.width, MAXW), h = Math.round(bmp.height * w / bmp.width);
    var c = canvas(w, h), x = c.getContext('2d');
    x.imageSmoothingQuality = 'high';
    if (mode !== 'png') { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); }
    x.drawImage(bmp, 0, 0, w, h); bmp.close();
    if (mode === 'png') return { blob: await toBlob(c, 'image/png'), ext: 'png', w: w, h: h };
    var jpg = await toBlob(c, 'image/jpeg', 0.9);
    if (mode === 'photo' && isPng && im.w <= MAXW && im.blob.size <= jpg.size) return { blob: im.blob, ext: 'png', w: w, h: h };
    return { blob: jpg, ext: 'jpg', w: w, h: h };
  }
  function zipName() {
    var d = new Date();
    return (state.siteName.trim() || 'landing').replace(/[\\/:*?"<>|\s]+/g, '') + '_' + d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate()) + '.zip';
  }
  var lastZip = null;
  async function exportZip() {
    var cs = checks(), errs = cs.filter(function (c) { return c.lvl === 'err'; });
    if (errs.length) {
      modal('<h3>아직 만들 수 없어요</h3><ul class="checks">' + errs.map(function (c) { return '<li class="err">' + esc(c.msg) + '</li>'; }).join('') +
        '</ul><div class="acts"><button class="btn primary" type="button" data-close>확인</button></div>');
      return;
    }
    modal('<h3>zip 만드는 중…</h3><div class="progress"><i id="pg"></i></div><div class="desc" id="pg-txt">이미지 변환 중</div>');
    var pg = function (v, txt) { var i = $('#pg'); if (i) i.style.width = v + '%'; if (txt) $('#pg-txt').textContent = txt; };
    try {
      var zip = new JSZip(), root = zip.folder(state.folder), out = new Map(), jobs = [], used = new Set();
      if (state.heroBg) jobs.push([state.heroBg, 'img/hero_bg', 'photo']);
      if (isPcMode() && state.heroBgPc) jobs.push([state.heroBgPc, 'img/hero_bg_pc', 'photo', 1920]);
      if (state.badge) jobs.push([state.badge, 'img/hero_badge', 'png']);
      (state.heroFl || []).forEach(function (L, k) { if (L.t === 'img' && L.img) jobs.push([L.img, 'img/hero_fl_' + pad2(k + 1), L.img.alpha > 0.01 ? 'png' : 'photo']); });
      state.heroLayers.forEach(function (L, k) { if (L.kind === 'image' && L.image) jobs.push([L.image, 'img/hero_layer_' + pad2(k + 1), L.image.alpha > 0.01 ? 'png' : 'photo']); });
      var keys = new Set();
      var addSecJobs = function (list, prefix) { list.forEach(function (s, si) {
        if (s.kind === 'form') return;
        var key = prefix + (SECTION_DEFS[s.key] ? s.key : 's' + (si + 1));
        if (s.kind === 'video') key = prefix + (s.vsrc === 'youtube' ? 'youtube' : 'video');   // 영상 파일만 video, video2 …
        var keyBase = key, keyN = 2;
        while (keys.has(key)) key = keyBase + (keyN++);   // 겹치면 video2, etc2 …
        keys.add(key);
        if (s.header) jobs.push([s.header, 'img/' + key + '_title', 'photo']);
        if (s.kind === 'video') {
          if (s.vsrc === 'file' && s.vfile) {
            var vpath = 'video/' + key + (/webm/.test(s.vfile.type) ? '.webm' : '.mp4');
            root.file(vpath, s.vfile.blob, { compression: 'STORE' });
            out.set(s.vfile.id, { path: vpath, w: s.vfile.w, h: s.vfile.h });
            if (s.poster) jobs.push([s.poster, 'img/' + key + '_poster', 'photo']);
          }
          return;
        }
        var split = s.kind === 'images' && s.mode !== 'slide' && pcSplitOk(prefix) && (s.pcImages || []).length > 0;
        s.images.forEach(function (im, j) {
          var base = 'img/' + key + '_' + pad2(j + 1);
          if (s.key === 'types' && s.mode === 'slide') {   // 타입 평면도는 알아보기 쉽게 타입명으로
            var nm = asciiName(im.label) || pad2(j + 1);
            while (used.has(nm)) nm += '_';
            used.add(nm);
            base = 'img/type/' + prefix + 'type_' + nm;
          }
          jobs.push([im, base, 'photo', undefined, split]);   // [4] = 메뉴 페이지 폭으로 안 바꿈
        });
        (s.fl || []).forEach(function (L, j) { if (L.t === 'img' && L.img) jobs.push([L.img, 'img/' + key + '_fl_' + pad2(j + 1), L.img.alpha > 0.01 ? 'png' : 'photo']); });
        if (split) s.pcImages.forEach(function (im, j) { jobs.push([im, 'img/' + key + '_pc_' + pad2(j + 1), 'photo', 1600]); });
      }); };
      addSecJobs(MAIN(), '');
      if (isMenuMode()) menuPages().forEach(function (x) {
        var from = jobs.length;
        addSecJobs(x.page.sections || [], x.page.slug + '-');
        var pw = x.page.cw === 375 ? 0 : x.page.cw === 860 ? 1200 : 1600;   // 1200 페이지 = PC용 큰 이미지, 375 = 모바일 이미지(메인과 같이 860)
        for (var pj = from; pj < jobs.length; pj++) if (!jobs[pj][4]) jobs[pj][3] = pw || undefined;
      });
      for (var k = 0; k < jobs.length; k++) {
        var r = await encode(jobs[k][0], jobs[k][2], jobs[k][3]);
        var path = jobs[k][1] + '.' + r.ext;
        root.file(path, r.blob);
        out.set(jobs[k][0].id, { path: path, w: r.w, h: r.h });
        pg(Math.round((k + 1) / jobs.length * 75), '이미지 변환 중 (' + (k + 1) + '/' + jobs.length + ')');
      }
      root.file('img/logo.png', state.logo.blob);
      out.set('logo', { path: 'img/logo.png', w: state.logo.w, h: state.logo.h });
      var o = {
        preview: false,
        src: function (im, pre) { return pre + out.get(im.id).path; },
        dims: function (im) { var v = out.get(im.id); return { w: v.w, h: v.h }; }
      };
      root.file('index.html', renderPage('main', o));
      root.file('contact/index.html', renderPage('contact', o));
      if (isMenuMode()) menuPages().forEach(function (x) { root.file(x.page.slug + '/index.html', renderPage(x.page.slug, o)); });
      root.file('css/landing-style.css', siteCss());
      root.file('css/pretendard.css', T.pretendardCss);
      root.file('js/main.js', T.js);
      Object.keys(T.fonts).forEach(function (p) { root.file(p, T.fonts[p], { base64: true }); });
      pg(78, 'zip 묶는 중');
      var blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } }, function (m) { pg(78 + m.percent * 0.22); });
      lastZip = blob;
      addHistory('export', '').catch(function () {});   // 만든 시점은 작업 내역에 남김
      var count = Object.keys(zip.files).filter(function (n) { return !zip.files[n].dir; }).length;
      var name = zipName(), url = URL.createObjectURL(blob), mb = blob.size / 1048576;
      var a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      var warns = cs.filter(function (c) { return c.lvl === 'warn'; });
      if (mb > 20) warns.unshift({ msg: 'zip이 ' + mb.toFixed(1) + 'MB로 20MB를 넘어요. 이미지를 줄여 주세요' });
      modal('<h3>zip을 만들었어요</h3><p class="desc" style="margin:0 0 10px">' + esc(name) + ' · ' + mb.toFixed(2) + 'MB · 파일 ' + count + '개</p>' +
        (warns.length ? '<ul class="checks">' + warns.map(function (c) { return '<li class="warn">' + esc(c.msg) + '</li>'; }).join('') + '</ul>' : '') +
        '<p class="desc" style="margin:12px 0 0">다운로드가 시작되지 않으면 아래 버튼을 눌러 주세요. 나중에 고칠 땐 이 zip을 위의 \'만든 zip 불러오기\'로 다시 열면 돼요.</p>' +
        '<div class="acts"><a class="btn" href="' + url + '" download="' + esc(name) + '" id="dl-again">다시 받기</a><button class="btn primary" type="button" data-close>닫기</button></div>');
    } catch (err) {
      console.error(err);
      modal('<h3>zip을 만들지 못했어요</h3><p class="desc">' + esc(err && err.message || err) + '</p><div class="acts"><button class="btn primary" type="button" data-close>닫기</button></div>');
    }
  }
  $('#export-btn').addEventListener('click', exportZip);

  /* =========================================================
     zip 불러오기 (이 에디터로 만든 zip, 예전에 손으로 만든 zip 모두)
     ========================================================= */
  function joinPath(base, rel) {
    var parts = (base + rel).split('/'), out = [];
    parts.forEach(function (p) { if (p === '..') out.pop(); else if (p !== '.' && p !== '') out.push(p); });
    return out.join('/');
  }
  function textWithBreaks(el) {
    if (!el) return '';
    var c = el.cloneNode(true);
    $$('br', c).forEach(function (b) { b.replaceWith('\n'); });
    return c.textContent.replace(/[ \t]+\n/g, '\n').trim();
  }
  async function importZip(file) {
    if (hasWork()) { try { await addHistory('import', ''); } catch (e) {} }   // 덮어쓰기 전 지금 작업을 내역에 남김
    busy('zip 불러오는 중…');
    try {
      var zip = await JSZip.loadAsync(file);
      var names = Object.keys(zip.files).filter(function (n) { return !zip.files[n].dir; });
      var idx = names.filter(function (n) { return /(^|\/)index\.html$/i.test(n) && !/contact\/index\.html$/i.test(n); })
        .sort(function (a, b) { return a.split('/').length - b.split('/').length; })[0];
      var revoke = function () { /* 이전 이미지 주소 정리 */ };
      revoke();
      if (!idx) {
        var imgs = names.filter(function (n) { return /\.(png|jpe?g|webp)$/i.test(n); });
        var files = [];
        for (var q = 0; q < imgs.length; q++) files.push(new File([await zip.file(imgs[q]).async('blob')], imgs[q].split('/').pop(), { type: mimeOf(imgs[q]) }));
        state = freshState();
        unbusy();
        await addFiles(files);
        toast('index.html이 없어서 이미지만 불러왔어요');
        return;
      }
      var base = idx.slice(0, idx.length - 'index.html'.length);
      var doc = new DOMParser().parseFromString(await zip.file(idx).async('string'), 'text/html');
      // 예전 zip은 css/style.css, 지금은 css/landing-style.css
      var cssFile = zip.file(base + 'css/landing-style.css') || zip.file(base + 'css/style.css'), css = cssFile ? await cssFile.async('string') : '';
      var get = async function (rel, alt, dirBase) {   // dirBase: 그 페이지 폴더 (방문예약 페이지는 contact/)
        if (!rel) return null;
        var p = joinPath(dirBase || base, rel), f = zip.file(p);
        if (!f) return null;
        var im = await loadImg(new Blob([await f.async('arraybuffer')], { type: mimeOf(p) }), p.split('/').pop());
        if (alt) im.alt = alt;
        return im;
      };
      var attr = function (sel, a) { var el = doc.querySelector(sel); return el ? el.getAttribute(a) : null; };
      var S = freshState();
      S.folder = base.replace(/\/$/, '').split('/').pop() || 'landing_m';
      var top = doc.querySelector('.pc-right a[data-nav-top]');
      S.siteName = (top ? top.textContent : doc.title.replace(/^방문예약 \| /, '')).trim();
      S.heroTitle = textWithBreaks(doc.querySelector('.hero-title')); S.titleAuto = false;
      S.heroSub = (doc.querySelector('.hero-sub') || { textContent: '' }).textContent.trim();
      S.phone = (doc.querySelector('.bar-tel') || { textContent: '' }).textContent.trim();
      var m = css.match(/--brand:\s*(#[0-9a-f]{3,6})/i) || css.match(/--navy:\s*(#[0-9a-f]{3,6})/i);
      if (m) { S.brand = normHex(m[1]); S.brandTouched = true; }
      m = css.match(/--badge-top:\s*([\d.]+)%/) || css.match(/\.hero-badges\s*\{[^}]*top:\s*([\d.]+)%/);
      if (m) S.badgeTop = parseFloat(m[1]);
      var num = function (re) { var mm = css.match(re); return mm ? parseFloat(mm[1]) : null; }, v;
      if ((v = num(/--logo-w:\s*([\d.]+)px/)) != null) { S.logoW = v; S.logoWTouched = true; }
      if ((v = num(/--title-size:\s*([\d.]+)/)) != null) S.titleSize = Math.round(v * 375 * 2) / 2;
      if ((v = num(/--title-top:\s*([\d.]+)%/)) != null) S.titleTop = v;
      if ((v = num(/--sub-size:\s*([\d.]+)/)) != null) S.subSize = Math.round(v * 375 * 2) / 2;
      if ((v = num(/--sub-top:\s*([\d.]+)%/)) != null) S.subTop = v;
      if ((v = num(/--badge-w:\s*([\d.]+)%/)) != null) S.badgeW = v;
      var obm = css.match(/--on-brand:\s*(#[0-9a-f]{3,6})/i);
      if (obm) {
        var ob = normHex(obm[1]), auto = lum(S.brand) < 150 ? '#ffffff' : '#1a1a1a';
        S.onBrandMode = ob === auto ? 'auto' : ob === '#ffffff' ? 'white' : ob === '#1a1a1a' ? 'dark' : 'custom';
        S.onBrandCustom = ob;
      }
      var bandM = css.match(/--tv-band:\s*([\d.]+)/) || css.match(/calc\(var\(--colw\) \* ([\d.]+) - 32px\)/);
      var disc = $$('.ft p:not(.ft-call)', doc).map(function (p) { return p.textContent.trim(); }).filter(Boolean);
      if (disc.length) S.disclaimers = disc.join('\n');
      var ptp = doc.querySelector('template[data-leadyo-privacy-text]'), ttp = doc.querySelector('template[data-leadyo-third-party-text]');
      if (ptp) S.privacyText = ptp.content.textContent;
      if (ttp) S.thirdPartyText = ttp.content.textContent;
      state = S;   // get()이 uid를 쓰므로 여기서 교체
      S.heroBg = await get(attr('.hero-bg img', 'src'));
      var hpSrc = doc.querySelector('.hero-bg picture source');
      if (hpSrc) S.heroBgPc = await get(hpSrc.getAttribute('srcset'));
      S.badge = await get(attr('.hero-badges img', 'src'));
      S.badgeAlt = attr('.hero-badges img', 'alt') || '';
      var readFl = async function (host, dirBase) {
        var out = [], els = host ? $$(':scope > .fl[data-fl]', host) : [];
        for (var q = 0; q < els.length; q++) {
          var L = null; try { L = JSON.parse(els[q].getAttribute('data-fl')); } catch (e) { L = null; }
          if (!L || !L.t) continue;
          if (L.t === 'img') { var fi = els[q].querySelector('img'); L.img = fi ? await get(fi.getAttribute('src'), fi.getAttribute('alt'), dirBase) : null; if (!L.img) continue; }
          out.push(L);
        }
        return out;
      };
      S.heroFl = await readFl(doc.querySelector('.hero'), base);
      var layerEls = $$('.hero > .hero-layer', doc);
      for (var li = 0; li < layerEls.length; li++) {
        var le = layerEls[li], ltop = parseFloat(le.getAttribute('data-top'));
        var limg = le.querySelector('img'), lp = le.querySelector('p');
        if (isNaN(ltop)) ltop = 55;
        if (limg) {
          var lim = await get(limg.getAttribute('src'), limg.getAttribute('alt'));
          if (lim) S.heroLayers.push(newLayer('image', { image: lim, top: ltop, w: parseFloat(le.getAttribute('data-w')) || 60 }));
        } else if (lp) {
          S.heroLayers.push(newLayer('text', { text: textWithBreaks(lp), top: ltop, size: parseFloat(lp.getAttribute('data-size')) || 20,
            font: lp.getAttribute('data-font') || 'pretendard', color: lp.getAttribute('data-color') || '#ffffff', bold: lp.hasAttribute('data-bold') }));
        }
      }
      var logoRel = attr('.hd-logo img', 'src');
      if (logoRel) {
        var lf = zip.file(joinPath(base, logoRel));
        if (lf) setLogo(await processLogo(new Blob([await lf.async('arraybuffer')], { type: mimeOf(logoRel) }), 'logo.png'));
      }
      var introEl = doc.getElementById('intro');
      S.introMode = !introEl ? 'none' : introEl.querySelector('.intro-logo') ? (introEl.querySelector('.intro-name') ? 'both' : 'logo') : 'text';
      // 섹션 하나 읽기 (메인·방문예약 페이지 공용)
      var readVideo = async function (el, dirBase, labels) {
        var id = el.id;
        var s = videoSection({ id: S.sections.some(function (x) { return x.id === id; }) ? uniqueId(id) : id, label: labels[id] || '홍보영상', nav: id in labels, order: 50 });
        var hf = el.querySelector(':scope > figure img');
        if (hf) s.header = await get(hf.getAttribute('src'), hf.getAttribute('alt'), dirBase);
        var box = el.querySelector('.vbox'), vel = el.querySelector('video');
        if (box && box.hasAttribute('data-yt')) {
          s.vsrc = 'youtube'; s.yt = box.getAttribute('data-yt'); s.ytUrl = 'https://youtu.be/' + s.yt;
          s.ratio = /9\s*\/\s*16/.test(box.getAttribute('style') || '') ? '9:16' : '16:9';
        } else if (vel) {
          s.vsrc = 'file'; s.autoplay = vel.hasAttribute('data-autoplay');
          var vrel = vel.getAttribute('src'), vzf = vrel && zip.file(joinPath(dirBase, vrel));
          if (vzf) {
            var vname = vrel.split('/').pop();
            var lv = await loadVideo(new Blob([await vzf.async('arraybuffer')], { type: videoType(vname) }), vname);
            s.vfile = lv.file; s.poster = lv.poster;
            var prel = vel.getAttribute('poster');
            if (prel) { var pim = await get(prel, '', dirBase); if (pim) { s.poster = pim; s.posterAuto = false; } }
          }
        }
        return s;
      };
      var readSection = async function (el, dirBase, labels) {
        var rs = await readSection1(el, dirBase, labels);
        if (rs && rs.kind === 'images') { var rfl = await readFl(el, dirBase); if (rfl.length) rs.fl = rfl; }
        if (rs && el.hasAttribute('data-join')) { rs.join = true; rs.nav = false; }
        if (rs && el.hasAttribute('data-anim')) rs.anim = { type: el.getAttribute('data-anim'), dur: parseFloat(el.getAttribute('data-ad')) || 1, rep: el.hasAttribute('data-anim-rep') };
        if (rs && rs.kind === 'images') {
          var pcf = $$('figure.pc-only img', el);
          if (pcf.length) { rs.pcImages = []; for (var pq = 0; pq < pcf.length; pq++) { var pim = await get(pcf[pq].getAttribute('src'), pcf[pq].getAttribute('alt'), dirBase); if (pim) rs.pcImages.push(pim); } }
        }
        if (rs && rs.kind === 'images' && el.classList.contains('has-mo')) {   // 팀원 버전(mimages)으로 만든 zip: mo-pic = 휴대폰용 → 기본, pc-pic → PC 이미지
          var hmo = [], hpc = [], hhd = [], mfs = $$('figure', el);
          for (var mq = 0; mq < mfs.length; mq++) {
            var mimg = mfs[mq].querySelector('img'), mim = mimg ? await get(mimg.getAttribute('src'), mimg.getAttribute('alt'), dirBase) : null;
            if (mim) (mfs[mq].classList.contains('mo-pic') ? hmo : mfs[mq].classList.contains('pc-pic') ? hpc : hhd).push(mim);
          }
          rs.header = null; rs.images = hhd.concat(hmo.length ? hmo : hpc); rs.pcImages = hmo.length ? hhd.concat(hpc) : [];
        }
        return rs;
      };
      var readSection1 = async function (el, dirBase, labels) {
        if (el.classList.contains('video-sec')) return readVideo(el, dirBase, labels);
        if (el.classList.contains('text-sec')) {
          var tid = el.id, num = function (v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; };
          return textSection({
            id: S.sections.some(function (x) { return x.id === tid; }) ? uniqueId(tid) : tid, label: labels[tid] || '안내 문구', nav: tid in labels, order: 50,
            bg: el.getAttribute('data-bg') || '#ffffff', padY: num(el.getAttribute('data-pad'), 48),
            texts: $$('.tx', el).map(function (p) {
              return newTextItem({ text: textWithBreaks(p), font: p.getAttribute('data-font') || 'pretendard', bold: p.hasAttribute('data-bold'), size: num(p.getAttribute('data-size'), 22),
                color: p.getAttribute('data-color') || '#1a1a1a', align: p.getAttribute('data-align') || 'center', lh: num(p.getAttribute('data-lh'), 1.45), gap: num(p.getAttribute('data-gap'), 12) });
            })
          });
        }
        var id = el.id, key = id.replace(/^s-/, '');
        var tvEl = el.querySelector('.tv');
        var isTypes = el.classList.contains('types') || id === 's-type';
        var s = newSection({
          id: S.sections.some(function (x) { return x.id === id; }) ? uniqueId(id) : id,
          key: isTypes ? 'types' : (SECTION_DEFS[key] ? key : 'custom'),
          label: labels[id] || (isTypes ? '타입안내' : SECTION_DEFS[key] ? SECTION_DEFS[key].label : '섹션'),
          nav: id in labels, order: 50, mode: tvEl ? 'slide' : 'stack', tabs: !!el.querySelector('.tabs')
        });
        var pcFigs = $$('figure.pc-only img', el);
        var figs = $$('figure img', el).filter(function (img) { return !img.closest('.tv') && !img.closest('.pc-only'); });
        if (tvEl) {
          if (figs[0]) s.header = await get(figs[0].getAttribute('src'), figs[0].getAttribute('alt'), dirBase);
          var list = [];
          try { list = JSON.parse(tvEl.getAttribute('data-types') || '[]'); } catch (er) { list = []; }
          for (var t = 0; t < list.length; t++) {
            var tp = list[t][2] || ('img/type/type_' + String(list[t][0]).replace(/,/g, '') + '.jpg');
            if (dirBase !== base && !/^\.\.\//.test(tp)) tp = '../' + tp;   // data-types 경로는 메인 기준
            var tim = await get(tp, list[t][3] || '', dirBase);
            if (tim) { tim.label = String(list[t][0] == null ? '' : list[t][0]); s.images.push(tim); }
          }
          var inl = (tvEl.getAttribute('style') || '').match(/--tv-band:\s*([\d.]+)/);
          s.band = inl ? parseFloat(inl[1]) : tvEl.classList.contains('tv--mid') ? 0 : (bandM ? parseFloat(bandM[1]) : null);
        } else {
          for (var f2 = 0; f2 < figs.length; f2++) {
            var fim = await get(figs[f2].getAttribute('src'), figs[f2].getAttribute('alt'), dirBase);
            if (fim) s.images.push(fim);
          }
        }
        return s;
      };
      // 예전 이벤트 배너(반짝이 그림)는 '이벤트' 섹션으로
      var eventSection = async function (fig, dirBase) {
        var img = fig.querySelector('img');
        var s = newSection({ id: uniqueId('s-event'), key: 'event', label: '이벤트', nav: false, order: 1.5 });
        var eim = img ? await get(img.getAttribute('src'), img.getAttribute('alt'), dirBase) : null;
        if (eim) s.images.push(eim);
        return s;
      };
      var labelsOf = function (d) {
        var out = {};
        $$('.pc-right a', d).forEach(function (a) {
          var h = a.getAttribute('href') || '';
          if (!a.hasAttribute('data-nav-top') && h[0] === '#') out[h.slice(1)] = a.textContent.trim();
        });
        return out;
      };
      var navLabels = labelsOf(doc);
      var kidsOf = function (d) { return $$('.app > section[id], .app > figure.shine', d).filter(function (el) { return !el.classList.contains('hero'); }); };
      S.sections = [];
      S.mainSections = S.sections;
      var mainEvent = null;
      var kids = kidsOf(doc);
      for (var i = 0; i < kids.length; i++) {
        var el = kids[i];
        if (el.classList.contains('reserve')) {
          var fi = formItem(el.id in navLabels, navLabels[el.id] || '', formId());
          try { var fj = JSON.parse(el.getAttribute('data-fields') || '[]'); if (Array.isArray(fj) && fj.length) fi.fields = fj.map(function (x) { return { type: x.type || 'short', label: x.label || '', required: !!x.required, help: x.help || '', placeholder: x.placeholder || '', options: x.options || undefined, pos: x.pos || 'memo' }; }); } catch (e) {}
          if (el.hasAttribute('data-hide-memo')) fi.hideMemo = true;
          S.sections.push(fi); continue;
        }
        if (el.tagName === 'FIGURE') { mainEvent = await eventSection(el, base); S.sections.push(mainEvent); continue; }
        S.sections.push(await readSection(el, base, navLabels));
      }
      if (!formsOf(S.sections).length) S.sections.unshift(formItem('reserve' in navLabels, navLabels.reserve || ''));
      var lastSec = S.sections[S.sections.length - 1];
      if (lastSec && lastSec.kind === 'form' && S.sections.length > 1) lastSec.order = 999;
      // 원페이지 + 메뉴 페이지 zip: 메뉴 줄의 data-menus 로 메뉴를 다시 만들고, 페이지마다 섹션 읽기
      var mbarEl = doc.querySelector('.menubar[data-menus]');
      if (mbarEl) {
        S.siteMode = doc.documentElement.hasAttribute('data-pc') ? 'pc' : 'menu'; S.menus = []; S.pageTitle = false; S.pageForm = false;
        S.menuContact = !!mbarEl.querySelector('[data-contact]');
        var mdefs = []; try { mdefs = JSON.parse(mbarEl.getAttribute('data-menus')) || []; } catch (er) { mdefs = []; }
        var readMenuPage = async function (d) {
          var p = { id: newPid(), name: d.name || '메뉴', slug: cleanSlug(d.slug) || 'page', slugAuto: false, sections: [] };
          var pf = d.slug && zip.file(base + d.slug + '/index.html');
          if (!pf) return p;
          var pdoc = new DOMParser().parseFromString(await pf.async('string'), 'text/html');
          if (pdoc.querySelector('.page-title')) S.pageTitle = true;
          if (pdoc.documentElement.getAttribute('data-cw') === '860') p.cw = 860;
          else if (!pdoc.documentElement.hasAttribute('data-wide')) p.cw = 375;
          if (pdoc.querySelector('[data-leadyo-form]')) S.pageForm = true;
          var keep = S.sections; S.sections = p.sections;   // 섹션 id가 그 페이지 안에서만 겹치지 않게
          var pk = kidsOf(pdoc).filter(function (x) { return !x.classList.contains('reserve'); });
          for (var q2 = 0; q2 < pk.length; q2++) p.sections.push(await readSection(pk[q2], base + d.slug + '/', {}));
          S.sections = keep;
          return p;
        };
        for (var md = 0; md < mdefs.length; md++) {
          var dd = mdefs[md];
          if (dd.children && dd.children.length) {
            var grp = { id: newPid(), name: dd.name || '메뉴', slug: '', slugAuto: true, sections: [], children: [] };
            for (var mc = 0; mc < dd.children.length; mc++) grp.children.push(await readMenuPage(dd.children[mc]));
            S.menus.push(grp);
          } else S.menus.push(await readMenuPage(dd));
        }
      }
      // 방문예약 페이지: 메인에도 있는 섹션 → 둘 다, 거기에만 있는 섹션 → 방문예약만 (앞 섹션 바로 뒤에 끼워 넣음)
      var cf = zip.file(base + 'contact/index.html');
      if (cf) {
        var cdoc = new DOMParser().parseFromString(await cf.async('string'), 'text/html');
        var cLabels = labelsOf(cdoc), both = new Set(), prev = null;
        S.contactHero = !!cdoc.querySelector('.hero');
        S.contactFormBottom = cdoc.querySelectorAll('[data-leadyo-form]').length > 1;
        var ckids = kidsOf(cdoc).filter(function (x) { return !x.classList.contains('reserve'); });
        for (var c = 0; c < ckids.length; c++) {
          var cel = ckids[c], hit = null;
          if (cel.tagName === 'FIGURE') hit = mainEvent;
          else hit = S.sections.find(function (x) { return x.kind !== 'form' && x.id === cel.id && !x.where; });
          if (hit) { both.add(hit); prev = hit; continue; }
          var cs = cel.tagName === 'FIGURE' ? await eventSection(cel, base + 'contact/') : await readSection(cel, base + 'contact/', cLabels);
          cs.where = 'contact';
          S.sections.splice(prev ? S.sections.indexOf(prev) + 1 : 0, 0, cs);
          prev = cs;
        }
        S.sections.forEach(function (x) { if (x.kind !== 'form' && !x.where) x.where = both.has(x) ? 'both' : 'main'; });
      }
      allLists().forEach(function (L) {   // 묶음: 이어지는 칸은 머리 이름·보이는 곳을 따름
        fixJoins(L);
        L.forEach(function (x) { if (!x.join) return; var hh = headOf(L, x); x.label = hh.label; if (hh.where) x.where = hh.where; });
      });
      afterImagesChanged();
      render();
      undoReset();
      if (view === 'upload') setView('sections');
      toast('"' + (S.siteName || file.name) + '"을(를) 불러왔어요');
    } catch (err) {
      console.error(err);
      toast('zip을 읽지 못했어요: ' + (err && err.message || err));
    } finally { unbusy(); }
  }
  $('#import-zip').addEventListener('change', async function (e) { if (e.target.files[0]) await importZip(e.target.files[0]); e.target.value = ''; });

  /* =========================================================
     공식 홈페이지에서 가져오기 → 메뉴 페이지 (메뉴 구조 + 페이지마다 PC·모바일 이미지)
     - 서버가 홈페이지를 대신 읽어 줌 (브라우저는 보안상 다른 사이트를 직접 못 읽음). 단계별로 부름:
       메뉴 → 페이지마다 → 정리 → (모바일을 못 찾았으면) 파일명 규칙 찾기·확인. 형식은 서버 폴더 site-import-core.js 맨 위
     - 사내 서버로 열면 같은 서버의 api/site-scan, 깃허브 Pages(마법도구)·파일로 열면 Cloudflare Worker 중계 서버
       중계 서버 주소: 이 브라우저에 저장한 주소 → 없으면 <meta name="site-import-remote"> (처음 누를 때 물어봄)
     - 주소 뒤 ?siteimport=… 를 붙이면 그 주소를 씀
     ========================================================= */
  var metaOf = function (n) { var m = document.querySelector('meta[name="' + n + '"]'); return m ? String(m.content || '').trim() : ''; };
  var SCAN_LOCAL = metaOf('site-import-url') || 'api/site-scan', REMOTE_KEY = 'bunyang-editor-siteimport';
  var scanParam = (function () { var m = /[?&]siteimport=([^&]+)/.exec(location.search); return m ? decodeURIComponent(m[1]) : ''; })();
  var scanVia = !/^https?:$/.test(location.protocol) || /\.github\.io$/i.test(location.hostname) ? 'remote' : 'local';   // 파일만 보여 주는 곳 → 중계 서버
  function normRemote(v) {
    v = String(v || '').trim();
    if (!v) return '';
    if (!/^https?:\/\//i.test(v)) v = 'https://' + v;
    return /site-scan\/?$/.test(v) ? v : v.replace(/\/+$/, '') + '/api/site-scan';
  }
  function remoteUrl() { var v = ''; try { v = localStorage.getItem(REMOTE_KEY) || ''; } catch (e) { v = ''; } return normRemote(v || metaOf('site-import-remote')); }
  function scanEndpoint() { return scanParam || (scanVia === 'remote' ? remoteUrl() : SCAN_LOCAL); }
  var lastScan = null, scanBusy = false, SCAN_NOTE = $('#site-imp-note').textContent;
  var scanImg = function (u) {
    return scanEndpoint().replace(/site-scan\/?$/, 'site-img') + '?u=' + encodeURIComponent(u) + (lastScan ? '&ref=' + encodeURIComponent(lastScan.site.url) : '');
  };
  async function scanCall(body) {
    var r = await fetch(scanEndpoint(), { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=UTF-8' }, body: JSON.stringify(body), cache: 'no-store' });
    var d = await r.json().catch(function () { return null; });
    if (!r.ok || !d) { var e = new Error(d && d.error ? d.error : 'HTTP ' + r.status); e.status = r.status; throw e; }
    return d;
  }
  // 깃허브 Pages에서 쓰는 중계 서버 주소 (이 컴퓨터 브라우저에 기억)
  function askRemote(msg) {
    modal('<h3>중계 서버 주소를 넣어 주세요</h3>' +
      '<p class="desc" style="margin:0">깃허브 Pages(마법도구) 에디터는 Cloudflare에 만든 중계 서버를 거쳐서 홈페이지를 읽어요. 브라우저는 보안상 다른 사이트를 직접 못 읽어서요.</p>' +
      (msg ? '<p class="desc" style="margin:8px 0 0;color:var(--err)">' + esc(msg) + '</p>' : '') +
      '<div class="field" style="margin:12px 0 0"><label for="remote-url">중계 서버 주소</label>' +
      '<input class="inp" id="remote-url" spellcheck="false" autocomplete="off" placeholder="https://bunyang-import.○○○.workers.dev" value="' + esc(remoteUrl().replace(/\/api\/site-scan$/, '')) + '">' +
      '<div class="note">이 컴퓨터 브라우저에 기억돼요. 아직 없으면 분양랜딩_에디터_서버 → cloudflare → 설정방법.txt 대로 만들어 주세요. 사내 서버(http://서버 IP:8080/)로 연 에디터에선 없어도 돼요.</div></div>' +
      '<div class="acts"><button class="btn" type="button" data-close>취소</button><button class="btn primary" type="button" data-remote="save">저장하고 읽기</button></div>');
    var i = $('#remote-url'); if (i) { i.focus(); i.select(); }
  }
  function saveRemote() {
    var raw = ($('#remote-url') || { value: '' }).value.trim(), v = normRemote(raw);
    if (v && !/^https:\/\//i.test(v) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//i.test(v)) { toast('https:// 로 시작하는 주소를 넣어 주세요'); return; }
    try { if (v) localStorage.setItem(REMOTE_KEY, v); else localStorage.removeItem(REMOTE_KEY); } catch (e) { /* 저장 못 해도 이번엔 씀 */ }
    $('#modal').hidden = true;
    renderRemote();
    if (!v) { toast('저장한 중계 서버 주소를 지웠어요'); return; }
    toast('중계 서버 주소를 저장했어요');
    if ($('#f-site-url').value.trim()) siteScan();
  }
  // 사내 에디터 주소 (<meta name="site-import-office">): 중계 서버가 없는 곳(마법도구)에서 가져오기를 누르면 여기로 안내
  var SCAN_OFFICE = metaOf('site-import-office');
  function officeHref(url) { return SCAN_OFFICE.replace(/\/*$/, '/') + (url ? '?siteurl=' + encodeURIComponent(url) : ''); }
  function askOffice() {
    var url = $('#f-site-url').value.trim();
    modal('<h3>홈페이지 가져오기는 새 탭에서 해요</h3>' +
      '<p class="desc" style="margin:0">공식 홈페이지는 회사 컴퓨터가 대신 읽어 와요. 아래 버튼을 누르면 가져오기가 되는 에디터가 새 탭으로 열려요.</p>' +
      '<ol class="office-steps"><li>아래 <b>가져오기 화면 열기</b>를 눌러요</li><li>새 탭에서 <b>메뉴 읽기</b>를 눌러요' + (url ? ' (홈페이지 주소는 채워져 있어요)' : ' (홈페이지 주소를 넣고)') + '</li></ol>' +
      '<p style="margin:12px 0 0"><a class="btn primary" href="' + esc(officeHref(url)) + '" target="_blank" rel="noopener">가져오기 화면 열기</a></p>' +
      '<div class="note">지금 화면에서 하던 작업은 새 탭에 저절로 안 넘어가요. 이어서 하려면 여기서 [zip 만들기] → 새 탭에서 [zip 불러오기].<br>안 열리면: 회사 컴퓨터(' + esc(SCAN_OFFICE.replace(/^https?:\/\//, '').replace(/\/+$/, '')) + ')에서 서버_시작.bat 검은 창이 켜져 있는지 봐 주세요. 회사 안 인터넷에서만 열려요.</div>' +
      '<div class="acts"><button class="btn" type="button" data-close>닫기</button></div>');
  }
  function renderRemote() {
    var b = $('#site-remote'); if (!b) return;
    var on = scanVia === 'remote' && !scanParam, r = on ? remoteUrl() : '';
    b.hidden = !on;
    if (!on) return;
    var h = r; try { h = new URL(r).host; } catch (e) { h = r; }
    b.textContent = r ? '중계 서버: ' + h + ' · 바꾸기' : SCAN_OFFICE ? '여기선 가져오기가 안 돼요 → 가져오기 화면 열기' : '중계 서버 주소 넣기 (깃허브 Pages에서 쓸 때)';
  }
  // 중계 서버 주소가 없을 때: 사내 에디터 주소가 있으면 거기로 안내, 없으면 중계 서버 주소를 물어봄
  function noRemote(msg) { if (SCAN_OFFICE) askOffice(); else askRemote(msg); }
  function scanProgress(txt, pct) { var t = $('#scan-txt'), p = $('#scan-pg'); if (t) t.textContent = txt; if (p) p.style.width = pct + '%'; }
  var IMP_SKIP = /관심고객|고객등록|언론|보도|뉴스|공지|게시판|당첨|조회|로그인|회원/;   // 이미지가 있어도 처음엔 안 고르는 페이지
  var IMP_MIN_W = 400;   // 이보다 좁은 이미지(키맵·아이콘 등)는 기본으로 뺌
  function scanNote(msg, bad) { var n = $('#site-imp-note'); n.textContent = msg || SCAN_NOTE; n.style.color = bad ? 'var(--err)' : ''; }
  async function siteScan() {
    var inp = $('#f-site-url'), url = inp.value.trim();
    if (!url) { inp.focus(); toast('공식 홈페이지 주소를 넣어 주세요'); return; }
    if (scanBusy) return;
    if (!scanEndpoint()) { noRemote(); return; }   // 깃허브 Pages인데 중계 서버 주소가 없음
    var btn = $('#site-scan');
    btn.disabled = true; scanBusy = true; scanNote('읽는 중…');
    modal('<h3>홈페이지 읽는 중…</h3><div class="progress"><i id="scan-pg" style="width:3%"></i></div><div class="desc" id="scan-txt">메뉴 읽는 중</div>');
    try {
      var m;
      try { m = await scanCall({ op: 'menu', url: url }); }
      catch (e) {
        // 연 서버에 가져오기 기능이 없으면(예전 서버·다른 곳에 올린 에디터) 중계 서버로 바꿔서 다시
        if (scanParam || scanVia !== 'local' || (e.status !== 404 && e.status !== 405)) throw e;
        scanVia = 'remote'; renderRemote();
        if (!remoteUrl()) { scanNote(''); noRemote('이 서버엔 가져오기 기능이 없어서 중계 서버를 거쳐야 해요'); return; }
        m = await scanCall({ op: 'menu', url: url });
      }
      // 페이지마다 (4개씩 동시에)
      var pages = {}, done = 0, next = 0, N = m.pages.length;
      scanProgress('페이지 읽는 중 0 / ' + N, 8);
      await Promise.all([0, 1, 2, 3].map(async function () {
        while (next < N) {
          var p = m.pages[next++];
          pages[p.url] = await scanCall({ op: 'page', url: p.url, name: p.name, mo: m.mo }).catch(function (e) { return { pc: [], mo: [], err: e.message || String(e) }; });
          done++;
          scanProgress('페이지 읽는 중 ' + done + ' / ' + N, 8 + Math.round(done / Math.max(1, N) * 77));
        }
      }));
      var f = await scanCall({ op: 'finish', pages: pages }), how = f.how;
      // 페이지 안에서도, 휴대폰으로 열어도 모바일 이미지가 안 보이면: 파일명 규칙(m_파일 등)을 찾아서 이미지마다 확인
      if (!how) {
        scanProgress('모바일 이미지 규칙 찾는 중', 87);
        var pat = { k: -1 };
        for (var si = 0; si < f.samples.length && pat.k < 0; si++) pat = await scanCall({ op: 'probe', url: f.samples[si], ref: m.site.url });
        if (pat.k >= 0) {
          var all = [], found = {};
          Object.keys(f.pages).forEach(function (u) { f.pages[u].pc.forEach(function (v) { if (all.indexOf(v) < 0) all.push(v); }); });
          for (var c = 0; c < all.length; c += 25) {
            var part = all.slice(c, c + 25), cr = await scanCall({ op: 'check', k: pat.k, urls: part, ref: m.site.url });
            part.forEach(function (v, j) { if (cr.found[j]) found[v] = cr.found[j]; });
            scanProgress('모바일 이미지 확인 중 ' + Math.min(c + 25, all.length) + ' / ' + all.length, 90 + Math.round(Math.min(c + 25, all.length) / all.length * 10));
          }
          Object.keys(f.pages).forEach(function (u) {
            var P = f.pages[u], mo = P.pc.map(function (v) { return found[v] || v; });
            if (mo.some(function (v, j) { return v !== P.pc[j]; })) P.mo = mo;
          });
          how = '모바일 이미지 파일명 규칙: ' + pat.name;
        } else how = '모바일용 이미지를 따로 못 찾았어요 (휴대폰에서도 PC 이미지를 써요)';
      }
      lastScan = { site: m.site, menus: m.menus, pages: f.pages, how: how, skipped: m.skipped };
      scanNote('');
      openScan(lastScan);
    } catch (err) {
      var msg = err.message || String(err);
      if (/failed to fetch|networkerror|load failed/i.test(msg)) msg = scanVia === 'remote' ? '중계 서버에 연결이 안 돼요 (주소를 확인해 주세요)' : '서버에 연결이 안 돼요';
      $('#modal').hidden = true;
      scanNote('못 읽었어요: ' + msg, true);
      if (scanVia === 'remote' && !scanParam && (err.status === 403 || /중계 서버에 연결/.test(msg))) askRemote(msg);
      else toast('홈페이지를 못 읽었어요: ' + msg);
    } finally { btn.disabled = false; scanBusy = false; }
  }
  // 메뉴 순서대로 페이지 한 줄씩: {item:{name,url}, parent, P:{pc,mo,err}}
  function scanRows(d) {
    var out = [];
    d.menus.forEach(function (m) {
      if (m.children.length) m.children.forEach(function (c) { out.push({ item: c, parent: m }); });
      else if (m.url) out.push({ item: m, parent: null });
    });
    out.forEach(function (x) { x.P = d.pages[x.item.url] || { pc: [], mo: [], err: '페이지가 많아서 안 읽었어요' }; });
    return out;
  }
  var pathOf = function (u) { try { var x = new URL(u); return decodeURIComponent(x.pathname + x.search); } catch (e) { return u; } };
  function openScan(d) {
    var rows = scanRows(d), seen = {}, lastGrp = null, moPages = 0;
    var hadPages = menuPages().some(function (x) { return (x.page.sections || []).some(filled); });
    var list = rows.map(function (x, k) {
      var P = x.P, n = P.pc.length, nm = P.mo.length, on = n > 0 && !IMP_SKIP.test(x.item.name) && !seen[x.item.url];
      seen[x.item.url] = 1;
      if (nm) moPages++;
      var head = x.parent && x.parent !== lastGrp ? '<div class="imp-grp">' + esc(x.parent.name) + '</div>' : '';
      lastGrp = x.parent;
      var ct = P.err ? '<em>' + esc(P.err) + '</em>' : !n ? '이미지 없음' : 'PC ' + n + '장 · ' + (nm ? '<b>모바일 ' + nm + '장</b>' : '모바일 같음');
      return head + '<label class="imp-row' + (x.parent ? ' is-sub' : '') + '"><input type="checkbox" data-imp="' + k + '"' + (on ? ' checked' : '') + (n ? '' : ' disabled') + '>' +
        (n ? '<img class="imp-pic" loading="lazy" src="' + esc(scanImg(P.pc[0])) + '" alt="">' : '<span class="imp-pic"></span>') +
        '<span class="imp-nm" title="' + esc(x.item.url) + '">' + esc(x.item.name) + '<small>' + esc(pathOf(x.item.url)) + '</small></span><span class="imp-ct">' + ct + '</span></label>';
    }).join('');
    modal('<h3>가져올 메뉴 페이지 고르기</h3>' +
      '<p class="imp-sum"><b>' + esc(d.site.title || pathOf(d.site.url)) + '</b> · 메뉴 ' + d.menus.length + '개 · 페이지 ' + rows.length + '개' + (moPages ? ' · 모바일 이미지가 따로 있는 페이지 ' + moPages + '개' : '') + '<br>' + esc(d.how || '') +
      (d.skipped ? '<br>페이지가 많아서 ' + d.skipped + '개는 안 읽었어요' : '') + '</p>' +
      '<div class="imp-tools"><button class="link" type="button" data-imp-all="1">모두 고르기</button><button class="link" type="button" data-imp-all="0">모두 빼기</button></div>' +
      '<div class="imp-list">' + list + '</div>' +
      '<div class="imp-opts">' +
      '<label class="chk"><input type="radio" name="imp-mode" value="replace"' + (hadPages ? '' : ' checked') + '>지금 메뉴를 이걸로 바꾸기' + (hadPages ? ' (지금 메뉴 페이지에 넣은 건 지워져요 · Ctrl+Z로 되돌릴 수 있어요)' : '') + '</label>' +
      '<label class="chk"><input type="radio" name="imp-mode" value="append"' + (hadPages ? ' checked' : '') + '>지금 메뉴 뒤에 붙이기</label>' +
      '<label class="chk"><input type="checkbox" id="imp-small" checked>가로 ' + IMP_MIN_W + 'px 안 되는 작은 이미지(키맵·아이콘 등)는 빼기</label>' +
      '</div>' +
      '<div class="acts"><button class="btn" type="button" data-close>취소</button><button class="btn primary" type="button" id="imp-go"></button></div>', 'wide');
    impCount();
  }
  function impPicks() { return $$('#modal-box [data-imp]').filter(function (c) { return c.checked && !c.disabled; }).map(function (c) { return +c.getAttribute('data-imp'); }); }
  function impCount() {
    var b = $('#imp-go'); if (!b) return;
    var n = impPicks().length;
    b.textContent = n ? n + '페이지 가져오기' : '페이지를 골라 주세요';
    b.disabled = !n;
  }
  // 메뉴 페이지 주소: 이름으로 정한 영문(입지환경 → location)이 없으면 원래 주소의 파일 이름 (unit_84a.html → unit-84a)
  function slugFor(item) {
    var a = autoSlug(item.name), f = '';
    if (a !== 'page') return a;
    try { f = decodeURIComponent(new URL(item.url).pathname.split('/').filter(Boolean).pop() || ''); } catch (e) { f = ''; }
    f = cleanSlug(f.replace(/\.[a-z0-9]+$/i, ''));
    return f && !/^(index|sub|page|view|main|default|content|contents)$/.test(f) ? f : 'page';
  }
  async function importScan(d, picks, mode, dropSmall) {
    var rows = scanRows(d).filter(function (x, k) { return picks.indexOf(k) >= 0; });
    var jobs = [];
    rows.forEach(function (x) {
      x.pc = []; x.mo = [];
      x.P.pc.forEach(function (u, j) { jobs.push({ x: x, list: 'pc', j: j, u: u }); });
      x.P.mo.forEach(function (u, j) { jobs.push({ x: x, list: 'mo', j: j, u: u }); });
    });
    modal('<h3>이미지 가져오는 중…</h3><div class="progress"><i id="pg"></i></div><div class="desc" id="pg-txt">0 / ' + jobs.length + '</div>');
    var done = 0, fail = 0, small = 0, next = 0, byUrl = {};
    // 같은 이미지(모바일이 따로 없어서 PC와 같은 것)는 한 번만 받아서 같이 씀
    var load = function (u) {
      if (!byUrl[u]) byUrl[u] = (async function () {
        var r = await fetch(scanImg(u));
        if (!r.ok) throw new Error('HTTP ' + r.status);
        var name = '';
        try { name = decodeURIComponent(new URL(u).pathname.split('/').pop()); } catch (e) { name = ''; }
        var blob = await r.blob();
        if (!/\.(png|jpe?g|webp|gif)$/i.test(name)) name = (name.replace(/\.[^.]*$/, '') || 'image') + (/png/.test(blob.type) ? '.png' : /webp/.test(blob.type) ? '.webp' : /gif/.test(blob.type) ? '.gif' : '.jpg');
        return loadImg(blob, name);
      })();
      return byUrl[u];
    };
    var one = async function (jb) {
      try {
        var im = await load(jb.u);
        if (dropSmall && im.w < IMP_MIN_W) small++;
        else jb.x[jb.list][jb.j] = im;
      } catch (e) { fail++; }
      done++;
      var bar = $('#pg'), txt = $('#pg-txt');
      if (bar) bar.style.width = Math.round(done / jobs.length * 100) + '%';
      if (txt) txt.textContent = done + ' / ' + jobs.length + (fail ? ' · 못 받음 ' + fail : '');
    };
    await Promise.all([0, 1, 2, 3].map(async function () { while (next < jobs.length) await one(jobs[next++]); }));

    if (mode === 'replace') state.menus = [];
    state.menus = state.menus || [];
    var firstPage = null, nPage = 0, nPc = 0, nMo = 0, nMoPage = 0, ids = new Set();
    var fill = function (p, x) {
      var pc = x.pc.filter(Boolean), mo = x.mo.filter(Boolean);
      if (!pc.length) { pc = mo; mo = []; }
      if (mo.length === pc.length && mo.every(function (im, k) { return im === pc[k]; })) mo = [];
      var maxW = pc.reduce(function (t, im) { return Math.max(t, im.w); }, 0);
      p.cw = maxW >= 1100 ? 1200 : maxW >= 760 ? 860 : 375;   // 이미지 폭에 맞춰 1200 · 860 · 375
      p.slugAuto = false;
      p.slug = uniqueSlug(slugFor(x.item), p);
      // 휴대폰용이 따로 있으면 기본 이미지 = 휴대폰용, PC 이미지 = PC용(넓은 화면에서만). 없으면 PC용 하나로
      p.sections = pc.length ? [newSection({ id: 's-' + (p.slug.replace(/[^a-z0-9]+/g, '') || 'img'), key: 'custom', label: x.item.name, nav: false, images: mo.length ? mo : pc })] : [];
      if (mo.length) { p.sections[0].pcImages = pc; nMoPage++; }
      pc.concat(mo).forEach(function (im) { ids.add(im.id); });
      nPc += pc.length; nMo += mo.length; nPage++;
      if (!firstPage) firstPage = p;
    };
    var groups = [];
    rows.forEach(function (x) {
      var g = groups[groups.length - 1];
      if (x.parent && g && g.parent === x.parent) g.rows.push(x); else groups.push({ parent: x.parent, rows: [x] });
    });
    groups.forEach(function (g) {
      if (!g.parent || g.rows.length === 1) {   // 소메뉴를 하나만 고르면 펼침 없이 그 페이지 하나로
        var p = newMenuPage((g.rows[0].item.name || '메뉴').slice(0, 14));
        state.menus.push(p); fill(p, g.rows[0]);
        return;
      }
      var grp = { id: newPid(), name: g.parent.name.slice(0, 14), slug: '', slugAuto: true, sections: [], children: [] };
      state.menus.push(grp);
      g.rows.forEach(function (x) { var c = newMenuPage(x.item.name.slice(0, 14)); grp.children.push(c); fill(c, x); });
    });
    if (state.siteMode === 'single') state.siteMode = 'menu';   // PC 최적화였으면 그대로
    var filledIn = [];
    if (!state.siteName.trim() && d.site.title) { state.siteName = d.site.title; if (state.titleAuto) state.heroTitle = splitTitle(d.site.title); filledIn.push('현장명'); }
    if (!state.phone.trim() && d.site.phone) { state.phone = d.site.phone; filledIn.push('대표번호'); }
    relinkEditing();
    if (firstPage) { pv.page = firstPage.slug; pv.keepScroll = false; }
    afterImagesChanged();
    render();
    setView('menus');
    modal('<h3>가져왔어요</h3><ul class="checks">' +
      '<li class="ok">메뉴 페이지 ' + nPage + '개 · PC 이미지 ' + nPc + '장</li>' +
      '<li class="ok">' + (nMoPage ? '모바일 이미지가 따로 있는 페이지 ' + nMoPage + '개 · 모바일 이미지 ' + nMo + '장 (휴대폰에선 이걸로, PC에선 섹션의 \'PC 이미지\'로 나와요)' : '모바일 이미지가 따로 있는 페이지는 없어요 (휴대폰에서도 PC 이미지를 써요)') + '</li>' +
      (small ? '<li class="warn">가로 ' + IMP_MIN_W + 'px 안 되는 작은 이미지 ' + small + '장은 뺐어요</li>' : '') +
      (fail ? '<li class="warn">못 받은 이미지 ' + fail + '장 (홈페이지를 다시 읽고 가져와 보세요)</li>' : '') +
      (filledIn.length ? '<li class="ok">비어 있던 ' + filledIn.join('·') + '을(를) 홈페이지 것으로 채웠어요</li>' : '') +
      '</ul><p class="desc" style="margin:12px 0 0">위쪽 페이지 탭에서 페이지마다 확인해 보세요. 미리보기를 모바일 ↔ PC로 바꾸면 이미지가 바뀌어 나와요. 마음에 안 들면 Ctrl+Z로 되돌릴 수 있어요.</p>' +
      '<div class="acts"><button class="btn primary" type="button" data-close>확인</button></div>');
    // 안 쓰게 된 이미지(작아서 뺀 것)의 주소는 정리
    Object.keys(byUrl).forEach(function (u) { byUrl[u].then(function (im) { if (!ids.has(im.id)) URL.revokeObjectURL(im.url); }, function () {}); });
  }
  $('#site-scan').addEventListener('click', siteScan);
  $('#f-site-url').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); siteScan(); } });
  $('#site-remote').addEventListener('click', function () { if (!remoteUrl()) noRemote(); else askRemote(); });
  $('#modal-box').addEventListener('keydown', function (e) { if (e.target.id === 'remote-url' && e.key === 'Enter' && !e.isComposing) { e.preventDefault(); saveRemote(); } });
  renderRemote();
  $('#goto-imp').addEventListener('click', function () { setView('menus'); var i = $('#f-site-url'); if (i) { i.focus(); i.scrollIntoView({ block: 'center', behavior: 'smooth' }); } });
  $('#modal-box').addEventListener('change', function (e) { if (e.target.hasAttribute('data-imp')) impCount(); });
  $('#modal-box').addEventListener('click', function (e) {
    if (e.target.closest('[data-remote="save"]')) { saveRemote(); return; }
    if (e.target.closest('[data-remote="ask"]')) { askRemote(); return; }
    var all = e.target.closest('[data-imp-all]');
    if (all) { $$('#modal-box [data-imp]').forEach(function (c) { if (!c.disabled) c.checked = all.getAttribute('data-imp-all') === '1'; }); impCount(); return; }
    if (e.target.id !== 'imp-go' || !lastScan) return;
    var mode = ($('#modal-box input[name="imp-mode"]:checked') || { value: 'replace' }).value, small = ($('#imp-small') || { checked: true }).checked;
    importScan(lastScan, impPicks(), mode, small).catch(function (err) {
      console.error(err);
      modal('<h3>가져오지 못했어요</h3><p class="desc">' + esc(err && err.message || err) + '</p><div class="acts"><button class="btn primary" type="button" data-close>닫기</button></div>');
    });
  });

  /* =========================================================
     모달·토스트·작업 중 표시
     ========================================================= */
  function modal(html, cls) { var bx = $('#modal-box'); bx.className = 'modal-box' + (cls ? ' ' + cls : ''); bx.innerHTML = html; $('#modal').hidden = false; }
  $('#modal').addEventListener('click', function (e) { if (e.target.id === 'modal' || e.target.hasAttribute('data-close')) $('#modal').hidden = true; });
  var busyN = 0;
  function busy(msg) { busyN++; modal('<h3>' + esc(msg) + '</h3><div class="progress"><i style="width:100%;opacity:.35"></i></div>'); }
  function unbusy() { busyN = Math.max(0, busyN - 1); if (!busyN) $('#modal').hidden = true; }
  var toastT;
  function toast(msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('is-on');
    clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('is-on'); }, 2800);
  }
  window.addEventListener('beforeunload', function (e) {
    // 자동 저장이 켜져 있으면 그냥 닫아도 됨 (다음에 열면 이어서)
    if (!storeReady && (state.heroBg || state.sections.some(filled))) { e.preventDefault(); e.returnValue = ''; }
  });

  // 다크 / 라이트 토글 (고른 값은 다음에 열어도 유지)
  (function () {
    var btn = $('#theme-toggle');
    if (!btn) return;
    var sync = function () {
      var light = document.documentElement.getAttribute('data-theme') === 'light';
      btn.setAttribute('aria-checked', light);
      btn.setAttribute('aria-label', light ? '다크 모드로' : '라이트 모드로');
    };
    btn.addEventListener('click', function () {
      var next = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', next);
      try { localStorage.setItem('bunyang-editor-theme', next); } catch (e) {}
      sync();
    });
    sync();
  })();

  /* =========================================================
     자동 저장 · 작업 내역 (이 컴퓨터 브라우저 안 IndexedDB, 인터넷 필요 없음)
     - 자동 저장: 고칠 때마다 1.5초 뒤 최신 상태 하나만 덮어씀 → 창이 꺼져도 다음에 열면 이어서
     - 작업 내역: 최근 10개까지만 (zip 만들 때 · zip 불러오기 전 · 작업 중 10분마다 · '지금 저장')
     - 이미지는 한 번만 저장해서 내역끼리 같이 쓰고, 아무 데서도 안 쓰는 이미지는 지움
     ========================================================= */
  var DB_NAME = 'bunyang-editor', HISTORY_MAX = 10, AUTO_KEEP = 3, HIST_EVERY = 10 * 60 * 1000;
  var SID = Math.random().toString(36).slice(2, 10);   // 이 창(탭) 표시
  var autoKey = 'auto:' + SID, storeReady = false, storeInitDone = false, savedBlobs = new Set();
  var autoT = null, lastAutoJson = '', lastHistJson = '', lastHistTime = Date.now(), storeQ = Promise.resolve();
  var HIST_KIND = { export: 'zip 만듦', import: '불러오기 전', timer: '작업 중 자동 보관', manual: '직접 저장', restore: '되돌리기 전', left: '지난번 자동 저장본', auto: '자동 저장본 (다른 창이나 지난 작업)' };

  var dbp = null;
  function db() {
    if (!dbp) dbp = new Promise(function (res, rej) {
      if (!window.indexedDB) { rej(new Error('이 브라우저는 저장소를 못 써요')); return; }
      var r = indexedDB.open(DB_NAME, 1), done = false;
      var fail = function (err) { if (done) return; done = true; clearTimeout(to); dbp = null; rej(err); };
      // 다른 창이 저장소를 막고 있으면 영원히 기다리지 않고 6초 뒤 포기 (나중에 다시 시도)
      var to = setTimeout(function () { fail(new Error('저장소가 다른 창에 막혀 있어요')); }, 6000);
      r.onupgradeneeded = function () { r.result.createObjectStore('blobs', { keyPath: 'key' }); r.result.createObjectStore('snaps', { keyPath: 'key' }); };
      r.onsuccess = function () {
        var d = r.result;
        d.onversionchange = function () { d.close(); dbp = null; };   // 다른 창이 저장소를 새로 만들거나 지우려 하면 비켜 줌
        if (done) { d.close(); return; }
        done = true; clearTimeout(to); res(d);
      };
      r.onerror = function () { fail(r.error); };
    });
    return dbp;
  }
  function idb(store, mode, fn) {
    return db().then(function (d) {
      return new Promise(function (res, rej) {
        var t = d.transaction(store, mode), out = { v: undefined };
        fn(t.objectStore(store), out);
        t.oncomplete = function () { res(out.v); };
        t.onerror = t.onabort = function () { rej(t.error); };
      });
    });
  }
  var getAll = function (store) { return idb(store, 'readonly', function (st, out) { st.getAll().onsuccess = function (e) { out.v = e.target.result; }; }); };
  var getAllKeys = function (store) { return idb(store, 'readonly', function (st, out) { st.getAllKeys().onsuccess = function (e) { out.v = e.target.result; }; }); };
  var putAll = function (store, items) { return idb(store, 'readwrite', function (st) { items.forEach(function (it) { st.put(it); }); }); };
  var delAll = function (store, keys) { return idb(store, 'readwrite', function (st) { keys.forEach(function (k) { st.delete(k); }); }); };
  var getBlobs = function (keys) {
    return idb('blobs', 'readonly', function (st, out) {
      out.v = {};
      keys.forEach(function (k) { st.get(k).onsuccess = function (e) { if (e.target.result) out.v[k] = e.target.result.blob; }; });
    });
  };
  // 저장소 작업은 한 줄로 (자동 저장과 정리가 엇갈리지 않게)
  function queued(fn) { var p = storeQ.then(fn); storeQ = p.catch(function () {}); return p; }

  function hasWork() { return !!(state.heroBg || state.logo || allSecs().some(filled) || state.siteName.trim()); }
  function imgCount() {
    return (state.heroBg ? 1 : 0) + (state.badge ? 1 : 0) +
      allSecs().reduce(function (a, s) { return a + (s.images ? s.images.length : 0) + (s.header ? 1 : 0); }, 0);
  }
  // 상태 → 글자(JSON) + 이미지 목록. 이미지는 dbKey로만 가리킴
  function snapshot() {
    var refs = [], fresh = [];
    var json = JSON.stringify(state, function (k, v) {
      if (k === 'detecting') return undefined;
      if (k === 'sections' && this === state) return undefined;
      if (v && typeof v === 'object' && v.blob instanceof Blob) {
        if (!v.dbKey) v.dbKey = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
        if (refs.indexOf(v.dbKey) < 0) { refs.push(v.dbKey); if (!savedBlobs.has(v.dbKey)) fresh.push({ key: v.dbKey, blob: v.blob }); }
        var o = { $img: 1 };
        Object.keys(v).forEach(function (x) { if (x !== 'blob' && x !== 'url') o[x] = v[x]; });
        return o;
      }
      return v;
    });
    return { json: json, refs: refs, fresh: fresh };
  }
  async function writeSnap(key, kind, label, s) {
    if (s.fresh.length) { await putAll('blobs', s.fresh); s.fresh.forEach(function (b) { savedBlobs.add(b.key); }); }
    await putAll('snaps', [{ key: key, kind: kind, label: label || '', time: Date.now(), site: state.siteName.trim(), imgCount: imgCount(), json: s.json, refs: s.refs }]);
  }
  async function prune() {
    var all = await getAll('snaps'), now = Date.now();
    var hist = all.filter(function (x) { return x.kind !== 'auto'; }).sort(function (a, b) { return b.time - a.time; });
    var autos = all.filter(function (x) { return x.kind === 'auto'; }).sort(function (a, b) { return b.time - a.time; });
    var drop = hist.slice(HISTORY_MAX).concat(autos.slice(AUTO_KEEP).filter(function (a) { return a.key !== autoKey && now - a.time > 60000; }));
    if (drop.length) await delAll('snaps', drop.map(function (d) { return d.key; }));
    var used = new Set();
    all.forEach(function (x) { if (drop.indexOf(x) < 0) x.refs.forEach(function (r) { used.add(r); }); });
    var orphan = (await getAllKeys('blobs')).filter(function (k) { return !used.has(k); });
    if (orphan.length) { await delAll('blobs', orphan); orphan.forEach(function (k) { savedBlobs.delete(k); }); }
  }

  function setSaveState(txt, bad) { var el = $('#save-state'); if (el) { el.textContent = txt; el.classList.toggle('bad', !!bad); } }
  var hhmm = function (t) { var d = new Date(t); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); };
  var when = function (t) { var d = new Date(t), today = new Date().toDateString() === d.toDateString(); return (today ? '오늘 ' : (d.getMonth() + 1) + '/' + d.getDate() + ' ') + hhmm(t); };

  function scheduleAutosave() { if (!storeReady) return; clearTimeout(autoT); autoT = setTimeout(autosave, 1500); }
  function autosave() {
    clearTimeout(autoT);
    if (!storeReady || !hasWork()) return Promise.resolve();
    return queued(async function () {
      var s = snapshot();
      if (s.json === lastAutoJson) return;
      if (pendingResume) { var pr = pendingResume; pendingResume = null; await autoToHistory([pr]); }   // 답 없이 새로 작업 시작
      setSaveState('저장 중…');
      try {
        await writeSnap(autoKey, 'auto', '자동 저장', s);
        lastAutoJson = s.json;
        setSaveState('자동 저장됨 ' + hhmm(Date.now()));
        if (Date.now() - lastHistTime > HIST_EVERY && s.json !== lastHistJson) {   // 오래 작업하면 10분마다 내역에 하나
          await writeSnap(histKey(), 'timer', '', s);
          lastHistJson = s.json; lastHistTime = Date.now();
          await prune();
        }
      } catch (err) {
        console.error(err);
        setSaveState('자동 저장 안 됨', true);
        toast('자동 저장을 못 했어요: ' + (err && err.message || err));
      }
    });
  }
  function histKey() { return 'h:' + Date.now().toString(36) + ':' + SID + Math.random().toString(36).slice(2, 5); }
  // 이어서 하지 않은 자동 저장본은 버리지 않고 작업 내역으로 옮김
  async function autoToHistory(recs) {
    if (!recs.length) return;
    await putAll('snaps', recs.map(function (r) { return Object.assign({}, r, { key: histKey(), kind: 'left', label: '' }); }));
    await delAll('snaps', recs.map(function (r) { return r.key; }));
    await prune();
  }
  var pendingResume = null;   // 물어봤는데 아직 답 안 한 자동 저장본
  // 작업 내역에 하나 남기기 (바뀐 게 없으면 안 쌓음, '지금 저장'은 항상)
  function addHistory(kind, label) {
    if (!storeReady || !hasWork()) return Promise.resolve();
    return queued(async function () {
      var s = snapshot();
      if (s.json === lastHistJson && kind !== 'manual') return;
      await writeSnap(histKey(), kind, label, s);
      lastHistJson = s.json; lastHistTime = Date.now();
      await prune();
    });
  }
  // 저장본 → 상태
  async function loadSnap(rec) {
    var data = JSON.parse(rec.json), blobs = await getBlobs(rec.refs), missing = 0;
    var walk = function (v) {
      if (Array.isArray(v)) return v.map(walk).filter(function (x) { return x !== null; });
      if (v && typeof v === 'object') {
        if (v.$img) {
          var b = blobs[v.dbKey];
          if (!b) { missing++; return null; }
          delete v.$img; v.blob = b; v.url = URL.createObjectURL(b);
          if (v.id !== 'logo') v.id = uid();
          return v;
        }
        Object.keys(v).forEach(function (k) { v[k] = walk(v[k]); });
      }
      return v;
    };
    var restored = walk(data);
    state = Object.assign(freshState(), restored);
    state.mainSections = restored.mainSections || restored.sections || state.mainSections;   // 예전 저장본은 sections만 있음
    relinkEditing();
    allSecs().forEach(function (s) { if (s.kind === 'images') s.detecting = false; });
    lastAutoJson = ''; lastHistJson = rec.json;
    render();
    afterImagesChanged();
    undoReset();
    if (view === 'upload') setView('sections');
    if (missing) toast('이미지 ' + missing + '장은 저장소에서 찾지 못해서 빠졌어요');
  }

  // 작업 내역 창
  async function openHistory() {
    if (!storeReady) { toast('이 브라우저에서는 작업 내역을 저장할 수 없어요'); return; }
    await autosave();
    // 다른 창·지난 작업의 자동 저장본도 같이 보여 줌 (지금 이 창의 자동 저장은 빼고) → 질문 창이 안 떠도 언제든 꺼낼 수 있게
    var all = (await getAll('snaps')).filter(function (x) { return x.kind !== 'auto' || (x.key !== autoKey && (x.imgCount || x.site)); }).sort(function (a, b) { return b.time - a.time; });
    modal('<h3>작업 내역</h3>' +
      '<p class="desc" style="margin:0 0 10px">이 컴퓨터 브라우저에 최근 ' + HISTORY_MAX + '개까지 남아요 (오래된 것부터 지워져요). 고칠 때마다 하는 자동 저장은 따로라 창을 닫아도 다음에 이어서 할 수 있어요.</p>' +
      '<div class="row hist-new"><input class="inp" id="hist-memo" maxlength="40" placeholder="메모 (선택) 예: 분양팀 1차 수정 전"><button class="btn primary small" type="button" data-hist="save">지금 저장</button></div>' +
      (all.length ? '<ul class="hist">' + all.map(function (h) {
        return '<li><div class="hist-info"><b>' + esc(h.site || '이름 없는 현장') + '</b><span>' + esc(h.label || HIST_KIND[h.kind] || '') + ' · ' + when(h.time) + ' · 이미지 ' + h.imgCount + '장</span></div>' +
          '<button class="btn small" type="button" data-hist="load" data-key="' + esc(h.key) + '">불러오기</button>' +
          '<button class="icon danger" type="button" data-hist="del" data-key="' + esc(h.key) + '" title="이 내역 지우기">✕</button></li>';
      }).join('') + '</ul>' : '<p class="desc">아직 남은 내역이 없어요.</p>') +
      '<div class="acts"><button class="btn" type="button" data-close>닫기</button></div>');
  }
  $('#hist-btn').addEventListener('click', openHistory);
  $('#modal-box').addEventListener('click', async function (e) {
    var b = e.target.closest('[data-hist]');
    if (!b) return;
    var act = b.getAttribute('data-hist'), key = b.getAttribute('data-key');
    if (act === 'save') {
      if (!hasWork()) { toast('저장할 작업이 아직 없어요'); return; }
      var memo = ($('#hist-memo') || { value: '' }).value.trim();
      await addHistory('manual', memo);
      toast('작업 내역에 저장했어요'); openHistory();
    } else if (act === 'del') {
      await queued(async function () { await delAll('snaps', [key]); await prune(); });
      openHistory();
    } else if (act === 'load') {
      var rec = (await getAll('snaps')).find(function (x) { return x.key === key; });
      if (!rec) { toast('그 내역을 찾지 못했어요'); return; }
      await addHistory('restore', '');   // 지금 상태도 남겨 둠 → 되돌린 걸 다시 되돌릴 수 있게
      busy('불러오는 중…');
      try { await loadSnap(rec); } finally { unbusy(); }
      toast('"' + (rec.site || '이름 없는 현장') + '" ' + when(rec.time) + ' 저장본을 불러왔어요');
    }
  });

  // 열 때: 지난 자동 저장본이 있으면 이어서 할지 물어봄
  function offerResume(rec) {
    pendingResume = rec;
    modal('<h3>지난 작업이 남아 있어요</h3>' +
      '<p class="desc" style="margin:0">' + esc(rec.site || '이름 없는 현장') + ' · ' + when(rec.time) + ' · 이미지 ' + rec.imgCount + '장</p>' +
      '<p class="desc" style="margin:8px 0 0">창이 꺼져도 고친 데까지 자동으로 저장돼 있어요. 새로 시작해도 이 작업은 작업 내역에 남아요.</p>' +
      '<div class="acts"><button class="btn" type="button" data-resume="new">새로 시작</button><button class="btn primary" type="button" data-resume="go">이어서 하기</button></div>');
    $('#modal-box').addEventListener('click', async function once(e) {
      var b = e.target.closest('[data-resume]');
      if (!b) return;
      $('#modal-box').removeEventListener('click', once);
      if (pendingResume !== rec) { $('#modal').hidden = true; return; }   // 그새 새로 작업을 시작함
      pendingResume = null;
      if (b.getAttribute('data-resume') === 'go') {
        autoKey = rec.key;   // 같은 자동 저장 칸에 이어서 씀
        busy('불러오는 중…');
        try { await loadSnap(rec); } finally { unbusy(); }
        lastAutoJson = rec.json;
        toast('지난 작업을 이어서 열었어요');
      } else {
        $('#modal').hidden = true;
        await queued(function () { return autoToHistory([rec]); });   // 자동 저장본은 작업 내역으로 옮겨 둠
      }
    });
  }

  // 같은 컴퓨터 다른 창(탭)에서 에디터가 열려 있는지 (localStorage 신호, 4초마다)
  var PKEY = 'bunyang-editor-presence:';
  function beat() { try { localStorage.setItem(PKEY + SID, JSON.stringify({ sid: SID, t: Date.now(), site: state.siteName.trim() })); } catch (e) {} }
  function peersNow() {
    var out = [], stale = [], now = Date.now();
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (!k || k.indexOf(PKEY) !== 0 || k === PKEY + SID) continue;
        var v = null; try { v = JSON.parse(localStorage.getItem(k)); } catch (e) { v = null; }
        if (v && now - v.t < 12000) out.push(v); else stale.push(k);
      }
      stale.forEach(function (k) { localStorage.removeItem(k); });
    } catch (e) {}
    return out;
  }
  function renderPeers() {
    var p = peersNow(), el = $('#peer-warn');
    // 다른 PC 팀원이 같은 현장을 고치는 중이면 그게 먼저
    var mine = normSite(state.siteName);
    var same = mine ? team.others.filter(function (u) { return normSite(u.site) === mine; }) : [];
    if (same.length) {
      var who = same.map(function (u) { return (u.name || '이름 없는 팀원') + '님'; }).filter(function (x, k, a) { return a.indexOf(x) === k; }).join(', ');
      var first = Math.min.apply(null, same.map(function (u) { return u.since || Date.now(); }));
      var mins = Math.floor((Date.now() - first) / 60000);
      el.hidden = false;
      el.innerHTML = '<b>' + esc(who) + '이 같은 현장을 고치고 있어요</b>' +
        '<span>\'' + esc(state.siteName.trim()) + '\' · ' + (mins < 1 ? '방금 열었어요' : mins + '분째 작업 중') + '. 같이 고치면 각자 따로 작업한 게 돼서 한쪽 작업이 묻혀요. 누가 할지 정하고 한 명만 고쳐 주세요.</span>';
      if (!same.some(function (u) { return warnedSids.has(u.sid); })) toast(who + '이 같은 현장을 고치고 있어요');
      same.forEach(function (u) { warnedSids.add(u.sid); });
      return;
    }
    el.hidden = !p.length;
    if (!p.length) return;
    var sites = p.map(function (x) { return x.site; }).filter(Boolean);
    var same = sites.indexOf(state.siteName.trim()) >= 0 && state.siteName.trim();
    el.innerHTML = '<b>' + (same ? '같은 현장을 다른 창에서도 고치고 있어요' : '다른 창에서도 에디터가 열려 있어요') + '</b>' +
      '<span>' + (sites.length ? '(' + esc(sites.join(', ')) + ') ' : '') + '같은 현장을 두 창에서 고치면 서로 덮어쓸 수 있어요. 한 창만 쓰고 나머지는 닫아 주세요.</span>';
  }
  beat();
  setInterval(function () { beat(); renderPeers(); }, 4000);
  window.addEventListener('storage', function (e) { if (e.key && e.key.indexOf(PKEY) === 0) renderPeers(); });
  // 창을 닫거나 다른 데로 갈 때: 바로 저장 + 신호 지움
  window.addEventListener('pagehide', function () {
    try { localStorage.removeItem(PKEY + SID); } catch (e) {}
    if (team.mode === 'on') presSend({ sid: SID, leave: true }, true);
    autosave();
  });

  /* 팀원 동시 접속: 에디터를 웹(사내 서버·마법도구)에 올려서 주소로 열 때만 켜짐
     - 같은 주소의 api/presence 에 10초마다 {내 이름, 고치는 현장}을 보내고 접속자 목록을 받음
     - 다른 주소를 쓰려면 <meta name="presence-url"> 이나 주소 뒤 ?presence=… 로 바꿈
     - 파일로 열었거나 서버에 API가 없으면 조용히 꺼짐 (같은 컴퓨터 다른 창 경고만 동작)
     - 인터넷이 끊겨도 편집·자동 저장은 그대로, 다시 연결되면 저절로 돌아옴 */
  var NAME_KEY = 'bunyang-editor-name';
  var myName = ''; try { myName = localStorage.getItem(NAME_KEY) || ''; } catch (e) {}
  var team = { mode: 'off', others: [], fails: 0 };   // off(확인 전) | on | lost(끊김) | none(서버 없음)
  var presUrl = (function () {
    var m = /[?&]presence=([^&]+)/.exec(location.search);
    if (m) return decodeURIComponent(m[1]);
    var meta = document.querySelector('meta[name="presence-url"]');
    return (meta && meta.content) || 'api/presence';
  })();
  var siteSince = Date.now(), sentSite = null, teamT = null, askedName = false, warnedSids = new Set();
  function normSite(s) { return String(s || '').replace(/\s+/g, '').toLowerCase(); }
  function presSend(body, beacon) {
    var data = JSON.stringify(body);
    // text/plain → 다른 주소의 서버여도 사전 요청(preflight) 없이 감
    if (beacon && navigator.sendBeacon) return navigator.sendBeacon(presUrl, new Blob([data], { type: 'text/plain' }));
    return fetch(presUrl, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=UTF-8' }, body: data, cache: 'no-store' });
  }
  var teamBusy = false, presGiven = /[?&]presence=/.test(location.search);
  async function teamBeat() {
    clearTimeout(teamT);
    if (!/^https?:$/.test(location.protocol) || team.mode === 'none' || teamBusy) return;
    // 깃허브 Pages(마법도구)는 파일만 보여 주는 곳이라 신호를 못 받음 → 주소를 따로 안 줬으면 처음부터 끔 (빨간 405 오류 안 남게)
    if (!presGiven && /\.github\.io$/i.test(location.hostname)) { team.mode = 'none'; renderTeam(); return; }
    var site = state.siteName.trim();
    if (sentSite === null || normSite(site) !== normSite(sentSite)) siteSince = Date.now();
    sentSite = site;
    teamBusy = true;
    try {
      var r = await presSend({ sid: SID, name: myName, site: site, since: siteSince });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var d = await r.json();
      if (!d || !Array.isArray(d.users)) throw new Error('bad response');
      var local = peersNow().map(function (x) { return x.sid; });   // 내 다른 창은 팀원이 아님
      team.mode = 'on'; team.fails = 0;
      team.others = d.users.filter(function (u) { return u && u.sid !== SID && local.indexOf(u.sid) < 0; });
    } catch (err) {
      team.fails++;
      if (team.mode === 'off' || team.mode === 'none') {
        // 처음부터 안 되면 서버 없는 걸로 보고 끔 (405·404는 API가 없다는 뜻이라 바로)
        if (team.fails >= 3 || /HTTP 40[45]/.test(err && err.message)) { team.mode = 'none'; teamBusy = false; renderTeam(); return; }
      } else { team.mode = 'lost'; team.others = []; }
    }
    teamBusy = false;
    renderTeam(); renderPeers();
    teamT = setTimeout(teamBeat, 10000);
  }
  // 현장명이 바뀌면 바로 알림 (1초 모아서)
  var teamSoonT = null;
  function teamSiteCheck() {
    if (team.mode !== 'on' || sentSite === null || normSite(state.siteName) === normSite(sentSite)) return;
    clearTimeout(teamSoonT); teamSoonT = setTimeout(teamBeat, 1000);
  }
  function renderTeam() {
    var el = $('#team-pill');
    if (team.mode === 'none' || team.mode === 'off') { el.hidden = true; return; }
    el.hidden = false;
    el.classList.toggle('lost', team.mode === 'lost');
    if (team.mode === 'lost') {
      el.innerHTML = '<i></i>팀 연결 끊김';
      el.title = '서버에 연결이 안 돼요. 편집과 자동 저장은 그대로 돼요. 다시 연결되면 저절로 돌아와요.';
      return;
    }
    el.innerHTML = '<i></i>' + (team.others.length + 1) + '명 접속' + (myName ? '' : ' · 이름 정하기');
    el.title = team.others.length ? team.others.map(function (u) { return (u.name || '이름 없음') + ' — ' + (u.site || '현장명 없음'); }).join('\n') : '지금은 나 혼자예요';
    if (!myName && !askedName && storeInitDone && $('#modal').hidden) { askedName = true; openTeam(); }
  }
  function openTeam() {
    var since = function (t) { var m = Math.floor((Date.now() - (t || Date.now())) / 60000); return m < 1 ? '방금' : m + '분째'; };
    var row = function (name, site, t, me) {
      return '<li><div class="hist-info"><b>' + esc(name || '이름 없음') + (me ? ' (나)' : '') + '</b><span>' + esc(site || '현장명 아직 없음') + ' · ' + since(t) + '</span></div></li>';
    };
    modal('<h3>접속 중인 팀원</h3>' +
      (team.mode === 'on' ? '<ul class="hist">' + row(myName, state.siteName.trim(), siteSince, true) +
        team.others.map(function (u) { return row(u.name, u.site, u.since); }).join('') + '</ul>' : '<p class="desc">지금은 서버에 연결이 안 돼요.</p>') +
      '<div class="field" style="margin-top:14px"><label for="my-name">내 이름</label>' +
      '<div class="row hist-new" style="margin:0"><input class="inp" id="my-name" maxlength="20" value="' + esc(myName) + '" placeholder="예: 김종민"><button class="btn primary small" type="button" data-team="save">저장</button></div>' +
      '<div class="note">같은 현장을 열면 팀원 화면에 \'OO님이 같은 현장을 고치고 있어요\'로 떠요. 이 컴퓨터에 기억돼요.</div></div>' +
      '<div class="acts"><button class="btn" type="button" data-close>닫기</button></div>');
    var inp = $('#my-name');
    if (inp && !myName) inp.focus();
  }
  function saveName() {
    var inp = $('#my-name'); if (!inp) return;
    myName = inp.value.trim().slice(0, 20);
    try { localStorage.setItem(NAME_KEY, myName); } catch (e) {}
    $('#modal').hidden = true;
    toast(myName ? myName + '(으)로 보여요' : '이름을 비웠어요');
    teamBeat();
  }
  $('#team-pill').addEventListener('click', openTeam);
  $('#modal-box').addEventListener('click', function (e) { if (e.target.closest('[data-team="save"]')) saveName(); });
  $('#modal-box').addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.id === 'my-name') saveName(); });
  teamBeat();
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') autosave(); else beat(); });

  var initTries = 0;
  (async function initStore() {
    var peers = peersNow();
    renderPeers();
    initTries++;
    try {
      savedBlobs = new Set(await getAllKeys('blobs'));
      await queued(prune);
      storeReady = true;
      setSaveState('자동 저장 켜짐');
      // 다른 창이 열려 있으면 그 창이 쓰는 저장본일 수 있어서 건드리지 않음
      if (!peers.length) {
        var autos = (await getAll('snaps')).filter(function (x) { return x.kind === 'auto' && (x.imgCount || x.site); })
          .sort(function (a, b) { return b.time - a.time; });
        await queued(function () { return autoToHistory(autos.slice(1)); });   // 더 예전 자동 저장본은 작업 내역으로
        if (autos[0] && !hasWork() && $('#modal').hidden) offerResume(autos[0]);
      }
    } catch (err) {
      console.error(err);
      setSaveState('자동 저장 안 됨', true);
      if (initTries < 4) setTimeout(initStore, 15000);   // 막혔던 거면 조금 뒤 다시
    }
    storeInitDone = true;
    renderTeam();
  })();

  /* =========================================================
     대지 (피그마처럼 편집)
     - 지금 페이지를 모바일(375)·PC(1440) 대지로 펼쳐 놓고 확대·이동, 고르기, 끌어서 옮기기·크기 바꾸기, 스냅, 거리 재기(Alt), 눈금자
     - 대지마다 iframe 하나 = 내보내는 HTML 그대로 (키 = 페이지 전체 높이). 마우스는 위에 덮은 투명 칸(#ab-hit)이 받고,
       iframe 안 요소는 elementFromPoint로 찾음
     - 고를 수 있는 것: 섹션(칸), 자유 레이어(.fl: 글·사각형·이미지), 히어로 제목·위 문구·배지·더 얹은 것(세로 위치·크기)
     - 좌표: 화면(sx,sy) = 세계(wx,wy) × z + 이동(x,y). 대지 안 좌표 = 세계 - 대지 위치 (대지 1px = 세계 1px)
     - 자유 레이어 값은 칸 가로 폭 비율이라 모바일·PC 대지에서 같이 움직임
     ========================================================= */
  var ab = { on: false, z: 0.5, x: 60, y: 72, boards: [], sel: [], selB: null, hover: null, tool: 'move', alt: false, space: false, drag: null, show: 'both', fitted: false, guides: [], clip: null };
  var abApi = {};
  function abOn() { return !!(ab && ab.on); }
  var AB_GAP = 200, AB_SNAP = 6, AB_RULER = 20;
  var abStage = $('#ab-stage'), abWorld = $('#ab-world'), abHit = $('#ab-hit'), abUi = $('#ab-ui'), abRx = $('#ab-rx'), abRy = $('#ab-ry');
  abHit.tabIndex = -1;
  // 대지 안: 애니메이션·인트로 끄고, 고정 요소는 페이지 안 자리로
  var AB_CSS = 'html,body{overflow:hidden!important;scroll-behavior:auto!important}' +
    '.reveal,.a-fade,.a-up,.reveal img,.fl.reveal{opacity:1!important;transform:none!important;animation:none!important;transition:none!important}' +
    '.hero-bg img{transform:none!important;transition:none!important}.intro{display:none!important}' +
    '.pc-side{position:absolute!important;top:450px!important}.bar,.bar *{transition:none!important}';
  var flUid = function () { return 'L' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); };
  var KIND_NAME = { text: '텍스트', rect: '사각형', img: '이미지' };

  /* ---------- 자유 레이어 데이터 ---------- */
  function secAny(id) { return state.sections.find(function (s) { return s.id === id; }) || MAIN().find(function (s) { return s.id === id; }) || null; }
  function flList(host, make) {
    if (host === 'hero') { if (!state.heroFl) state.heroFl = []; return state.heroFl; }
    var s = secAny(host); if (!s) return null;
    if (!s.fl && make) s.fl = [];
    return s.fl || null;
  }
  function flGet(host, id) { var l = flList(host); return l ? l.find(function (L) { return L.id === id; }) || null : null; }
  function flHostOk(host) {
    if (host === 'hero') return !!state.heroBg;
    var s = secAny(host);
    return !!(s && s.kind === 'images' && s.mode !== 'slide' && (s.images.length || s.header));
  }
  function flName(L) {
    if (L.name) return L.name;
    if (L.t === 'text') return String(L.text || '').replace(/\s+/g, ' ').trim().slice(0, 16) || '텍스트';
    if (L.t === 'img') return (L.img && L.img.name) || '이미지';
    return KIND_NAME[L.t] || '레이어';
  }
  function flHostLabel(host) { if (host === 'hero') return '히어로'; var s = secAny(host); return s ? s.label || '섹션' : '섹션'; }
  function flBasis() { if (pv.page === 'main' || pv.page === 'contact') return 375; var p = pageBySlug(pv.page); return p ? p.page.cw || 1200 : 375; }

  /* ---------- 대지 그리기 ---------- */
  function abDefs() {
    var pg = pv.page === 'main' ? '메인' : pv.page === 'contact' ? '방문예약' : (pageBySlug(pv.page) ? pageBySlug(pv.page).page.name : pv.page);
    var out = [];
    if (ab.show !== 'pc') out.push({ key: 'm', w: 375, label: pg + ' · 모바일 375' });
    if (ab.show !== 'm') out.push({ key: 'pc', w: 1440, label: pg + ' · PC 1440' });
    var x = 0;
    out.forEach(function (d) { d.x = x; d.y = 0; x += d.w + AB_GAP; });
    return out;
  }
  function boardHtml() {
    return renderPage(pv.page, {
      preview: true, board: true, intro: false,
      src: function (im) { return im.url; },
      dims: function (im) { return { w: im.w, h: im.h }; },
      css: pretendardPv + '\n' + swapFonts(siteCss()) + '\n' + PV_FORM_CSS + '\n' + AB_CSS
    }).replace(/ loading="lazy"/g, '');
  }
  function renderBoards() {
    var ok = hasContent();
    $('#ab-empty').hidden = ok;
    if (!ok) { $('#ab-empty').innerHTML = pvEmptyHtml(); ab.boards.forEach(function (b) { b.el.remove(); }); ab.boards = []; abDraw(); return; }
    if (pv.page !== 'main' && pv.page !== 'contact' && !(isMenuMode() && pageBySlug(pv.page))) { pv.page = 'main'; renderPvPages(); }
    if (ab.page !== pv.page) { ab.page = pv.page; ab.fitted = false; ab.sel = []; ab.hover = null; }   // 다른 페이지면 처음처럼 맞춤
    var defs = abDefs(), html = boardHtml();
    var keep = ab.boards;
    ab.boards = defs.map(function (d) {
      var b = keep.find(function (x) { return x.key === d.key; });
      if (!b) {
        b = { key: d.key, h: 1200, el: document.createElement('div'), ifr: null, doc: null };
        b.el.className = 'ab-board';
        abWorld.appendChild(b.el);
      }
      b.w = d.w; b.x = d.x; b.y = d.y; b.label = d.label;
      return b;
    });
    keep.forEach(function (b) { if (ab.boards.indexOf(b) < 0) b.el.remove(); });
    ab.boards.forEach(function (b) {
      b.el.style.left = b.x + 'px'; b.el.style.top = b.y + 'px'; b.el.style.width = b.w + 'px'; b.el.style.height = b.h + 'px';
      // 새 iframe을 뒤에서 다 그린 다음 바꿔 끼움 (깜빡임 없게)
      var nf = document.createElement('iframe');
      nf.setAttribute('tabindex', '-1'); nf.setAttribute('aria-hidden', 'true');
      nf.className = 'is-next'; nf.style.width = b.w + 'px'; nf.style.height = '400px';
      if (b.next) b.next.remove();
      b.next = nf;
      nf.onload = function () {
        var d = nf.contentDocument;
        if (b.next !== nf || !d || d.URL === 'about:blank') return;   // 처음 빈 문서 load는 건너뜀
        if (b.ifr) b.ifr.remove();
        b.ifr = nf; b.next = null; b.doc = d; nf.className = '';
        abMeasure(b);
        setTimeout(function () { abMeasure(b); }, 300);
        setTimeout(function () { abMeasure(b); }, 1200);
        if (!ab.fitted && ab.boards.every(function (x) { return x.doc; })) { ab.fitted = true; abFitWidth(); }
      };
      nf.srcdoc = html;
      b.el.appendChild(nf);
    });
    abApply();
  }
  function abMeasure(b) {
    if (!b.doc || !b.doc.documentElement) return;
    var h = Math.max(200, Math.ceil(b.doc.documentElement.scrollHeight));
    if (b.ifr && Math.abs(h - b.h) > 1) { b.h = h; }
    if (b.ifr) b.ifr.style.height = b.h + 'px';
    b.el.style.height = b.h + 'px';
    abDraw();
  }
  function abApply() {
    abWorld.style.transform = 'translate(' + ab.x + 'px,' + ab.y + 'px) scale(' + ab.z + ')';
    $('#zoom-val').textContent = Math.round(ab.z * 100) + '%';
    $('#zoom-fit').classList.remove('is-on');
    abDraw();
  }
  function abStageRect() { return abStage.getBoundingClientRect(); }
  function abZoomAt(z, sx, sy) {
    var r = abStageRect();
    if (sx == null) { sx = r.width / 2; sy = r.height / 2; }
    var wx = (sx - ab.x) / ab.z, wy = (sy - ab.y) / ab.z;
    ab.z = clamp(z, 0.02, 64);
    ab.x = sx - wx * ab.z; ab.y = sy - wy * ab.z;
    abApply();
  }
  var AB_ZOOMS = [0.03, 0.05, 0.1, 0.125, 0.25, 0.33, 0.5, 0.75, 1, 1.5, 2, 3, 4, 8, 16, 32, 64];
  function abZoomStep(dir) {
    var z = ab.z, nx = dir > 0 ? AB_ZOOMS.find(function (v) { return v > z + 0.001; }) : AB_ZOOMS.slice().reverse().find(function (v) { return v < z - 0.001; });
    abZoomAt(nx == null ? z : nx);
  }
  function abBounds() {
    if (!ab.boards.length) return { x: 0, y: 0, w: 375, h: 800 };
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    ab.boards.forEach(function (b) { x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y); x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h); });
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }
  function abFitRect(R, maxZ) {
    var r = abStageRect(), pad = 64;
    ab.z = clamp(Math.min((r.width - pad * 2) / R.w, (r.height - pad * 2) / R.h, maxZ || 1), 0.02, 64);
    ab.x = (r.width - R.w * ab.z) / 2 - R.x * ab.z; ab.y = (r.height - R.h * ab.z) / 2 - R.y * ab.z;
    abApply();
  }
  function abFitWidth() {   // 처음: 대지 가로가 화면에 맞게, 위쪽부터
    var r = abStageRect(), B = abBounds();
    ab.z = clamp(Math.min((r.width - 120) / B.w, 1), 0.02, 1);
    ab.x = (r.width - B.w * ab.z) / 2 - B.x * ab.z; ab.y = 64 - B.y * ab.z;
    abApply();
  }
  function abFitAll() { abFitRect(abBounds(), 1); }
  function abFitSel() { var u = abSelUnion(); if (u) abFitRect({ x: u.b.x + u.x - 40, y: u.b.y + u.y - 40, w: u.w + 80, h: u.h + 80 }, 8); else abFitAll(); }
  function abReveal(b, r) {   // 고른 것이 화면 밖이면 보이게 옮김
    var R = abStageRect(), s = abToScreen(b, r);
    if (s.x > 40 && s.y > 40 && s.x + s.w < R.width - 40 && s.y + s.h < R.height - 40) return;
    ab.x += R.width / 2 - (s.x + s.w / 2); ab.y += R.height / 2 - (s.y + s.h / 2);
    abApply();
  }

  /* ---------- 좌표·찾기 ---------- */
  function abToScreen(b, r) { return { x: ab.x + (b.x + r.x) * ab.z, y: ab.y + (b.y + r.y) * ab.z, w: r.w * ab.z, h: r.h * ab.z }; }
  function abWorldAt(sx, sy) { return { x: (sx - ab.x) / ab.z, y: (sy - ab.y) / ab.z }; }
  function abBoardAt(wx, wy) { return ab.boards.find(function (b) { return b.doc && wx >= b.x && wx < b.x + b.w && wy >= b.y && wy < b.y + b.h; }) || null; }
  function abBoardByKey(k) { return ab.boards.find(function (b) { return b.key === k; }) || null; }
  function elRect(el) { var r = el.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }
  function hostEl(b, host) { return !b.doc ? null : host === 'hero' ? b.doc.querySelector('.hero') : b.doc.getElementById(host); }
  function abEl(b, t) {
    if (!b || !b.doc || !t) return null;
    var d = b.doc;
    if (t.k === 'fl') { var h = hostEl(b, t.host); return h ? h.querySelector(':scope > [data-flid="' + t.id + '"]') : null; }
    if (t.k === 'hero') {
      if (t.part === 'layer') return $$('.hero > .hero-layer', d)[t.idx] || null;
      return d.querySelector('.hero .hero-' + (t.part === 'badge' ? 'badges' : t.part));
    }
    if (t.k === 'sec') return d.getElementById(t.id);
    return null;
  }
  // 그 자리 요소 → 고를 것
  function abPick(b, lx, ly) {
    if (!b || !b.doc) return null;
    var el = b.doc.elementFromPoint(lx, ly);
    if (!el) return { k: 'board', b: b };
    var f = el.closest('[data-flid]');
    if (f) { var p = f.parentElement; return { k: 'fl', b: b, host: p.classList.contains('hero') ? 'hero' : p.id, id: f.getAttribute('data-flid') }; }
    var hp = el.closest('.hero-title, .hero-sub, .hero-badges, .hero-layer');
    if (hp && hp.closest('.hero')) {
      if (hp.classList.contains('hero-layer')) return { k: 'hero', b: b, part: 'layer', idx: $$('.hero > .hero-layer', b.doc).indexOf(hp) };
      return { k: 'hero', b: b, part: hp.classList.contains('hero-badges') ? 'badge' : hp.classList.contains('hero-title') ? 'title' : 'sub' };
    }
    if (el.closest('.hero')) return { k: 'sec', b: b, id: 'hero', hero: true };
    var s = el.closest('.app > section[id], .app > figure[id], #s-top > section[id]');
    if (s) return { k: 'sec', b: b, id: s.id };
    return { k: 'board', b: b };
  }
  function sameT(a, c) { return a && c && a.k === c.k && a.host === c.host && a.id === c.id && a.part === c.part && a.idx === c.idx; }
  function tEl(t, b) {
    if (t.k === 'sec' && t.id === 'hero') return b && b.doc ? b.doc.querySelector('.hero') : null;
    return abEl(b, t);
  }
  function abSelUnion(bk) {
    var b = abBoardByKey(bk || ab.selB) || ab.boards[0];
    if (!b || !ab.sel.length) return null;
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, n = 0;
    ab.sel.forEach(function (t) { var el = tEl(t, b); if (!el) return; var r = elRect(el); n++; x0 = Math.min(x0, r.x); y0 = Math.min(y0, r.y); x1 = Math.max(x1, r.x + r.w); y1 = Math.max(y1, r.y + r.h); });
    return n ? { b: b, x: x0, y: y0, w: x1 - x0, h: y1 - y0 } : null;
  }

  /* ---------- 고르기 ---------- */
  function abSelect(list, bk, opts) {
    ab.sel = list || [];
    if (bk) ab.selB = bk;
    opts = opts || {};
    var t = ab.sel[0];
    if (!t) { abDraw(); renderTree(); if (view === 'layer') setView(curSecIn() ? 'sections' : 'upload'); return; }
    if (t.k === 'fl') { setView('layer'); abInspector(); }
    else if (t.k === 'hero') setView('hero');
    else if (t.k === 'sec') {
      if (t.id === 'hero') setView('hero');
      else if (pv.page === 'contact' && /^reserve/.test(t.id)) setView('contact');   // 방문예약 페이지 맨 위·맨 아래 폼
      else if (pv.page !== 'main' && pv.page !== 'contact' && /^reserve/.test(t.id)) setView('menus');
      else { var s = state.sections.find(function (x) { return idOf(x) === t.id; }); if (s) selectSec(s, false); }
    }
    renderTree(); abDraw();
    if (opts.reveal) { var u = abSelUnion(); if (u) abReveal(u.b, u); }
  }
  function abSelectFl(host, id, reveal) {
    if (!abOn()) { ab.sel = [{ k: 'fl', host: host, id: id }]; setView('layer'); abInspector(); renderTree(); return; }
    abSelect([{ k: 'fl', host: host, id: id }], ab.selB || (ab.boards[0] && ab.boards[0].key), { reveal: reveal });
  }
  function selFl() { return ab.sel.filter(function (t) { return t.k === 'fl'; }).map(function (t) { return { t: t, L: flGet(t.host, t.id) }; }).filter(function (x) { return x.L; }); }

  /* ---------- 화면 위 표시 (선택 상자·손잡이·가이드·거리·눈금자) ---------- */
  var abRaf = 0;
  function abDraw() { if (!abRaf) abRaf = requestAnimationFrame(abDrawNow); }
  function box(s, cls, extra) { return '<div class="' + cls + '" style="left:' + s.x.toFixed(1) + 'px;top:' + s.y.toFixed(1) + 'px;width:' + Math.max(0, s.w).toFixed(1) + 'px;height:' + Math.max(0, s.h).toFixed(1) + 'px' + (extra || '') + '"></div>'; }
  function line(x1, y1, x2, y2, cls) {
    return x1 === x2 ? '<div class="' + cls + ' v" style="left:' + x1.toFixed(1) + 'px;top:' + Math.min(y1, y2).toFixed(1) + 'px;height:' + Math.abs(y2 - y1).toFixed(1) + 'px"></div>'
      : '<div class="' + cls + ' h" style="left:' + Math.min(x1, x2).toFixed(1) + 'px;top:' + y1.toFixed(1) + 'px;width:' + Math.abs(x2 - x1).toFixed(1) + 'px"></div>';
  }
  function tag(x, y, txt, cls) { return '<span class="' + (cls || 'ab-tag') + '" style="left:' + x.toFixed(1) + 'px;top:' + y.toFixed(1) + 'px">' + txt + '</span>'; }
  function abDrawNow() {
    abRaf = 0;
    if (!abOn()) { abUi.innerHTML = ''; return; }
    var out = [], R = abStageRect();
    ab.boards.forEach(function (b) {
      var s = abToScreen(b, { x: 0, y: 0, w: b.w, h: b.h });
      out.push(tag(s.x, s.y - 20, esc(b.label), 'ab-label' + (b.key === ab.selB && ab.sel.length ? ' is-on' : '')));
      if (ab.z >= 8) {   // 픽셀 격자
        var g = Math.round(ab.z * 1000) / 1000;
        out.push(box(s, 'ab-pxgrid', ';background-size:' + g + 'px ' + g + 'px;background-position:0 0'));
      }
    });
    var dg = ab.drag;
    out = out.concat(abSecTags());
    // 마우스 올린 것
    if (ab.hover && !dg && !ab.space) {
      var hb = ab.hover.b, he = tEl(ab.hover, hb);
      if (he && !ab.sel.some(function (t) { return sameT(t, ab.hover); })) out.push(box(abToScreen(hb, elRect(he)), 'ab-hover' + (ab.hover.k === 'sec' ? ' is-sec' : '')));
    }
    // 고른 것 (다른 대지엔 옅게)
    var u = abSelUnion();
    if (u) {
      ab.boards.forEach(function (b) {
        if (b === u.b) return;
        ab.sel.forEach(function (t) { var e2 = tEl(t, b); if (e2) out.push(box(abToScreen(b, elRect(e2)), 'ab-ghost')); });
      });
      if (ab.sel.length > 1) ab.sel.forEach(function (t) { var e3 = tEl(t, u.b); if (e3) out.push(box(abToScreen(u.b, elRect(e3)), 'ab-sel-item')); });
      var su = abToScreen(u.b, u), one = ab.sel.length === 1 ? ab.sel[0] : null;
      out.push(box(su, 'ab-sel' + (one && one.k === 'sec' ? ' is-sec' : '')));
      var hs = abHandles(one);
      hs.forEach(function (h) {
        var hx = su.x + (h.indexOf('w') >= 0 ? 0 : h.indexOf('e') >= 0 ? su.w : su.w / 2), hy = su.y + (h.indexOf('n') >= 0 ? 0 : h.indexOf('s') >= 0 ? su.h : su.h / 2);
        out.push('<i class="ab-h" data-h="' + h + '" style="left:' + (hx - 4).toFixed(1) + 'px;top:' + (hy - 4).toFixed(1) + 'px"></i>');
      });
      if (!(one && one.k === 'sec')) out.push(tag(su.x + su.w / 2, su.y + su.h + 8, Math.round(u.w) + ' × ' + Math.round(u.h), 'ab-size'));
    }
    // 스냅 가이드
    (ab.guides || []).forEach(function (g) {
      var b = abBoardByKey(g.bk); if (!b) return;
      var a = abToScreen(b, { x: g.x1, y: g.y1, w: 0, h: 0 }), c = abToScreen(b, { x: g.x2, y: g.y2, w: 0, h: 0 });
      out.push(line(a.x, a.y, c.x, c.y, 'ab-guide'));
    });
    // 거리 재기 (Alt)
    if (ab.alt && u && !dg) out = out.concat(abMeasureLines(u));
    // 끌어서 고르기 상자
    if (dg && dg.mode === 'marquee' && dg.moved) out.push(box(abToScreen(dg.b, dg.rect), 'ab-marquee'));
    if (dg && dg.mode === 'draw' && dg.moved) out.push(box(abToScreen(dg.b, dg.rect), 'ab-sel'));
    abUi.innerHTML = out.join('');
    abRulers(u, R);
  }
  function abSecTags() {
    var b = ab.boards[0]; if (!b || !b.doc || ab.z < 0.12) return [];
    var nums = numMap(state.sections), sel = ab.sel[0], out = [];
    $$('.app > section[id], .app > figure[id]', b.doc).forEach(function (el) {
      var id = el.id, isHero = el.classList.contains('hero'), s = isHero ? null : state.sections.find(function (x) { return idOf(x) === id; });
      if (!isHero && !s) return;
      var no = isHero ? '00' : nums.get(s), name = isHero ? '히어로' : (s.label || (s.kind === 'form' ? '방문예약 폼' : '섹션'));
      var r = elRect(el), p = abToScreen(b, { x: 0, y: r.y, w: 0, h: 0 });
      var on = sel && sel.k === 'sec' && (sel.id === id || (isHero && sel.id === 'hero'));
      out.push('<span class="ab-sec' + (on ? ' is-on' : '') + '" data-sec-id="' + esc(isHero ? 'hero' : id) + '" style="left:' + (p.x - 8).toFixed(1) + 'px;top:' + p.y.toFixed(1) + 'px">' +
        (no && no !== '–' ? '<b>' + esc(no) + '</b>' : '') + esc(name) + '</span>');
    });
    return out;
  }
  function abHandles(one) {
    if (!one || one.k === 'sec') return [];
    if (one.k === 'hero') return one.part === 'badge' || one.part === 'layer' ? ['nw', 'ne', 'sw', 'se', 'e', 'w'] : [];
    var L = flGet(one.host, one.id); if (!L) return [];
    if (L.t === 'rect') return ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];
    return ['nw', 'ne', 'sw', 'se', 'e', 'w'];
  }
  // Alt: 고른 것 ↔ 마우스 올린 것(없으면 고른 것이 든 칸) 사이 거리
  function abMeasureLines(u) {
    var b = u.b, out = [], target = null;
    if (ab.hover && ab.hover.b === b && !ab.sel.some(function (t) { return sameT(t, ab.hover); })) { var he = tEl(ab.hover, b); if (he) target = elRect(he); }
    if (!target) {
      var t0 = ab.sel[0], hel = t0.k === 'fl' ? hostEl(b, t0.host) : t0.k === 'hero' ? b.doc.querySelector('.hero') : null;
      if (!hel) return out;
      target = elRect(hel);
    }
    var A = u, T = target, lab = function (x, y, v) { out.push(tag(x, y, String(Math.round(v)), 'ab-dist')); };
    var S = function (r) { return abToScreen(b, r); };
    var inside = T.x <= A.x + 0.5 && T.y <= A.y + 0.5 && T.x + T.w >= A.x + A.w - 0.5 && T.y + T.h >= A.y + A.h - 0.5;
    var cy = A.y + A.h / 2, cx = A.x + A.w / 2;
    if (inside) {
      [[T.x, cy, A.x, cy], [A.x + A.w, cy, T.x + T.w, cy], [cx, T.y, cx, A.y], [cx, A.y + A.h, cx, T.y + T.h]].forEach(function (q) {
        var d = Math.abs(q[2] - q[0]) + Math.abs(q[3] - q[1]); if (d < 0.5) return;
        var a = S({ x: q[0], y: q[1], w: 0, h: 0 }), c = S({ x: q[2], y: q[3], w: 0, h: 0 });
        out.push(line(a.x, a.y, c.x, c.y, 'ab-mline')); lab((a.x + c.x) / 2, (a.y + c.y) / 2, d);
      });
      out.push(box(S(T), 'ab-mbox'));
      return out;
    }
    out.push(box(S(T), 'ab-mbox'));
    var my = Math.max(A.y, T.y) < Math.min(A.y + A.h, T.y + T.h) ? (Math.max(A.y, T.y) + Math.min(A.y + A.h, T.y + T.h)) / 2 : cy;
    var mx = Math.max(A.x, T.x) < Math.min(A.x + A.w, T.x + T.w) ? (Math.max(A.x, T.x) + Math.min(A.x + A.w, T.x + T.w)) / 2 : cx;
    var gx = A.x >= T.x + T.w ? [T.x + T.w, A.x] : T.x >= A.x + A.w ? [A.x + A.w, T.x] : null;
    var gy = A.y >= T.y + T.h ? [T.y + T.h, A.y] : T.y >= A.y + A.h ? [A.y + A.h, T.y] : null;
    if (gx) { var a1 = S({ x: gx[0], y: my, w: 0, h: 0 }), c1 = S({ x: gx[1], y: my, w: 0, h: 0 }); out.push(line(a1.x, a1.y, c1.x, c1.y, 'ab-mline')); lab((a1.x + c1.x) / 2, a1.y, gx[1] - gx[0]); }
    if (gy) { var a2 = S({ x: mx, y: gy[0], w: 0, h: 0 }), c2 = S({ x: mx, y: gy[1], w: 0, h: 0 }); out.push(line(a2.x, a2.y, c2.x, c2.y, 'ab-mline')); lab(a2.x, (a2.y + c2.y) / 2, gy[1] - gy[0]); }
    return out;
  }
  // 눈금자: 고른 것(없으면 마우스 올린) 대지 기준 px, 고른 범위는 파랗게
  function abRulers(u, R) {
    var b = u ? u.b : (ab.hover && ab.hover.b) || abBoardByKey(ab.selB) || ab.boards[0];
    [[abRx, R.width, AB_RULER, 'x'], [abRy, AB_RULER, R.height, 'y']].forEach(function (q) {
      var cv = q[0], W = q[1], H = q[2], ax = q[3], dpr = window.devicePixelRatio || 1;
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); cv.style.width = W + 'px'; cv.style.height = H + 'px'; }
      var c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
      var dark = document.documentElement.getAttribute('data-theme') === 'dark';
      c.fillStyle = dark ? '#1f2128' : '#ffffff'; c.fillRect(0, 0, W, H);
      if (!b) return;
      var o = ax === 'x' ? ab.x + b.x * ab.z : ab.y + b.y * ab.z;   // 대지 0이 화면 어디인지
      if (u) {
        var s0 = o + (ax === 'x' ? u.x : u.y) * ab.z, s1 = s0 + (ax === 'x' ? u.w : u.h) * ab.z;
        c.fillStyle = 'rgba(13,153,255,.16)';
        if (ax === 'x') c.fillRect(s0, 0, s1 - s0, H); else c.fillRect(0, s0, W, s1 - s0);
      }
      var steps = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000], step = steps.find(function (v) { return v * ab.z >= 56; }) || 10000;
      var len = ax === 'x' ? W : H, v0 = Math.floor(-o / ab.z / step) * step;
      c.strokeStyle = dark ? '#555a66' : '#c9ccd3'; c.fillStyle = dark ? '#9aa0ac' : '#8a8f99'; c.font = '9.5px Pretendard Variable, sans-serif'; c.lineWidth = 1;
      c.beginPath();
      for (var v = v0; o + v * ab.z < len; v += step / 5) {
        var p = Math.round(o + v * ab.z) + 0.5, major = Math.abs(v / step - Math.round(v / step)) < 1e-6;
        if (ax === 'x') { c.moveTo(p, major ? 6 : 14); c.lineTo(p, H); } else { c.moveTo(major ? 6 : 14, p); c.lineTo(W, p); }
        if (major) {
          if (ax === 'x') c.fillText(String(Math.round(v)), p + 3, 9);
          else { c.save(); c.translate(9, p - 3); c.rotate(-Math.PI / 2); c.fillText(String(Math.round(v)), 0, 0); c.restore(); }
        }
      }
      c.stroke();
      if (u) {
        c.fillStyle = '#0d99ff'; c.font = '600 9.5px Pretendard Variable, sans-serif';
        var a0 = ax === 'x' ? u.x : u.y, a1 = a0 + (ax === 'x' ? u.w : u.h);
        [a0, a1].forEach(function (val, k) {
          var p2 = o + val * ab.z, txt = String(Math.round(val));
          if (ax === 'x') c.fillText(txt, k ? p2 + 3 : p2 - c.measureText(txt).width - 3, 9);
          else { c.save(); c.translate(9, k ? p2 + c.measureText(txt).width + 3 : p2 - 3); c.rotate(-Math.PI / 2); c.fillText(txt, 0, 0); c.restore(); }
        });
      }
    });
  }

  /* ---------- 스냅 ---------- */
  // 칸(host) 가장자리·가운데, 같은 칸의 다른 레이어, 칸 안 이미지 경계
  function abSnapLines(b, host, skip) {
    var xs = [], ys = [], he = hostEl(b, host); if (!he) return { xs: xs, ys: ys };
    var H = elRect(he);
    var addR = function (r) {
      [r.x, r.x + r.w / 2, r.x + r.w].forEach(function (v) { xs.push({ v: v, a: r.y, b: r.y + r.h }); });
      [r.y, r.y + r.h / 2, r.y + r.h].forEach(function (v) { ys.push({ v: v, a: r.x, b: r.x + r.w }); });
    };
    addR(H);
    var mg = H.w * 20 / flBasis();   // 좌우 여백 20px에도 붙음
    xs.push({ v: H.x + mg, a: H.y, b: H.y + H.h }); xs.push({ v: H.x + H.w - mg, a: H.y, b: H.y + H.h });
    $$(':scope > [data-flid], :scope > .hero-title, :scope > .hero-sub, :scope > .hero-badges, :scope > .hero-layer', he).forEach(function (el) {
      if (skip.indexOf(el) >= 0) return;
      addR(elRect(el));
    });
    $$(':scope > figure', he).forEach(function (f) { var r = elRect(f); ys.push({ v: r.y, a: r.x, b: r.x + r.w }); ys.push({ v: r.y + r.h, a: r.x, b: r.x + r.w }); });
    return { xs: xs, ys: ys, H: H };
  }
  function abSnap(rect, lines, axes, edges) {   // edges: {x:[...], y:[...]} 어느 변을 맞출지 (끌기 = 다, 크기 = 움직이는 변)
    var th = AB_SNAP / ab.z, dx = 0, dy = 0, gx = null, gy = null;
    if (axes.x) {
      var best = th + 1;
      (edges.x || [rect.x, rect.x + rect.w / 2, rect.x + rect.w]).forEach(function (e) {
        lines.xs.forEach(function (c) { var d = c.v - e; if (Math.abs(d) < Math.abs(best)) { best = d; gx = c; } });
      });
      if (Math.abs(best) <= th) dx = best; else gx = null;
    }
    if (axes.y) {
      var bestY = th + 1;
      (edges.y || [rect.y, rect.y + rect.h / 2, rect.y + rect.h]).forEach(function (e) {
        lines.ys.forEach(function (c) { var d = c.v - e; if (Math.abs(d) < Math.abs(bestY)) { bestY = d; gy = c; } });
      });
      if (Math.abs(bestY) <= th) dy = bestY; else gy = null;
    }
    return { dx: dx, dy: dy, gx: gx, gy: gy };
  }
  function abGuideFrom(sn, r, bk) {
    var g = [];
    if (sn.gx) g.push({ bk: bk, x1: sn.gx.v, y1: Math.min(sn.gx.a, r.y), x2: sn.gx.v, y2: Math.max(sn.gx.b, r.y + r.h) });
    if (sn.gy) g.push({ bk: bk, x1: Math.min(sn.gy.a, r.x), y1: sn.gy.v, x2: Math.max(sn.gy.b, r.x + r.w), y2: sn.gy.v });
    return g;
  }

  /* ---------- 자유 레이어 바로 반영 (대지 다시 안 그림) ---------- */
  function flLive(host, L) {   // 끄는 동안: 모든 대지의 그 요소 위치만
    ab.boards.forEach(function (b) {
      var he = hostEl(b, host), el = he && he.querySelector(':scope > [data-flid="' + L.id + '"]');
      if (!el) return;
      var H = elRect(he), k = H.w / (H.h || 1);
      el.style.left = (L.x * 100) + '%'; el.style.top = (L.y * k * 100) + '%'; el.style.width = (L.w * 100) + '%';
      if (L.t === 'rect') el.style.height = (L.h * k * 100) + '%';
    });
  }
  function flPatch(host) {   // 그 칸의 자유 레이어 HTML을 새로 (속성 바꿀 때)
    var list = flList(host) || [], s = host === 'hero' ? 'hero' : secAny(host);
    var o = { preview: true, src: function (im) { return im.url; }, dims: function (im) { return { w: im.w, h: im.h }; } };
    var ctx = flCtx; flCtx = { tel: telOf(state.phone), res: pv.page === 'contact' ? '#reserve' : 'contact/', go: pv.page === 'contact', basis: flBasis() };
    var html = flHtml(list, flAr(s), o, '', '');
    flCtx = ctx;
    ab.boards.forEach(function (b) {
      var he = hostEl(b, host); if (!he) return;
      $$(':scope > [data-flid]', he).forEach(function (el) { el.remove(); });
      he.classList.toggle('has-fl', !!html);
      if (html) he.insertAdjacentHTML('beforeend', html);
    });
    abDraw();
  }
  function flCommit(host, opts) { flPatch(host); changed(Object.assign({ keepBoards: true }, opts || {})); if (view === 'layer') abInspector(); }

  /* ---------- 마우스 ---------- */
  function abPoint(e) { var r = abStageRect(); return { sx: e.clientX - r.left, sy: e.clientY - r.top }; }
  abHit.addEventListener('pointermove', function (e) {
    var p = abPoint(e), w = abWorldAt(p.sx, p.sy);
    if (ab.drag) { abDragMove(e, w); return; }
    var b = abBoardAt(w.x, w.y);
    var t = b ? abPick(b, w.x - b.x, w.y - b.y) : null;
    var nh = t && t.k !== 'board' ? t : null;
    if (!sameT(nh, ab.hover) || (nh && ab.hover && nh.b !== ab.hover.b)) { ab.hover = nh; abDraw(); }
    abHit.style.cursor = ab.space ? 'grab' : ab.tool === 'text' ? 'text' : ab.tool === 'rect' ? 'crosshair' : 'default';
  });
  abHit.addEventListener('pointerleave', function () { if (!ab.drag && ab.hover) { ab.hover = null; abDraw(); } });
  abHit.addEventListener('pointerdown', function (e) {
    abHit.setPointerCapture(e.pointerId);
    var p = abPoint(e), w = abWorldAt(p.sx, p.sy);
    if (e.button === 1 || ab.space || (e.button === 0 && ab.tool === 'hand')) { ab.drag = { mode: 'pan', sx: p.sx, sy: p.sy, x: ab.x, y: ab.y }; abHit.style.cursor = 'grabbing'; e.preventDefault(); return; }
    if (e.button !== 0) return;
    var b = abBoardAt(w.x, w.y), lx = b ? w.x - b.x : 0, ly = b ? w.y - b.y : 0;
    var t = b ? abPick(b, lx, ly) : null;
    if (ab.tool === 'text' || ab.tool === 'rect') {
      var host = !t ? null : t.k === 'fl' ? t.host : t.k === 'hero' ? 'hero' : t.k === 'sec' ? t.id : null;
      if (!host || !flHostOk(host)) { toast('글·사각형은 이미지 섹션이나 히어로 위에 놓을 수 있어요'); return; }
      if (ab.tool === 'text') { abAddText(b, host, lx, ly); return; }
      ab.drag = { mode: 'draw', b: b, host: host, start: { x: lx, y: ly }, rect: { x: lx, y: ly, w: 0, h: 0 }, moved: false };
      return;
    }
    if (t && t.k === 'fl') {
      var already = ab.sel.some(function (x) { return sameT(x, t); });
      if (e.shiftKey) { ab.sel = already ? ab.sel.filter(function (x) { return !sameT(x, t); }) : ab.sel.filter(function (x) { return x.k === 'fl'; }).concat([strip(t)]); ab.selB = b.key; abSelect(ab.sel, b.key); if (already) return; }
      else if (!already || ab.selB !== b.key) abSelect([strip(t)], b.key);
      abStartMove(b, w);
      return;
    }
    if (t && t.k === 'hero') {
      abSelect([strip(t)], b.key);
      abStartHeroMove(b, w, t);
      return;
    }
    // 섹션·빈 곳: 끌면 고르기 상자, 그냥 누르면 섹션 고르기
    ab.drag = { mode: 'marquee', b: b, start: w, t: t, shift: e.shiftKey, rect: { x: lx, y: ly, w: 0, h: 0 }, moved: false };
  });
  function strip(t) { var o = {}; ['k', 'host', 'id', 'part', 'idx', 'hero'].forEach(function (k) { if (t[k] != null) o[k] = t[k]; }); return o; }
  abHit.addEventListener('pointerup', function (e) { abDragEnd(e); });
  abHit.addEventListener('pointercancel', function (e) { abDragEnd(e); });
  abHit.addEventListener('dblclick', function () {
    var x = selFl()[0];
    if (x && x.L.t === 'text') abEditText(x);
  });
  // 글 레이어를 대지 위에서 바로 고치기 (두 번 누르기 · Enter). Esc나 다른 곳을 누르면 끝
  var abEditing = null;
  function abEditText(x) {
    var b = abBoardByKey(ab.selB) || ab.boards[0], el = abEl(b, x.t);
    if (!el) return;
    abEditEnd();
    try { el.contentEditable = 'plaintext-only'; } catch (e) { el.contentEditable = 'true'; }
    if (el.contentEditable !== 'plaintext-only') el.contentEditable = 'true';
    el.style.outline = 'none'; el.style.cursor = 'text';
    abEditing = { x: x, el: el, b: b };
    abHit.classList.add('is-editing');
    b.ifr.style.pointerEvents = 'auto';
    b.ifr.focus(); el.focus();
    var sel = b.doc.getSelection(), rg = b.doc.createRange(); rg.selectNodeContents(el); sel.removeAllRanges(); sel.addRange(rg);
    el.addEventListener('input', abEditInput);
    el.addEventListener('keydown', abEditKey);
    el.addEventListener('blur', abEditEnd);
    abDraw();
  }
  function abEditInput() { if (!abEditing) return; abEditing.x.L.text = abEditing.el.innerText.replace(/\n$/, ''); flLive(abEditing.x.t.host, abEditing.x.L); abDraw(); }
  function abEditKey(e) { if (e.key === 'Escape' || (e.key === 'Enter' && (e.ctrlKey || e.metaKey))) { e.preventDefault(); abEditEnd(); } }
  function abEditEnd() {
    var ed = abEditing; if (!ed) return;
    abEditing = null;
    ed.el.removeEventListener('input', abEditInput); ed.el.removeEventListener('keydown', abEditKey); ed.el.removeEventListener('blur', abEditEnd);
    ed.el.contentEditable = 'false';
    ed.b.ifr.style.pointerEvents = '';
    abHit.classList.remove('is-editing');
    try { ed.b.doc.getSelection().removeAllRanges(); } catch (e) {}
    abHit.focus({ preventScroll: true });   // 키보드를 다시 에디터로 (단축키가 대지 안에 갇히지 않게)
    var txt = ed.el.innerText.replace(/\n$/, '');
    if (!txt.trim()) { abSelect([{ k: 'fl', host: ed.x.t.host, id: ed.x.L.id }]); abDelete(); return; }   // 다 지우면 레이어도 빼기
    ed.x.L.text = txt;
    flCommit(ed.x.t.host);
    renderTree();
  }
  abStage.addEventListener('wheel', function (e) {
    if (!abOn()) return;
    e.preventDefault();
    var p = abPoint(e);
    if (e.ctrlKey || e.metaKey) { abZoomAt(ab.z * Math.exp(-e.deltaY * (e.deltaMode ? 0.05 : 0.0022)), p.sx, p.sy); return; }
    var k = e.deltaMode ? 40 : 1;
    if (e.shiftKey && !e.deltaX) { ab.x -= e.deltaY * k; } else { ab.x -= e.deltaX * k; ab.y -= e.deltaY * k; }
    abApply();
  }, { passive: false });
  // 손잡이로 크기 바꾸기
  abUi.addEventListener('pointerdown', function (e) {
    var tg = e.target.closest('.ab-sec');
    if (tg && e.button === 0) { e.preventDefault(); e.stopPropagation(); abSelect([{ k: 'sec', id: tg.getAttribute('data-sec-id') }], ab.boards[0].key, { reveal: true }); return; }
    var h = e.target.closest('.ab-h'); if (!h || e.button !== 0) return;
    e.preventDefault(); e.stopPropagation();
    abHit.setPointerCapture(e.pointerId);
    var p = abPoint(e), w = abWorldAt(p.sx, p.sy);
    abStartResize(h.getAttribute('data-h'), w);
  });

  function abStartMove(b, w) {
    var items = selFl().map(function (x) {
      var el = abEl(b, x.t), he = hostEl(b, x.t.host);
      return el && he ? { t: x.t, L: x.L, el: el, r0: elRect(el), H: elRect(he) } : null;
    }).filter(Boolean);
    if (!items.length) return;
    var host = items[0].t.host;
    var U = items.reduce(function (a, it) { var r = it.r0; return a ? { x: Math.min(a.x, r.x), y: Math.min(a.y, r.y), x1: Math.max(a.x1, r.x + r.w), y1: Math.max(a.y1, r.y + r.h) } : { x: r.x, y: r.y, x1: r.x + r.w, y1: r.y + r.h }; }, null);
    ab.drag = { mode: 'move', b: b, w0: w, items: items, U: { x: U.x, y: U.y, w: U.x1 - U.x, h: U.y1 - U.y }, lines: abSnapLines(b, host, items.map(function (it) { return it.el; })), moved: false, host: host };
  }
  function abStartHeroMove(b, w, t) {
    var el = abEl(b, t), he = b.doc.querySelector('.hero');
    if (!el || !he) return;
    ab.drag = { mode: 'hero', b: b, w0: w, t: t, el: el, r0: elRect(el), H: elRect(he), lines: abSnapLines(b, 'hero', [el]), moved: false };
  }
  function abStartResize(dir, w) {
    var one = ab.sel[0], b = abBoardByKey(ab.selB); if (!one || !b) return;
    var el = tEl(one, b); if (!el) return;
    var host = one.k === 'fl' ? one.host : 'hero', he = hostEl(b, host);
    ab.drag = { mode: 'resize', dir: dir, b: b, w0: w, t: one, L: one.k === 'fl' ? flGet(one.host, one.id) : null, el: el, r0: elRect(el), H: elRect(he), lines: abSnapLines(b, host, [el]), moved: false };
  }
  function abDragMove(e, w) {
    var dg = ab.drag;
    if (dg.mode === 'pan') { var p = abPoint(e); ab.x = dg.x + (p.sx - dg.sx); ab.y = dg.y + (p.sy - dg.sy); abApply(); return; }
    var dx = w.x - (dg.w0 ? dg.w0.x : dg.start.x), dy = w.y - (dg.w0 ? dg.w0.y : dg.start.y);
    if (!dg.moved) { if (Math.abs(dx) * ab.z < 3 && Math.abs(dy) * ab.z < 3) return; dg.moved = true; }
    var snapOff = e.ctrlKey || e.metaKey;   // Ctrl 누르고 끌면 스냅 없이
    if (dg.mode === 'move') {
      if (e.shiftKey) { if (Math.abs(dx) > Math.abs(dy)) dy = 0; else dx = 0; }
      var R = { x: dg.U.x + dx, y: dg.U.y + dy, w: dg.U.w, h: dg.U.h };
      var sn = snapOff ? { dx: 0, dy: 0 } : abSnap(R, dg.lines, { x: true, y: true }, {});
      dx += sn.dx; dy += sn.dy; R.x += sn.dx; R.y += sn.dy;
      ab.guides = snapOff ? [] : abGuideFrom(sn, R, dg.b.key);
      dg.items.forEach(function (it) {
        it.L.x = (it.r0.x + dx - it.H.x) / it.H.w; it.L.y = (it.r0.y + dy - it.H.y) / it.H.w;
        flLive(it.t.host, it.L);
      });
      abDraw(); return;
    }
    if (dg.mode === 'hero') {
      var R2 = { x: dg.r0.x, y: dg.r0.y + dy, w: dg.r0.w, h: dg.r0.h };
      var sn2 = snapOff ? { dy: 0 } : abSnap(R2, dg.lines, { y: true }, {});
      R2.y += sn2.dy || 0;
      ab.guides = snapOff ? [] : abGuideFrom(sn2, R2, dg.b.key);
      var topPct = clamp((R2.y - dg.H.y) / dg.H.h * 100, -20, 110);
      abHeroLive(dg.t, { top: topPct });
      dg.val = { top: topPct };
      abDraw(); return;
    }
    if (dg.mode === 'resize') { abResizeMove(e, dx, dy, snapOff); return; }
    if (dg.mode === 'marquee' || dg.mode === 'draw') {
      var b = dg.b; if (!b) { abDraw(); return; }
      var lx = w.x - b.x, ly = w.y - b.y, s0 = dg.mode === 'draw' ? dg.start : { x: dg.start.x - b.x, y: dg.start.y - b.y };
      if (dg.mode === 'draw' && e.shiftKey) { var m = Math.max(Math.abs(lx - s0.x), Math.abs(ly - s0.y)); lx = s0.x + Math.sign(lx - s0.x || 1) * m; ly = s0.y + Math.sign(ly - s0.y || 1) * m; }
      dg.rect = { x: Math.min(s0.x, lx), y: Math.min(s0.y, ly), w: Math.abs(lx - s0.x), h: Math.abs(ly - s0.y) };
      if (dg.mode === 'marquee') {   // 상자에 걸친 자유 레이어 고르기
        var hits = [];
        $$('[data-flid]', b.doc).forEach(function (el) {
          var r = elRect(el), q = dg.rect;
          if (r.x < q.x + q.w && r.x + r.w > q.x && r.y < q.y + q.h && r.y + r.h > q.y) { var p2 = el.parentElement; hits.push({ k: 'fl', host: p2.classList.contains('hero') ? 'hero' : p2.id, id: el.getAttribute('data-flid') }); }
        });
        ab.sel = hits; ab.selB = b.key;
      }
      abDraw();
    }
  }
  function abResizeMove(e, dx, dy, snapOff) {
    var dg = ab.drag, d = dg.dir, r = dg.r0, x0 = r.x, y0 = r.y, x1 = r.x + r.w, y1 = r.y + r.h;
    var keepRatio = e.shiftKey || (dg.L && dg.L.t === 'img') || dg.t.k === 'hero';
    var fromCenter = e.altKey || dg.t.k === 'hero';
    if (d.indexOf('w') >= 0) x0 += dx; if (d.indexOf('e') >= 0) x1 += dx;
    if (d.indexOf('n') >= 0) y0 += dy; if (d.indexOf('s') >= 0) y1 += dy;
    if (fromCenter) {
      if (d.indexOf('w') >= 0) x1 = r.x + r.w - dx; if (d.indexOf('e') >= 0) x0 = r.x - dx;
      if (d.indexOf('n') >= 0) y1 = r.y + r.h - dy; if (d.indexOf('s') >= 0) y0 = r.y - dy;
    }
    // 스냅: 움직이는 변만
    if (!snapOff) {
      var ex = [], ey = [];
      if (d.indexOf('w') >= 0) ex.push(x0); if (d.indexOf('e') >= 0) ex.push(x1);
      if (d.indexOf('n') >= 0) ey.push(y0); if (d.indexOf('s') >= 0) ey.push(y1);
      var sn = abSnap({ x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, dg.lines, { x: ex.length > 0, y: ey.length > 0 }, { x: ex, y: ey });
      if (sn.dx) { if (d.indexOf('w') >= 0 && Math.abs(ex[0] - x0) < 0.01) { x0 += sn.dx; if (fromCenter) x1 -= sn.dx; } else { x1 += sn.dx; if (fromCenter) x0 -= sn.dx; } }
      if (sn.dy) { if (d.indexOf('n') >= 0 && Math.abs(ey[0] - y0) < 0.01) { y0 += sn.dy; if (fromCenter) y1 -= sn.dy; } else { y1 += sn.dy; if (fromCenter) y0 -= sn.dy; } }
      ab.guides = abGuideFrom(sn, { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, dg.b.key);
    } else ab.guides = [];
    var W = Math.max(4, x1 - x0), Hh = Math.max(4, y1 - y0);
    if (keepRatio && r.w && r.h) {
      var ratio = r.h / r.w;
      if (d === 'n' || d === 's') W = Hh / ratio; else Hh = W * ratio;
      if (d.indexOf('w') >= 0 && !fromCenter) x0 = x1 - W;
      if (d.indexOf('n') >= 0 && !fromCenter) y0 = y1 - Hh;
      if (fromCenter) { x0 = r.x + r.w / 2 - W / 2; y0 = r.y + r.h / 2 - Hh / 2; }
    }
    if (dg.t.k === 'hero') {   // 배지·더 얹은 이미지: 가운데 기준 폭 %
      var wp = clamp(W / dg.H.w * 100, 5, 100);
      abHeroLive(dg.t, { w: wp }); dg.val = { w: wp };
      abDraw(); return;
    }
    var L = dg.L, H = dg.H;
    L.x = (x0 - H.x) / H.w; L.w = W / H.w;
    if (L.t === 'rect') { L.y = (y0 - H.y) / H.w; L.h = Hh / H.w; }
    else if (L.t === 'img') { L.y = (y0 - H.y) / H.w; }
    flLive(dg.t.host, L);
    abDraw();
  }
  function abDragEnd() {
    var dg = ab.drag; if (!dg) return;
    ab.drag = null; ab.guides = [];
    if (dg.mode === 'pan') { abHit.style.cursor = ab.space ? 'grab' : 'default'; return; }
    if (dg.mode === 'move' && dg.moved) { var hs = {}; dg.items.forEach(function (it) { hs[it.t.host] = 1; }); Object.keys(hs).forEach(function (h) { flPatch(h); }); changed({ keepBoards: true }); abInspector(); return; }
    if (dg.mode === 'resize' && dg.moved) {
      if (dg.t.k === 'hero') { abHeroCommit(dg.t, dg.val); return; }
      flCommit(dg.t.host); return;
    }
    if (dg.mode === 'hero' && dg.moved) { abHeroCommit(dg.t, dg.val); return; }
    if (dg.mode === 'draw') {
      var b = dg.b, he = hostEl(b, dg.host), H = elRect(he), q = dg.moved && dg.rect.w > 3 ? dg.rect : { x: dg.start.x - 60, y: dg.start.y - 30, w: 120, h: 60 };
      abAddLayer(dg.host, { t: 'rect', x: (q.x - H.x) / H.w, y: (q.y - H.y) / H.w, w: q.w / H.w, h: q.h / H.w, fill: 'brand', radius: 0 }, b.key);
      abTool('move'); return;
    }
    if (dg.mode === 'marquee') {
      if (dg.moved) { abSelect(ab.sel, dg.b && dg.b.key); return; }
      var t = dg.t;
      if (!t || t.k === 'board') { abSelect([], null); return; }
      abSelect([strip(t)], dg.b.key);
    }
    abDraw();
  }

  /* ---------- 히어로 글·배지 (기존 설정값을 끌어서) ---------- */
  function abHeroLive(t, v) {
    ab.boards.forEach(function (b) {
      if (!b.doc) return;
      var root = b.doc.documentElement.style;
      if (t.part === 'title' && v.top != null) root.setProperty('--title-top', v.top.toFixed(1) + '%');
      if (t.part === 'sub' && v.top != null) root.setProperty('--sub-top', v.top.toFixed(1) + '%');
      if (t.part === 'badge') { if (v.top != null) root.setProperty('--badge-top', v.top.toFixed(1) + '%'); if (v.w != null) root.setProperty('--badge-w', v.w.toFixed(1) + '%'); }
      if (t.part === 'layer') { var el = abEl(b, t); if (el) { if (v.top != null) el.style.top = v.top.toFixed(1) + '%'; if (v.w != null) el.style.width = v.w.toFixed(1) + '%'; } }
    });
  }
  function abHeroCommit(t, v) {
    if (!v) return;
    var r1 = function (n) { return Math.round(n * 10) / 10; };
    if (t.part === 'title' && v.top != null) state.titleTop = r1(v.top);
    if (t.part === 'sub' && v.top != null) state.subTop = r1(v.top);
    if (t.part === 'badge') { if (v.top != null) state.badgeTop = r1(v.top); if (v.w != null) state.badgeW = r1(v.w); }
    if (t.part === 'layer') { var L = state.heroLayers[t.idx]; if (L) { if (v.top != null) L.top = r1(v.top); if (v.w != null) L.w = r1(v.w); } }
    renderRanges(); if (typeof renderLayers === 'function') renderLayers();
    changed({ keepBoards: true });
    abDraw();
  }

  /* ---------- 레이어 만들기·고치기 ---------- */
  function abAddLayer(host, o, bk) {
    var list = flList(host, true); if (!list) return null;
    var L = Object.assign({ id: flUid(), opacity: 1, link: '' }, o);
    list.push(L);
    flPatch(host);
    changed({ keepBoards: true });
    abSelect([{ k: 'fl', host: host, id: L.id }], bk || ab.selB || 'm');
    return L;
  }
  function hostTone(host) {   // 칸 바탕이 어두우면 흰 글씨
    var im = host === 'hero' ? state.heroBg : (function () { var s = secAny(host); return s && (s.header || s.images[0]); })();
    return im && im.bg && lum(im.bg) > 150 ? '#111111' : '#ffffff';
  }
  function abAddText(b, host, lx, ly) {
    var he = hostEl(b, host), H = elRect(he), w = 0.6, x = clamp((lx - H.x) / H.w, 0, 1 - 0.1);
    if (x + w > 1) w = Math.max(0.2, 1 - x);
    abAddLayer(host, { t: 'text', text: '텍스트를 입력하세요', x: x, y: (ly - H.y) / H.w, w: w, font: 'pretendard', weight: 700, size: 24, lh: 1.3, ls: -0.01, color: hostTone(host), align: 'left' }, b.key);
    abTool('move');
    setTimeout(function () { var ta = $('#ly-body [data-ly="text"]'); if (ta) { ta.focus(); ta.select(); } }, 30);
  }
  async function abAddImage(files, host, at) {
    var f = Array.prototype.slice.call(files || []).find(function (x) { return /^image\//.test(x.type) || /\.(png|jpe?g|webp|gif)$/i.test(x.name); });
    if (!f) return;
    host = host || abCurHost();
    if (!host || !flHostOk(host)) { toast('이미지 섹션이나 히어로를 먼저 골라 주세요'); return; }
    var im = await loadImg(f, f.name), basis = flBasis(), w = clamp(Math.min(im.w, basis * 0.6) / basis, 0.05, 1);
    var x = at ? at.x - w / 2 : (1 - w) / 2, y = at ? at.y - w * im.h / im.w / 2 : 0.1;
    abAddLayer(host, { t: 'img', img: im, x: clamp(x, -0.5, 1), y: y, w: w, alt: '' });
    abTool('move');
  }
  function abCurHost() {
    var t = ab.sel[0];
    if (t) { if (t.k === 'fl') return t.host; if (t.k === 'hero') return 'hero'; if (t.k === 'sec') return t.id; }
    if (curSecIn() && curSec.kind === 'images') return curSec.id;
    var s = state.sections.find(function (x) { return flHostOk(x.id); });
    return s ? s.id : state.heroBg ? 'hero' : null;
  }
  function abDelete() {
    var xs = selFl(); if (!xs.length) return false;
    var hs = {};
    xs.forEach(function (x) { var l = flList(x.t.host); var i = l.indexOf(x.L); if (i >= 0) l.splice(i, 1); hs[x.t.host] = 1; });
    Object.keys(hs).forEach(function (h) { flPatch(h); });
    ab.sel = []; changed({ keepBoards: true }); abSelect([]);
    return true;
  }
  function abDuplicate(off) {
    var xs = selFl(); if (!xs.length) return;
    var b = abBoardByKey(ab.selB), nsel = [], hs = {};
    xs.forEach(function (x) {
      var he = b ? hostEl(b, x.t.host) : null, d = off && he ? 10 / elRect(he).w : 0;
      var c = JSON.parse(JSON.stringify(flData(x.L))); c.id = flUid(); c.x += d; c.y += d; if (x.L.img) c.img = x.L.img;
      var l = flList(x.t.host); l.splice(l.indexOf(x.L) + 1, 0, c); nsel.push({ k: 'fl', host: x.t.host, id: c.id }); hs[x.t.host] = 1;
    });
    Object.keys(hs).forEach(function (h) { flPatch(h); });
    changed({ keepBoards: true }); abSelect(nsel);
  }
  function abNudge(dx, dy) {
    var b = abBoardByKey(ab.selB) || ab.boards[0], xs = selFl(), hs = {};
    if (xs.length) {
      xs.forEach(function (x) { var he = b && hostEl(b, x.t.host); var W = he ? elRect(he).w : 375; x.L.x += dx / W; x.L.y += dy / W; hs[x.t.host] = 1; flLive(x.t.host, x.L); });
      clearTimeout(abNudge.t); abNudge.t = setTimeout(function () { Object.keys(hs).forEach(function (h) { flPatch(h); }); changed({ keepBoards: true }); abInspector(); }, 250);
      abDraw(); return true;
    }
    var t = ab.sel[0];
    if (t && t.k === 'hero' && dy && b) {   // 히어로 글·배지는 위아래만
      var he2 = b.doc.querySelector('.hero'), el = abEl(b, t); if (!he2 || !el) return false;
      var H = elRect(he2), r = elRect(el), top = (r.y + dy - H.y) / H.h * 100;
      abHeroLive(t, { top: top }); abHeroCommit(t, { top: top }); return true;
    }
    return false;
  }
  function abOrder(dir) {   // 1 앞으로, -1 뒤로, 9 맨 앞, -9 맨 뒤
    var xs = selFl(); if (!xs.length) return;
    var hs = {};
    xs.forEach(function (x) {
      var l = flList(x.t.host), i = l.indexOf(x.L); l.splice(i, 1);
      var j = dir === 9 ? l.length : dir === -9 ? 0 : clamp(i + dir, 0, l.length);
      l.splice(j, 0, x.L); hs[x.t.host] = 1;
    });
    Object.keys(hs).forEach(function (h) { flPatch(h); });
    changed({ keepBoards: true }); abInspector();
  }
  // 정렬: 하나면 칸 기준, 여럿이면 고른 범위 기준. 나누기는 3개 이상
  function abAlign(how) {
    var b = abBoardByKey(ab.selB) || ab.boards[0], xs = selFl(); if (!xs.length || !b) return;
    var items = xs.map(function (x) { var el = abEl(b, x.t), he = hostEl(b, x.t.host); return el && he ? { x: x, r: elRect(el), H: elRect(he) } : null; }).filter(Boolean);
    if (!items.length) return;
    var R = items.length === 1 ? items[0].H : items.reduce(function (a, it) { var r = it.r; return a ? { x: Math.min(a.x, r.x), y: Math.min(a.y, r.y), x1: Math.max(a.x1, r.x + r.w), y1: Math.max(a.y1, r.y + r.h) } : { x: r.x, y: r.y, x1: r.x + r.w, y1: r.y + r.h }; }, null);
    if (R.x1 != null) R = { x: R.x, y: R.y, w: R.x1 - R.x, h: R.y1 - R.y };
    if (how === 'dh' || how === 'dv') {
      if (items.length < 3) { toast('간격 맞추기는 3개 이상 골랐을 때 돼요'); return; }
      var hz = how === 'dh', sorted = items.slice().sort(function (a, c) { return hz ? a.r.x - c.r.x : a.r.y - c.r.y; });
      var total = sorted.reduce(function (t, it) { return t + (hz ? it.r.w : it.r.h); }, 0), span = hz ? R.w : R.h, gap = (span - total) / (sorted.length - 1), pos = hz ? R.x : R.y;
      sorted.forEach(function (it) { if (hz) it.nx = pos; else it.ny = pos; pos += (hz ? it.r.w : it.r.h) + gap; });
    } else items.forEach(function (it) {
      var r = it.r;
      if (how === 'l') it.nx = R.x; if (how === 'c') it.nx = R.x + R.w / 2 - r.w / 2; if (how === 'r') it.nx = R.x + R.w - r.w;
      if (how === 't') it.ny = R.y; if (how === 'm') it.ny = R.y + R.h / 2 - r.h / 2; if (how === 'b') it.ny = R.y + R.h - r.h;
    });
    var hs = {};
    items.forEach(function (it) {
      if (it.nx != null) it.x.L.x = (it.nx - it.H.x) / it.H.w;
      if (it.ny != null) it.x.L.y = (it.ny - it.H.y) / it.H.w;
      hs[it.x.t.host] = 1;
    });
    Object.keys(hs).forEach(function (h) { flPatch(h); });
    changed({ keepBoards: true }); abInspector();
  }

  /* ---------- 오른쪽 칸: 레이어 속성 ---------- */
  var AL_IC = {
    l: '<path d="M4 3v18M8 7h12v4H8zM8 14h7v4H8z"/>', c: '<path d="M12 3v18M6 7h12v4H6zM8.5 14h7v4h-7z"/>', r: '<path d="M20 3v18M4 7h12v4H4zM9 14h7v4H9z"/>',
    t: '<path d="M3 4h18M7 8h4v12H7zM14 8h4v7h-4z"/>', m: '<path d="M3 12h18M7 6h4v12H7zM14 8.5h4v7h-4z"/>', b: '<path d="M3 20h18M7 4h4v12H7zM14 9h4v7h-4z"/>',
    dh: '<path d="M4 4v16M20 4v16M10 7h4v10h-4z"/>', dv: '<path d="M4 4h16M4 20h16M7 10h10v4H7z"/>'
  };
  var AL_TIP = { l: '왼쪽 맞춤', c: '가운데 맞춤', r: '오른쪽 맞춤', t: '위 맞춤', m: '세로 가운데', b: '아래 맞춤', dh: '가로 간격 똑같이', dv: '세로 간격 똑같이' };
  var COLOR_CHIPS = [['#ffffff', '흰색'], ['#111111', '검정'], ['brand', '메인 색'], ['onbrand', '메인 색 위 글씨']];
  function chipCss(c) { return c === 'brand' ? (normHex(state.brand) || '#001241') : c === 'onbrand' ? onBrand() : c; }
  function colorField(key, val, label) {
    var hex = val === 'brand' || val === 'onbrand' ? chipCss(val) : (normHex(val) || '#111111');
    return '<div class="field"><span class="lab">' + label + '</span><div class="ly-color"><input type="color" class="color" data-ly="' + key + '" value="' + hex + '">' +
      COLOR_CHIPS.map(function (c) { return '<button type="button" class="ly-chip' + (val === c[0] ? ' is-on' : '') + '" data-ly-chip="' + key + '" data-v="' + c[0] + '" title="' + c[1] + '" style="background:' + chipCss(c[0]) + '"></button>'; }).join('') + '</div></div>';
  }
  function num(key, val, label, step, unit) {
    return '<label class="ly-num"><span>' + label + '</span><input class="inp" type="number" data-ly="' + key + '" value="' + val + '" step="' + (step || 1) + '">' + (unit ? '<em>' + unit + '</em>' : '') + '</label>';
  }
  function segH(key, opts, val) { return '<div class="seg small">' + opts.map(function (o) { return '<button type="button" data-ly-seg="' + key + '" data-v="' + o[0] + '"' + (String(val) === String(o[0]) ? ' class="is-on"' : '') + '>' + o[1] + '</button>'; }).join('') + '</div>'; }
  function abInspector() {
    var body = $('#ly-body'); if (!body) return;
    var xs = selFl();
    if (!xs.length) { body.innerHTML = '<p class="desc">대지에서 글·사각형·이미지를 고르면 여기서 고쳐요.</p>'; return; }
    var align = '<div class="ly-align">' + ['l', 'c', 'r', 't', 'm', 'b', 'dh', 'dv'].map(function (k) { return '<button type="button" class="icon" data-ly-align="' + k + '" title="' + AL_TIP[k] + '"><svg viewBox="0 0 24 24">' + AL_IC[k] + '</svg></button>'; }).join('') + '</div>';
    if (xs.length > 1) {
      $('#ly-title').textContent = '레이어 ' + xs.length + '개';
      body.innerHTML = align + '<p class="desc">하나만 고르면 위치·크기·글꼴을 고칠 수 있어요. 정렬은 고른 범위 기준이에요.</p>' + abOrderRow();
      return;
    }
    var L = xs[0].L, t = xs[0].t, basis = flBasis(), px = function (v) { return Math.round(v * basis * 10) / 10; };
    $('#ly-title').textContent = (KIND_NAME[L.t] || '레이어') + ' · ' + flHostLabel(t.host);
    var h = align +
      '<div class="ly-grid">' + num('x', px(L.x), 'X') + num('y', px(L.y), 'Y') + num('w', px(L.w), 'W') + (L.t === 'rect' ? num('h', px(L.h), 'H') : '') + '</div>' +
      '<p class="ly-note">' + basis + 'px 폭 기준이에요. 휴대폰·PC에선 칸 폭에 맞춰 같이 커지고 작아져요.</p>';
    if (L.t === 'text') {
      h += '<div class="field"><span class="lab">내용</span><textarea class="inp" data-ly="text" rows="3">' + esc(L.text || '') + '</textarea></div>' +
        '<div class="field"><span class="lab">글꼴</span>' + segH('font', LAYER_FONTS, L.font || 'pretendard') + '</div>' +
        '<div class="ly-grid">' + num('size', L.size || 24, '크기', 0.5, 'px') + num('lh', L.lh || 1.3, '줄 간격', 0.05) + num('ls', Math.round((L.ls || 0) * 1000) / 10, '자간', 0.5, '%') +
        ((L.font || 'pretendard') === 'pretendard' ? '<label class="ly-num"><span>굵기</span><select class="inp" data-ly="weight">' + [300, 400, 500, 600, 700, 800, 900].map(function (wv) { return '<option' + ((L.weight || 700) === wv ? ' selected' : '') + '>' + wv + '</option>'; }).join('') + '</select></label>' : '') + '</div>' +
        '<div class="field"><span class="lab">정렬</span>' + segH('align', [['left', '왼쪽'], ['center', '가운데'], ['right', '오른쪽']], L.align || 'left') + '</div>' +
        colorField('color', L.color || '#111111', '글자 색');
    } else if (L.t === 'rect') {
      h += colorField('fill', L.fill || 'brand', '채우기') +
        '<div class="ly-grid">' + num('radius', L.radius || 0, '모서리', 1, 'px') + num('strokeW', L.strokeW || 0, '테두리', 0.5, 'px') + '</div>' +
        (L.strokeW ? colorField('stroke', L.stroke || '#ffffff', '테두리 색') : '');
    } else if (L.t === 'img') {
      h += '<div class="field"><span class="lab">이미지</span><div class="ly-img"><img src="' + L.img.url + '" alt=""><label class="btn small">바꾸기<input type="file" accept="image/*" hidden data-ly-file></label></div></div>' +
        '<div class="field"><span class="lab">대체 텍스트</span><input class="inp" data-ly="alt" value="' + esc(L.alt || '') + '" placeholder="이미지 설명 (선택)"></div>';
    }
    h += '<div class="field"><span class="lab">투명도</span><div class="range"><input type="range" min="0" max="100" data-ly="opacity" value="' + Math.round((L.opacity == null ? 1 : L.opacity) * 100) + '"><span class="rv">' + Math.round((L.opacity == null ? 1 : L.opacity) * 100) + '%</span></div></div>' +
      '<div class="field"><span class="lab">누르면</span>' + segH('link', [['', '없음'], ['tel', '전화 걸기'], ['reserve', '방문예약']], L.link || '') + '</div>' +
      abOrderRow();
    body.innerHTML = h;
  }
  function abOrderRow() {
    return '<div class="ly-acts"><button type="button" class="btn small" data-ly-act="front" title="맨 앞으로 (Ctrl+Shift+])">맨 앞</button><button type="button" class="btn small" data-ly-act="fwd" title="앞으로 (Ctrl+])">앞으로</button>' +
      '<button type="button" class="btn small" data-ly-act="back" title="뒤로 (Ctrl+[)">뒤로</button><button type="button" class="btn small" data-ly-act="bottom" title="맨 뒤로 (Ctrl+Shift+[)">맨 뒤</button>' +
      '<button type="button" class="btn small" data-ly-act="dup" title="복제 (Ctrl+D)">복제</button><button type="button" class="btn small danger" data-ly-act="del" title="삭제 (Delete)">삭제</button></div>';
  }
  var lyBody = $('#ly-body');
  lyBody.addEventListener('input', function (e) {
    e.stopPropagation();
    var k = e.target.getAttribute('data-ly'); if (!k) return;
    var x = selFl()[0]; if (!x) return;
    var L = x.L, v = e.target.value, basis = flBasis();
    if (k === 'x' || k === 'y' || k === 'w' || k === 'h') { var n = parseFloat(v); if (isNaN(n)) return; L[k] = (k === 'w' || k === 'h' ? Math.max(1, n) : n) / basis; }
    else if (k === 'size' || k === 'lh' || k === 'radius' || k === 'strokeW') { var n2 = parseFloat(v); if (isNaN(n2)) return; L[k] = Math.max(0, n2); }
    else if (k === 'ls') { var n3 = parseFloat(v); if (isNaN(n3)) return; L.ls = n3 / 100; }
    else if (k === 'weight') L.weight = +v;
    else if (k === 'opacity') { L.opacity = clamp(+v / 100, 0, 1); var rv = e.target.nextElementSibling; if (rv) rv.textContent = v + '%'; }
    else if (k === 'color' || k === 'fill' || k === 'stroke') { L[k] = v; $$('#ly-body [data-ly-chip="' + k + '"]').forEach(function (c) { c.classList.remove('is-on'); }); }
    else L[k] = v;
    flPatch(x.t.host);
    changed({ keepBoards: true });
    if (k === 'text') renderTree();
  });
  lyBody.addEventListener('change', async function (e) {
    e.stopPropagation();
    if (e.target.hasAttribute('data-ly-file') && e.target.files[0]) {
      var x = selFl()[0]; if (!x) return;
      x.L.img = await loadImg(e.target.files[0], e.target.files[0].name); e.target.value = '';
      flCommit(x.t.host);
    }
  });
  lyBody.addEventListener('click', function (e) {
    var a = e.target.closest('[data-ly-align]'); if (a) { abAlign(a.getAttribute('data-ly-align')); return; }
    var s = e.target.closest('[data-ly-seg]'), c = e.target.closest('[data-ly-chip]'), act = e.target.closest('[data-ly-act]');
    var x = selFl()[0];
    if (act) { var v = act.getAttribute('data-ly-act'); if (v === 'del') abDelete(); else if (v === 'dup') abDuplicate(true); else abOrder({ front: 9, fwd: 1, back: -1, bottom: -9 }[v]); return; }
    if (!x) return;
    if (s) { x.L[s.getAttribute('data-ly-seg')] = s.getAttribute('data-v'); flCommit(x.t.host); return; }
    if (c) { x.L[c.getAttribute('data-ly-chip')] = c.getAttribute('data-v'); flCommit(x.t.host); }
  });

  /* ---------- 왼쪽 목록: 자유 레이어 줄 ---------- */
  var TI_FL = { text: '<svg viewBox="0 0 24 24"><path d="M5 6h14M12 6v13"/></svg>', rect: '<svg viewBox="0 0 24 24"><rect x="5" y="6" width="14" height="12" rx="1.5"/></svg>', img: '<svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="14" rx="2"/><path d="M4 16l5-5 4 4 3-3 4 4"/></svg>' };
  function flTreeRows(rows, L, isC, onPg) {
    if (!ab) return rows;
    var mk = function (host) {
      var list = flList(host) || [];
      return list.slice().reverse().map(function (Lr) {
        var on = ab.sel.some(function (t) { return t.k === 'fl' && t.host === host && t.id === Lr.id; });
        return '<div class="tr tr-fl' + (on ? ' is-on' : '') + (Lr.hidden ? ' is-dim' : '') + '" data-tr="fl" data-host="' + esc(host) + '" data-id="' + esc(Lr.id) + '"><span class="tr-no"></span>' +
          '<span class="tr-pic tr-ic">' + (TI_FL[Lr.t] || '') + '</span><span class="tr-t"><b>' + esc(flName(Lr)) + '</b><small>' + (KIND_NAME[Lr.t] || '') + '</small></span>' +
          '<button type="button" class="tr-eye' + (Lr.hidden ? ' off' : '') + '" data-tr-fl-hide="1" title="' + (Lr.hidden ? '숨김 (누르면 보이기)' : '보임 (누르면 숨기기)') + '">' + (Lr.hidden ? TI.eyeOff : TI.eye) + '</button></div>';
      }).join('');
    };
    var out = [];
    rows.forEach(function (r) {
      out.push(r);
      var m = /data-tr="hero"/.test(r) ? 'hero' : (/data-tr="sec" data-i="(\d+)"/.exec(r) || [])[1];
      if (m === 'hero') { var hr = mk('hero'); if (hr) out.push(hr); }
      else if (m != null) { var s = L[+m]; if (s && s.fl && s.fl.length) out.push(mk(s.id)); }
    });
    return out;
  }
  $('#tree').addEventListener('click', function (e) {
    var hb = e.target.closest('[data-tr-fl-hide]'); if (!hb) return;
    e.stopPropagation();
    var r = hb.closest('[data-tr="fl"]'), L = flGet(r.getAttribute('data-host'), r.getAttribute('data-id')); if (!L) return;
    L.hidden = !L.hidden; flPatch(r.getAttribute('data-host')); changed({ keepBoards: true });
  }, true);

  /* ---------- 모드·도구 ---------- */
  function abTool(t) {
    ab.tool = t;
    $$('#ab-tools [data-tool]').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-tool') === t); });
    abHit.style.cursor = t === 'text' ? 'text' : t === 'rect' ? 'crosshair' : 'default';
  }
  function abMode(on) {
    if (on === ab.on) return;
    ab.on = on;
    $('#canvas').classList.toggle('is-board', on);
    $$('#cv-mode button').forEach(function (b) { b.classList.toggle('is-on', (b.getAttribute('data-v') === 'board') === on); });
    $('#pv-stage').hidden = on; abStage.hidden = !on;
    $('#pv-device').hidden = on; $('#ab-tools').hidden = !on; $('#ab-show').hidden = !on;
    $('#cv-hint').textContent = on ? 'Alt: 거리 · Shift: 비율·여러 개 · 화살표: 1px (Shift 10px) · Shift+1: 다 보기' : 'Ctrl+휠 확대·축소 · 스페이스+끌기 이동';
    if (on) { renderBoards(); abTool('move'); }
    else { ab.sel = []; ab.hover = null; renderPreview(); layoutPreview(); if (view === 'layer') setView(curSecIn() ? 'sections' : 'upload'); }
    renderTree(); abDraw();
  }
  $('#cv-mode').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) abMode(b.getAttribute('data-v') === 'board'); });
  $('#ab-tools').addEventListener('click', function (e) {
    var b = e.target.closest('[data-tool]'); if (!b) return;
    var t = b.getAttribute('data-tool');
    if (t === 'img') { $('#ab-img-input').click(); return; }
    abTool(t);
  });
  $('#ab-img-input').addEventListener('change', function (e) { abAddImage(e.target.files); e.target.value = ''; });
  $('#ab-show').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    ab.show = b.getAttribute('data-v');
    $$('#ab-show button').forEach(function (x) { x.classList.toggle('is-on', x === b); });
    ab.fitted = false; renderBoards();
  });
  // 이미지 파일을 대지 위 칸에 끌어다 놓으면 그 자리에 이미지 레이어
  abHit.addEventListener('dragover', function (e) { if (e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types, 'Files') >= 0) { e.preventDefault(); e.stopPropagation(); } });
  abHit.addEventListener('drop', function (e) {
    if (!e.dataTransfer || !e.dataTransfer.files.length) return;
    e.preventDefault(); e.stopPropagation();
    var p = abPoint(e), w = abWorldAt(p.sx, p.sy), b = abBoardAt(w.x, w.y), t = b ? abPick(b, w.x - b.x, w.y - b.y) : null;
    var host = t ? (t.k === 'fl' ? t.host : t.k === 'hero' ? 'hero' : t.k === 'sec' ? t.id : null) : null;
    var fs0 = e.dataTransfer.files;
    if (fs0.length > 1 || /\.zip$/i.test(fs0[0].name) || !/^image\//.test(fs0[0].type) || !host || !flHostOk(host)) { addFiles(fs0); return; }
    var H = elRect(hostEl(b, host));
    ab.selB = b.key;
    abAddImage(e.dataTransfer.files, host, { x: (w.x - b.x - H.x) / H.w, y: (w.y - b.y - H.y) / H.w });
  });
  // 확대 버튼도 대지 모드면 대지를
  ['#zoom-in', '#zoom-out', '#zoom-val', '#zoom-fit'].forEach(function (sel) {
    $(sel).addEventListener('click', function (e) {
      if (!abOn()) return;
      e.stopImmediatePropagation();
      if (sel === '#zoom-in') abZoomStep(1); else if (sel === '#zoom-out') abZoomStep(-1); else if (sel === '#zoom-val') abZoomAt(1); else abFitAll();
    }, true);
  });
  window.addEventListener('resize', function () { if (abOn()) abDraw(); });

  /* ---------- 단축키 (피그마와 같게) ---------- */
  document.addEventListener('keydown', function (e) {
    if (!abOn()) return;
    if (e.key === 'Alt') { if (!ab.alt) { ab.alt = true; abDraw(); } e.preventDefault(); return; }
    if (!$('#modal').hidden || isTyping(e.target)) return;
    var c = e.code, mod = e.ctrlKey || e.metaKey, done = true;
    if (c === 'Space') { if (!ab.space) { ab.space = true; abHit.style.cursor = 'grab'; } e.preventDefault(); return; }
    if (!mod && !e.altKey && c === 'KeyV') abTool('move');
    else if (!mod && !e.altKey && c === 'KeyT') abTool('text');
    else if (!mod && !e.altKey && c === 'KeyR') abTool('rect');
    else if (!mod && e.shiftKey && c === 'Digit1') abFitAll();
    else if (!mod && e.shiftKey && c === 'Digit2') abFitSel();
    else if (!mod && e.shiftKey && c === 'Digit0') abZoomAt(1);
    else if (mod && (c === 'Digit0' || c === 'Numpad0')) abZoomAt(1);
    else if (mod && (c === 'Equal' || c === 'NumpadAdd')) abZoomStep(1);
    else if (mod && (c === 'Minus' || c === 'NumpadSubtract')) abZoomStep(-1);
    else if (c === 'Escape') { if (ab.tool !== 'move') abTool('move'); else if (ab.sel.length) abSelect([]); else done = false; }
    else if ((c === 'Delete' || c === 'Backspace') && !mod) done = abDelete();
    else if (c.indexOf('Arrow') === 0 && !mod) { var st = e.shiftKey ? 10 : 1; done = abNudge(c === 'ArrowLeft' ? -st : c === 'ArrowRight' ? st : 0, c === 'ArrowUp' ? -st : c === 'ArrowDown' ? st : 0); }
    else if (mod && c === 'KeyD') { if (selFl().length) abDuplicate(true); else done = false; }
    else if (mod && c === 'KeyC' && !e.shiftKey && selFl().length) { ab.clip = selFl().map(function (x) { var d = JSON.parse(JSON.stringify(flData(x.L))); if (x.L.img) d.img = x.L.img; return d; }); toast('레이어 ' + ab.clip.length + '개를 복사했어요'); }
    else if (mod && c === 'KeyV' && !e.shiftKey && ab.clip && ab.clip.length) {
      var host = abCurHost(); if (!host || !flHostOk(host)) { done = false; }
      else {
        var list = flList(host, true), ns = [];
        ab.clip.forEach(function (d) { var n = Object.assign({}, d, { id: flUid() }); if (d.img) n.img = d.img; list.push(n); ns.push({ k: 'fl', host: host, id: n.id }); });
        flPatch(host); changed({ keepBoards: true }); abSelect(ns);
      }
    }
    else if (mod && c === 'KeyA' && !e.shiftKey) { var h0 = abCurHost(), l0 = h0 ? flList(h0) || [] : []; if (l0.length) abSelect(l0.map(function (L) { return { k: 'fl', host: h0, id: L.id }; })); else done = false; }
    else if (mod && c === 'BracketRight') abOrder(e.shiftKey ? 9 : 1);
    else if (mod && c === 'BracketLeft') abOrder(e.shiftKey ? -9 : -1);
    else if (c === 'Enter' && !mod) { var x = selFl()[0]; if (x && x.L.t === 'text') abEditText(x); else done = false; }
    else done = false;
    if (done) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  document.addEventListener('keyup', function (e) {
    if (e.key === 'Alt') { ab.alt = false; abDraw(); if (abOn()) e.preventDefault(); }
    if (e.code === 'Space' && ab.space) { ab.space = false; abHit.style.cursor = 'default'; }
  });
  window.addEventListener('blur', function () { ab.alt = false; ab.space = false; });
  // 내보내기 전 검사: 휴대폰에서 문제 될 자유 레이어 (칸 밖으로 잘림 · 너무 작은 글자 · 누르기 어려운 크기)
  function flChecks(add) {
    var hosts = [{ name: '히어로', list: state.heroFl || [], ar: flAr('hero'), basis: 375 }];
    MAIN().forEach(function (s) { if (s.fl && s.fl.length) hosts.push({ name: s.label || '섹션', list: s.fl, ar: flAr(s), basis: 375 }); });
    if (isMenuMode()) menuPages().forEach(function (x) { (x.page.sections || []).forEach(function (s) { if (s.fl && s.fl.length) hosts.push({ name: x.page.name + ' › ' + (s.label || '섹션'), list: s.fl, ar: flAr(s), basis: x.page.cw || 1200 }); }); });
    var n = 0, out = [], small = [], tiny = [];
    hosts.forEach(function (h) {
      h.list.forEach(function (L) {
        if (L.hidden) return;
        n++;
        var hh = L.t === 'rect' ? L.h : L.t === 'img' && L.img ? L.w * L.img.h / L.img.w : L.t === 'text' ? (L.size || 24) * (L.lh || 1.3) * Math.max(1, String(L.text || '').split('\n').length) / h.basis : 0;
        if (L.x < -0.002 || L.x + L.w > 1.002 || L.y < -0.002 || L.y + hh > h.ar + 0.002) out.push(h.name + ' · ' + flName(L));
        if (L.t === 'text' && (L.size || 24) * 375 / h.basis < 12) small.push(h.name + ' · ' + flName(L));
        if (L.link && hh * 375 < 40) tiny.push(h.name + ' · ' + flName(L));
      });
    });
    if (!n) return;
    add('ok', '대지에서 놓은 레이어 ' + n + '개');
    if (out.length) add('warn', '칸 밖으로 나가서 잘리는 레이어: ' + out.join(', '));
    if (small.length) add('warn', '휴대폰에서 12px보다 작은 글자: ' + small.join(', '));
    if (tiny.length) add('warn', '누르는 레이어가 작아요 (휴대폰에서 높이 40px 이상 권장): ' + tiny.join(', '));
  }


  abApi = { select: abSelect, selectFl: abSelectFl, mode: abMode, tool: abTool, zoomAt: abZoomAt, fitAll: abFitAll, align: abAlign, add: abAddLayer, del: abDelete, dup: abDuplicate, nudge: abNudge, order: abOrder, pick: abPick, board: abBoardByKey, toScreen: abToScreen, el: abEl, list: flList };
  setTimeout(function () { abMode(!/[?&]view=preview/.test(location.search)); }, 0);


  // 테스트·자동화용
  window.__editor = {
    state: function () { return state; }, lastZip: function () { return lastZip; }, placed: function () { return lastPlaced; }, renderPage: renderPage, scan: function () { return lastScan; }, ab: function () { return ab; }, abApi: function () { return abApi; }, readTitle: readTitle, fileTitle: fileTitle,
    store: { flush: autosave, addHistory: addHistory, list: function () { return getAll('snaps'); }, blobKeys: function () { return getAllKeys('blobs'); }, ready: function () { return storeReady; }, sid: SID },
    team: function () { return { mode: team.mode, others: team.others, name: myName, url: presUrl }; },
    undo: function () { return { back: undoStack.length, fwd: redoStack.length, pending: !!undoT, clip: secClip ? secClip.label : null, cur: curSec ? curSec.label : null }; }
  };

  setView(hasContent() ? 'sections' : 'upload');
  render();
  // 마법도구에서 '사내 에디터 열기'로 넘어온 경우(?siteurl=…): 그 홈페이지 주소를 가져오기 칸에 채워 둠
  (function () {
    var m = /[?&]siteurl=([^&]+)/.exec(location.search);
    if (!m) return;
    try { $('#f-site-url').value = decodeURIComponent(m[1]); } catch (e) { return; }
    setView('menus');
  })();
})();
