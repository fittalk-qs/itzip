(function () {
  'use strict';

  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var root = document.documentElement;
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------------------------------------------------
     0. 우클릭·끌기·끌어서 글자 선택 막기 (입력칸은 그대로)
     --------------------------------------------------------- */
  var typing = function (el) { return el && el.closest && el.closest('input, textarea, select, [contenteditable="true"]'); };
  ['contextmenu', 'dragstart', 'selectstart'].forEach(function (type) {
    document.addEventListener(type, function (e) { if (!typing(e.target)) e.preventDefault(); });
  });

  /* ---------------------------------------------------------
     0-1. 원페이지 + 메뉴 페이지: 메뉴 페이지는 PC에서 화면 전체로 싸악 넓어지고,
          홈·방문예약은 (메뉴 페이지에서 왔으면) 넓은 채로 시작해서 다시 좁아짐
     --------------------------------------------------------- */
  if (root.getAttribute('data-mode') === 'menu') {
    var wideTarget = root.hasAttribute('data-wide'), ss = null;
    try { ss = window.sessionStorage; } catch (e) { ss = null; }
    if (root.classList.contains('is-wide') !== wideTarget) {
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          root.classList.toggle('is-wide', wideTarget);
          setTimeout(function () {
            window.dispatchEvent(new Event('resize'));   // 폭이 바뀐 뒤 슬라이드 다시 맞춤
            // 메뉴 페이지에서 메인의 섹션(#…)으로 왔으면, 좁아진 뒤 그 섹션으로 다시 맞춤
            var hashTarget = location.hash && document.getElementById(location.hash.slice(1));
            if (hashTarget) hashTarget.scrollIntoView({ block: 'start' });
          }, 800);
        });
      });
    }
    try { if (ss) { ss.setItem('lp-wide', wideTarget ? '1' : '0'); ss.setItem('lp-intro', '1'); } } catch (e) {}
  }

  /* ---------------------------------------------------------
     1. 링크
        - 메인의 '방문예약 등록' → contact/ 페이지
        - contact 페이지의 '방문예약 등록'(data-go-reserve) → 맨 위 폼 자리로 이동
          (폼은 <div data-leadyo-form> 안에 따로 들어감)
     --------------------------------------------------------- */
  // 로컬 파일(file://)로 열면 폴더 링크(contact/, ../)가 안 열려서 index.html을 붙여 줌
  if (location.protocol === 'file:') {
    $$('a[href]').forEach(function (a) {
      var h = a.getAttribute('href'), m = /^([^#?]*\/)(#.*)?$/.exec(h);
      if (m && !/^[a-z]+:/i.test(h)) a.setAttribute('href', m[1] + 'index.html' + (m[2] || ''));
    });
  }

  $$('[data-go-reserve]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var target = $('#reserve');
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    });
  });

  /* ---------------------------------------------------------
     2. 스크롤 페이드업 (이미지가 로드된 뒤에 한 번만)
     --------------------------------------------------------- */
  $$('section[data-anim] .vbox, section[data-anim] .tv').forEach(function (el) { el.classList.add('reveal'); });
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var el = en.target, rep = el.closest('[data-anim-rep]');
        if (!en.isIntersecting) { if (rep) el.classList.remove('is-in'); return; }   // 반복: 나갔다 들어오면 다시
        if (!rep) io.unobserve(el);
        var img = $('img', el);
        var show = function () { el.classList.add('is-in'); };
        if (!img || img.complete) show();
        else {
          img.addEventListener('load', show, { once: true });
          img.addEventListener('error', show, { once: true });
        }
      });
    }, { rootMargin: '0px 0px -12% 0px' });
    $$('.reveal').forEach(function (el) { io.observe(el); });
  } else {
    $$('.reveal').forEach(function (el) { el.classList.add('is-in'); });
  }

  /* ---------------------------------------------------------
     3. 슬라이드 섹션 (타입 안내·인테리어 등): 좌우로 넘기기 + 탭(있을 때만)
        한 페이지에 여러 개 가능. 각 .tv 의 data-types:
        [["이름", 세로px(가로 860 기준), "이미지 경로", "대체 텍스트"], ...]
        경로가 없으면 img/type/type_이름.jpg (예전 형식)
     --------------------------------------------------------- */
  var refreshViewers = [];
  function initViewer(tv) {
    var sec = tv.parentElement;
    var ITEMS = JSON.parse(tv.getAttribute('data-types') || '[]');
    if (!ITEMS.length) return function () {};
    var tabsEl = $('.tabs', sec), tabsWrap = $('.tabs-wrap', sec), ink = tabsEl ? $('.tabs-ink', tabsEl) : null;
    var vp = $('.tv-vp', tv), track = $('.tv-track', tv);
    var prevBtn = $('.tv-prev', tv), nextBtn = $('.tv-next', tv), countEl = $('.tv-count b', tv);
    var total = $('.tv-count span', tv);
    if (total) total.textContent = ITEMS.length;
    if (ITEMS.length < 2) tv.classList.add('is-single');

    var tabs = [], slides = [], cur = 0;
    ITEMS.forEach(function (t, i) {
      var label = String(t[0] == null ? '' : t[0]);
      if (tabsEl) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'tab';
        b.setAttribute('role', 'tab');
        b.textContent = label;
        b.addEventListener('click', function () { go(i); });
        tabsEl.appendChild(b);
        tabs.push(b);
      }
      var s = document.createElement('div');
      s.className = 'tv-slide';
      var img = document.createElement('img');
      img.width = 860;
      img.height = t[1];
      img.alt = t[3] || label;
      img.setAttribute('data-src', t[2] || ('img/type/type_' + label.replace(/,/g, '') + '.jpg'));
      s.appendChild(img);
      track.appendChild(s);
      slides.push(s);
    });

    function load(i) {
      var s = slides[i];
      if (!s) return;
      var img = $('img', s);
      if (!img.getAttribute('src')) img.src = img.getAttribute('data-src');
    }

    function go(i, instant) {
      cur = Math.max(0, Math.min(ITEMS.length - 1, i));
      track.style.transform = 'translate3d(' + (-cur * 100) + '%,0,0)';
      vp.style.height = slides[cur].offsetHeight + 'px';
      [cur - 1, cur, cur + 1, cur + 2].forEach(load);
      if (tabsEl) {
        tabs.forEach(function (b, k) {
          b.classList.toggle('is-on', k === cur);
          b.setAttribute('aria-selected', k === cur);
        });
        var on = tabs[cur];
        ink.style.width = on.offsetWidth + 'px';
        ink.style.transform = 'translateX(' + on.offsetLeft + 'px)';
        var left = on.offsetLeft - (tabsEl.clientWidth - on.offsetWidth) / 2;
        if (tabsEl.scrollTo) tabsEl.scrollTo({ left: left, behavior: instant || reduce ? 'auto' : 'smooth' });
        else tabsEl.scrollLeft = left;
      }
      if (countEl) countEl.textContent = cur + 1;
      prevBtn.disabled = cur === 0;
      nextBtn.disabled = cur === ITEMS.length - 1;
    }

    // 탭 줄 옆으로 넘기기: 손가락(기본) + PC 마우스 휠·드래그 + 양끝 화살표
    if (tabsEl && tabsWrap) {
      var arrowSvg = function (d) { return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>'; };
      var arrowL = document.createElement('button');
      var arrowR = document.createElement('button');
      arrowL.type = arrowR.type = 'button';
      arrowL.className = 'tabs-arrow tabs-arrow--l';
      arrowR.className = 'tabs-arrow tabs-arrow--r';
      arrowL.setAttribute('aria-label', '목록 왼쪽으로');
      arrowR.setAttribute('aria-label', '목록 오른쪽으로');
      arrowL.innerHTML = arrowSvg('M15.41 16.59 10.83 12l4.58-4.59L14 6l-6 6 6 6z');
      arrowR.innerHTML = arrowSvg('M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6z');
      tabsWrap.appendChild(arrowL);
      tabsWrap.appendChild(arrowR);
      var scrollTabs = function (dir) {
        tabsEl.scrollBy({ left: dir * tabsEl.clientWidth * 0.7, behavior: reduce ? 'auto' : 'smooth' });
      };
      arrowL.addEventListener('click', function () { scrollTabs(-1); });
      arrowR.addEventListener('click', function () { scrollTabs(1); });

      // 양끝에 닿으면 그쪽 화살표·페이드 숨김, 넘칠 게 없으면 둘 다 숨김
      var onTabsScroll = function () {
        var max = tabsEl.scrollWidth - tabsEl.clientWidth;
        tabsWrap.classList.toggle('is-start', tabsEl.scrollLeft <= 2);
        tabsWrap.classList.toggle('is-end', tabsEl.scrollLeft >= max - 2);
      };
      tabsEl.addEventListener('scroll', onTabsScroll, { passive: true });
      window.addEventListener('resize', onTabsScroll);
      onTabsScroll();

      // 마우스 휠: 세로 휠을 가로 이동으로 (끝에 닿으면 원래대로 페이지 스크롤)
      tabsEl.addEventListener('wheel', function (e) {
        if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
        var max = tabsEl.scrollWidth - tabsEl.clientWidth;
        if ((e.deltaY < 0 && tabsEl.scrollLeft <= 0) || (e.deltaY > 0 && tabsEl.scrollLeft >= max - 1)) return;
        e.preventDefault();
        tabsEl.scrollLeft += e.deltaY;
      }, { passive: false });

      // 마우스로 잡아 끌기 (끌었을 땐 탭이 눌리지 않게)
      var tabDrag = null, tabDragged = false;
      tabsEl.addEventListener('pointerdown', function (e) {
        if (e.pointerType !== 'mouse' || e.button !== 0) return;
        tabDrag = { x: e.clientX, left: tabsEl.scrollLeft };
        tabDragged = false;
      });
      window.addEventListener('pointermove', function (e) {
        if (!tabDrag) return;
        var d = e.clientX - tabDrag.x;
        if (!tabDragged && Math.abs(d) > 5) { tabDragged = true; tabsWrap.classList.add('is-dragging'); }
        if (tabDragged) tabsEl.scrollLeft = tabDrag.left - d;
      });
      window.addEventListener('pointerup', function () {
        if (!tabDrag) return;
        tabDrag = null;
        tabsWrap.classList.remove('is-dragging');
      });
      tabsEl.addEventListener('click', function (e) {
        if (tabDragged) { e.stopPropagation(); e.preventDefault(); tabDragged = false; }
      }, true);
      tabsEl.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') { go(cur + 1); tabs[cur].focus(); }
        if (e.key === 'ArrowLeft') { go(cur - 1); tabs[cur].focus(); }
      });
    }

    prevBtn.addEventListener('click', function () { go(cur - 1); });
    nextBtn.addEventListener('click', function () { go(cur + 1); });

    // 손가락으로 넘기기 (세로 스크롤은 그대로)
    var sx = 0, sy = 0, dx = 0, dragging = false, down = false;
    vp.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      down = true; dragging = false; dx = 0; sx = e.clientX; sy = e.clientY;
    });
    vp.addEventListener('pointermove', function (e) {
      if (!down) return;
      dx = e.clientX - sx;
      var dy = e.clientY - sy;
      if (!dragging) {
        if (Math.abs(dx) < 8 || Math.abs(dx) < Math.abs(dy)) return;
        dragging = true;
        track.classList.add('is-drag');
        try { vp.setPointerCapture(e.pointerId); } catch (err) {}
      }
      var edge = (cur === 0 && dx > 0) || (cur === ITEMS.length - 1 && dx < 0);
      var off = edge ? dx * 0.3 : dx;
      track.style.transform = 'translate3d(calc(' + (-cur * 100) + '% + ' + off + 'px),0,0)';
    });
    function endDrag() {
      if (!down) return;
      down = false;
      if (!dragging) return;
      dragging = false;
      track.classList.remove('is-drag');
      if (dx < -50) go(cur + 1);
      else if (dx > 50) go(cur - 1);
      else go(cur);
    }
    vp.addEventListener('pointerup', endDrag);
    vp.addEventListener('pointercancel', endDrag);

    window.addEventListener('resize', function () { go(cur, true); });

    // 처음 보일 때 한 번 살짝 밀어서 '넘길 수 있다'는 힌트
    if ('IntersectionObserver' in window && !reduce && ITEMS.length > 1) {
      var hintIO = new IntersectionObserver(function (entries) {
        if (!entries[0].isIntersecting) return;
        hintIO.disconnect();
        if (cur !== 0) return;
        track.classList.add('is-hint');
        track.addEventListener('animationend', function () { track.classList.remove('is-hint'); }, { once: true });
      }, { threshold: 0.5 });
      hintIO.observe(vp);
    }

    go(0, true);
    return function () { go(cur, true); };
  }
  $$('.tv').forEach(function (tv) { refreshViewers.push(initViewer(tv)); });

  /* ---------------------------------------------------------
     4. 헤더: 스크롤하면 그림자 / 메뉴 버튼 → 빠른 이동 패널
     --------------------------------------------------------- */
  var hd = $('.hd');
  var onScroll = function () { hd.classList.toggle('is-scrolled', window.scrollY > 4); };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // 패널 목록은 PC 오른쪽 메뉴 링크를 그대로 복사 (메뉴를 바꿀 땐 .pc-right만 고치면 됨)
  var menuList = $('.hd-menu-list');
  if (menuList) {
    $$('.pc-right a').forEach(function (a, i) {
      var li = document.createElement('li');
      li.style.setProperty('--i', i);
      li.appendChild(a.cloneNode(true));
      menuList.appendChild(li);
    });
  }
  var menuBtn = $('.hd-menu-btn');
  var setMenu = function (open) {
    root.classList.toggle('menu-open', open);
    if (menuBtn) menuBtn.setAttribute('aria-expanded', open);
  };
  if (menuBtn) menuBtn.addEventListener('click', function () { setMenu(!root.classList.contains('menu-open')); });
  if ($('.hd-dim')) $('.hd-dim').addEventListener('click', function () { setMenu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });

  /* ---------------------------------------------------------
     4-1. 메뉴 줄 (원페이지 + 메뉴 페이지)
        - 소메뉴가 있는 대메뉴: 누르면 소메뉴가 차르르 펼쳐짐 (다른 대메뉴는 접힘)
        - 메뉴 페이지에선 지금 페이지의 대메뉴가 펼쳐진 채로 시작, 바깥을 누르면 그 상태로 돌아감
        - 메뉴가 많으면 옆으로 밀기 (PC는 휠로)
     --------------------------------------------------------- */
  var mbar = $('.menubar');
  if (mbar) {
    var groups = $$('.mb-group', mbar), homeGroup = $('.mb-group.is-home', mbar);
    var openSub = function (btn) {
      groups.forEach(function (g) {
        var on = g === btn;
        g.classList.toggle('is-open', on);
        g.setAttribute('aria-expanded', on);
        var p = document.getElementById(g.getAttribute('aria-controls'));
        if (p) p.classList.toggle('is-open', on);
      });
    };
    groups.forEach(function (g) {
      g.addEventListener('click', function () { openSub(g.classList.contains('is-open') ? null : g); });
    });
    document.addEventListener('click', function (e) { if (!mbar.contains(e.target)) openSub(homeGroup); });
    var mbRow = $('.mb-row', mbar), mbCur = $('.mb-row .is-cur', mbar);
    if (mbRow && mbCur) mbRow.scrollLeft = mbCur.offsetLeft - (mbRow.clientWidth - mbCur.offsetWidth) / 2;
    if (mbRow) mbRow.addEventListener('wheel', function (e) {
      if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
      var max = mbRow.scrollWidth - mbRow.clientWidth;
      if (max <= 0 || (e.deltaY < 0 && mbRow.scrollLeft <= 0) || (e.deltaY > 0 && mbRow.scrollLeft >= max - 1)) return;
      e.preventDefault();
      mbRow.scrollLeft += e.deltaY;
    }, { passive: false });
  }

  /* ---------------------------------------------------------
     5. 섹션 메뉴 (PC 오른쪽 + 빠른 이동 패널): 현재 섹션 표시, 누르면 이동
     --------------------------------------------------------- */
  var navLinks = $$('.pc-right a, .hd-menu-list a');
  var setNav = function (id) {
    navLinks.forEach(function (a) { a.classList.toggle('is-on', a.getAttribute('href') === '#' + id); });
  };
  if ('IntersectionObserver' in window) {
    var navIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) setNav(en.target.id);
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    navLinks.forEach(function (a) {
      var h = a.getAttribute('href') || '';
      if (h.charAt(0) !== '#') return;
      var sec = $(h);
      if (sec) navIO.observe(sec);
    });
  }
  navLinks.forEach(function (a) {
    a.addEventListener('click', function (e) {
      var behavior = reduce ? 'auto' : 'smooth';
      setMenu(false);
      // 00 현장명: 헤더까지 보이게 맨 위로
      if (a.hasAttribute('data-nav-top')) {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: behavior });
        return;
      }
      var h = a.getAttribute('href') || '';
      if (h.charAt(0) !== '#') return;
      var sec = $(h);
      if (!sec) return;
      e.preventDefault();
      sec.scrollIntoView({ behavior: behavior, block: 'start' });
    });
  });

  /* ---------------------------------------------------------
     5-1. 영상
        - 유튜브: 표지를 누르면 그 자리에서 재생. 주소는 www.youtube-nocookie.com 만 씀
          (유튜브 기본 임베드 주소는 사이트에서 막혀서 쓰지 않음, 비메오는 지원 안 됨)
        - 영상 파일 자동 재생(소리 없이 반복): 화면에 보일 때만 재생
     --------------------------------------------------------- */
  $$('.vbox--yt').forEach(function (box) {
    var id = box.getAttribute('data-yt'), btn = $('.vbox-play', box), img = btn && $('img', btn);
    if (!id || !btn) return;
    // 고화질 표지가 없는 영상은 회색 작은 그림(120px)이 와서 보통 화질로 바꿈
    var fallback = function () { if (img && !/hqdefault/.test(img.src)) img.src = 'https://img.youtube.com/vi/' + id + '/hqdefault.jpg'; };
    if (img) {
      img.addEventListener('error', fallback);
      img.addEventListener('load', function () { if (img.naturalWidth && img.naturalWidth <= 120) fallback(); });
      if (img.complete && img.naturalWidth && img.naturalWidth <= 120) fallback();
    }
    btn.addEventListener('click', function () {
      var f = document.createElement('iframe');
      f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?autoplay=1&rel=0&playsinline=1';
      f.title = btn.getAttribute('aria-label') || '영상';
      f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
      f.allowFullscreen = true;
      f.referrerPolicy = 'strict-origin-when-cross-origin';
      box.replaceChild(f, btn);
    });
  });
  var autoVids = $$('video[data-autoplay]');
  autoVids.forEach(function (v) {
    v.muted = true;
    if (reduce) { v.removeAttribute('autoplay'); v.pause(); v.controls = true; }   // 움직임 줄이기 설정이면 자동 재생 안 함
  });
  if (!reduce && autoVids.length && 'IntersectionObserver' in window) {
    var vio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var v = en.target;
        if (en.isIntersecting) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } else v.pause();
      });
    }, { threshold: 0.25 });
    autoVids.forEach(function (v) { vio.observe(v); });
  }

  /* ---------------------------------------------------------
     5-1. 방문예약 폼 제목·버튼 글자 고정: '방문예약' / '방문예약하기' (리드요 관리자에서 뭐라고 정했든)
     폼은 리드요가 나중에 넣고, 신청하는 동안 버튼 글자를 바꿨다 되돌리기도 해서 바뀔 때마다 다시 맞춤.
     신청 중(버튼이 눌리지 않는 상태)엔 리드요 글자를 그대로 둠
     --------------------------------------------------------- */
  var FORM_TITLE = '방문예약', FORM_BTN = '방문예약하기';
  $$('.reserve').forEach(function (host) {
    var fix = function () {
      $$('.lt-form__title', host).forEach(function (t) { if (t.textContent !== FORM_TITLE) t.textContent = FORM_TITLE; });
      $$('form [type=submit]', host).forEach(function (b) { if (!b.disabled && b.textContent.trim() !== FORM_BTN) b.textContent = FORM_BTN; });
    };
    fix();
    if ('MutationObserver' in window) new MutationObserver(fix).observe(host, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['disabled'] });
  });

  /* ---------------------------------------------------------
     5-2. 방문예약 폼 추가 항목 (에디터에서 만든 질문)
     폼은 리드요가 넣고, 우리는 그 폼 안에 질문만 끼워 넣음.
     답은 신청할 때 리드요 '문의 내용'(memo)에 "(질문: 답, …) 원래 문의" 로 담겨서 같이 접수됨
     (리드요 기본 추가 질문과 같은 방식). 문의 내용 칸이 없으면 숨은 칸을 하나 만들어서 보냄
     --------------------------------------------------------- */
  var lfHosts = $$('.reserve[data-fields]');
  if (lfHosts.length) {
    var lfMake = function (tag, cls, text) { var el = document.createElement(tag); if (cls) el.className = cls; if (text != null) el.textContent = text; return el; };
    var lfTop = function (box, el) { while (el && el.parentNode !== box) el = el.parentNode; return el || null; };
    var lfField = function (f, key) {
      var title = (f.label || '').trim() || '질문', wrap, ctl;
      var lab = lfMake('span', 'lt-field__label', title + (f.required ? ' *' : ''));
      if (f.type === 'single' || f.type === 'multi') {
        wrap = lfMake('fieldset', 'lt-question lt-choice lf-q lf-choice');
        var lg = lfMake('legend', 'lt-field__label', lab.textContent);
        var opts = lfMake('div', 'lt-choice__opts lf-opts'), boxes = [];
        wrap.appendChild(lg);
        (f.options || []).filter(function (o) { return String(o).trim(); }).forEach(function (o) {
          var ol = lfMake('label', 'lt-choice__opt lf-opt'), inp = document.createElement('input');
          inp.type = f.type === 'single' ? 'radio' : 'checkbox'; inp.name = key; inp.value = String(o).trim();
          if (f.required && f.type === 'single') inp.required = true;
          ol.appendChild(inp); ol.appendChild(lfMake('span', '', inp.value)); opts.appendChild(ol); boxes.push(inp);
        });
        wrap.appendChild(opts);
        if (f.required && f.type === 'multi' && boxes.length) {   // 복수선택 필수: 하나 이상 골라야 신청돼요
          var sync = function () { boxes[0].setCustomValidity(boxes.some(function (b) { return b.checked; }) ? '' : '하나 이상 골라 주세요'); };
          boxes.forEach(function (b) { b.addEventListener('change', sync); }); sync();
        }
      } else {
        wrap = lfMake('label', 'lf-q');
        wrap.appendChild(lab);
        if (f.type === 'select') {
          ctl = lfMake('select', 'lt-input');
          var o0 = lfMake('option', '', '선택해 주세요'); o0.value = ''; ctl.appendChild(o0);
          (f.options || []).filter(function (o) { return String(o).trim(); }).forEach(function (o) { var op = lfMake('option', '', String(o).trim()); op.value = String(o).trim(); ctl.appendChild(op); });
        } else if (f.type === 'long') {
          ctl = lfMake('textarea', 'lt-input lf-long'); ctl.rows = 3; ctl.maxLength = 300;
        } else {
          ctl = lfMake('input', 'lt-input'); ctl.type = 'text'; ctl.maxLength = 100;
        }
        if (f.required) ctl.required = true;
        if (f.placeholder && ctl.tagName !== 'SELECT') ctl.placeholder = f.placeholder;
        wrap.appendChild(ctl);
      }
      wrap.setAttribute('data-lf', title);
      wrap.setAttribute('data-lf-type', f.type || 'short');
      if (f.help) { var hp = lfMake('p', 'lt-form__hint lf-help', f.help); wrap.appendChild(hp); }
      return wrap;
    };
    var lfInject = function (host, form, fields, hideMemo, n) {
      var box = form.querySelector('.lt-form__fields') || form;
      var top = function (sel) { var el = form.querySelector(sel); return el ? lfTop(box, el) : null; };
      var phone = top('[name=phone]'), visit = top('[name=visit_time]') || top('[name=visit_date]');
      var memoEl = form.querySelector('[name=memo]'), memo = memoEl ? lfTop(box, memoEl) : null;
      var consent = top('[name=privacy_agreed]') || top('input[type=checkbox][required]'), submit = top('[type=submit]');   // 동의 줄 (클래스 이름은 안 씀)
      var before = { memo: memo || consent || submit, consent: consent || submit };
      var after = { phone: phone, visit: visit || phone };
      var place = function (el, pos) {
        var ref = before[pos];
        if (pos === 'phone' || pos === 'visit') {
          var a = after[pos];
          if (a) { box.insertBefore(el, a.nextSibling); after[pos] = el; if (pos === 'phone' && after.visit === phone) after.visit = el; return; }
          ref = before.memo;
        }
        if (ref && ref.parentNode === box) box.insertBefore(el, ref); else box.appendChild(el);
      };
      fields.forEach(function (f, k) { place(lfField(f, 'lfq_' + n + '_' + k), f.pos || 'memo'); });
      if (hideMemo && memo) memo.style.display = 'none';
      if (memoEl) {
        memoEl.__lfRaw = hideMemo ? '' : memoEl.value;
        memoEl.addEventListener('input', function () {   // 실패 뒤 다시 쓸 때 앞에 붙은 (질문: 답) 은 빼고 기억
          var v = memoEl.value, lp = memoEl.getAttribute('data-lt-memo-prefix');
          if (lp && v.indexOf(lp) === 0) v = v.slice(lp.length).replace(/^\s+/, '');
          if (memoEl.__lfPrefix && v.indexOf(memoEl.__lfPrefix) === 0) v = v.slice(memoEl.__lfPrefix.length).replace(/^\s+/, '');
          memoEl.__lfRaw = v;
        });
      }
      host.__lfForm = form;
    };
    var lfAll = function () {
      var left = 0;
      lfHosts.forEach(function (host, n) {
        if (host.__lfForm) return;
        var form = host.querySelector('form');
        if (!form) { left++; return; }
        var fields = [];
        try { fields = JSON.parse(host.getAttribute('data-fields')) || []; } catch (e) { fields = []; }
        lfInject(host, form, fields, host.hasAttribute('data-hide-memo'), n);
      });
      return left;
    };
    if (lfAll()) {   // 리드요 폼이 늦게 들어오는 경우 (미리보기 등)
      var lfMo = new MutationObserver(function () { if (!lfAll()) lfMo.disconnect(); });
      lfMo.observe(document.body, { childList: true, subtree: true });
      setTimeout(function () { lfMo.disconnect(); }, 15000);
    }
    // 신청 직전(리드요 전송보다 먼저): 추가 항목 답을 문의 내용 앞에 붙임
    document.addEventListener('submit', function (e) {
      var form = e.target, host = form && form.closest ? form.closest('.reserve[data-fields]') : null;
      if (!host || host.__lfForm !== form) return;
      var pairs = [];
      $$('[data-lf]', form).forEach(function (q) {
        var t = q.getAttribute('data-lf-type'), v = '';
        if (t === 'multi') v = $$('input:checked', q).map(function (x) { return x.value; }).join(' / ');
        else if (t === 'single') { var r = $('input:checked', q); v = r ? r.value : ''; }
        else { var c = $('input, textarea, select', q); v = c ? c.value : ''; }
        v = String(v || '').replace(/\s+/g, ' ').trim();
        if (v) pairs.push(q.getAttribute('data-lf') + ': ' + v);
      });
      var memo = form.querySelector('[name=memo]');
      if (!memo) {
        if (!pairs.length) return;
        memo = document.createElement('input'); memo.type = 'hidden'; memo.name = 'memo'; memo.__lfRaw = '';
        form.appendChild(memo);
      }
      var raw = memo.__lfRaw != null ? memo.__lfRaw : memo.value;
      var prefix = pairs.length ? '(' + pairs.join(', ') + ')' : '';
      memo.__lfPrefix = prefix;
      memo.value = (prefix + (prefix && raw ? ' ' : '') + raw).slice(0, 500);
    }, true);
  }

  /* ---------------------------------------------------------
     6. 인트로 → 페이지 시작
     --------------------------------------------------------- */
  var intro = $('#intro');
  var heroImg = $('.hero-bg img');
  var started = false;

  function startPage() {
    if (started) return;
    started = true;
    root.classList.add('is-ready');
    refreshViewers.forEach(function (f) { f(); });
  }

  if (root.classList.contains('is-intro')) {
    if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);

    // HOLD: 로고·현장명이 뜬 뒤 이동 시작 시점, FLY: 이동 시간 (CSS transition .5s와 같게)
    var HOLD = 550, FLY = 500, MAX = 2000;
    var t0 = Date.now(), ended = false;

    // 로고 → 헤더 로고, 현장명 → 히어로 타이틀 위치·크기로 이동 (인트로에 둘 중 하나만 있을 수도 있음)
    var introLogo = $('.intro-logo', intro), introName = $('.intro-name', intro);
    var headLogo = $('.hd-logo .logo'), heroTitle = $('.hero-title');
    var fly = function () {
      if (introLogo && headLogo) {
        var from = introLogo.getBoundingClientRect();
        var to = headLogo.getBoundingClientRect();
        var dx = (to.left + to.width / 2) - (from.left + from.width / 2);
        var dy = (to.top + to.height / 2) - (from.top + from.height / 2);
        introLogo.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(' + (to.width / from.width) + ')';
        root.classList.add('fly-logo');
      }
      // 현장명은 히어로 타이틀과 같은 크기로 만들어 두었으니 원래 크기(scale 1)로 키우면서 자리만 옮김
      if (introName && heroTitle) {
        var title = heroTitle.getBoundingClientRect();
        introName.style.transform = 'translate(' + (title.left - introName.offsetLeft) + 'px,' + (title.top - introName.offsetTop) + 'px) scale(1)';
        root.classList.add('fly-name');
      }
    };

    var endIntro = function () {
      if (ended) return;
      ended = true;
      root.classList.remove('is-intro');
      if (introName) root.classList.add('intro-done');   // 타이틀은 현장명이 날아와서 바꿔치기 → 페이드 없이
      intro.classList.add('is-out');
      void intro.offsetWidth;
      fly();
      setTimeout(startPage, 100);
      setTimeout(function () {
        root.classList.remove('fly-logo', 'fly-name');
        if (intro.parentNode) intro.parentNode.removeChild(intro);
      }, FLY + 50);
    };
    var whenHeroReady = function () { setTimeout(endIntro, Math.max(0, HOLD - (Date.now() - t0))); };
    if (heroImg.complete) whenHeroReady();
    else {
      heroImg.addEventListener('load', whenHeroReady, { once: true });
      heroImg.addEventListener('error', whenHeroReady, { once: true });
    }
    setTimeout(endIntro, MAX);          // 이미지가 늦어도 2초면 시작
    intro.addEventListener('click', endIntro);   // 탭하면 바로 건너뛰기
  } else {
    startPage();
  }
})();
