// E모델하우스(krpano VR) 장면 캡처 — 사내 서버에서만 (site-import.js 가 op 'vr' 일 때 부름, 설치할 것 없음)
//
// 이 컴퓨터의 크롬(없으면 엣지)을 화면 없이 띄워(--remote-debugging-pipe) VR 페이지를 열고, krpano 로 장면 목록을 읽어
// 타입별로 거실·주방·침실·욕실 장면을 골라 화살표·버튼을 숨기고 시야를 넓혀(fov 120) 1600×900 으로 찍음.
// Cloudflare 중계(마법도구)에는 브라우저가 없어서 안 됨 → 에디터가 '사내 서버에서만' 이라고 알려 줌.
//
// 요청: {"op":"vr", "url":"E모델하우스 주소(또는 VR이 iframe으로 들어간 페이지)", "form":"rule"|"slide", "maxTypes":3}
//   rule  = 타입 2~3개면 타입마다 거실·침실, 타입 1개면 거실·주방·침실·욕실 (팀 규칙)
//   slide = 타입마다 거실·주방·침실·욕실
// 답: {"url", "types":[{"name":"34A","label":"34㎡A","rooms":[{"room":"거실","title":"거실/침실-1","scene":"scene_01_01","img":"data:image/jpeg;base64,…"}]}], "scenes":[…]}
// 크롬 경로를 직접 정하려면 환경 변수 CHROME_PATH

const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const LA = process.env.LOCALAPPDATA || '', PF = process.env.ProgramFiles || 'C:\\Program Files', PF86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
const BROWSERS = [process.env.CHROME_PATH,
  path.join(PF, 'Google\\Chrome\\Application\\chrome.exe'), path.join(PF86, 'Google\\Chrome\\Application\\chrome.exe'), LA && path.join(LA, 'Google\\Chrome\\Application\\chrome.exe'),
  path.join(PF86, 'Microsoft\\Edge\\Application\\msedge.exe'), path.join(PF, 'Microsoft\\Edge\\Application\\msedge.exe'),
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge'];
function findBrowser() { return BROWSERS.filter(Boolean).find((p) => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }); }

// 브라우저 하나 띄우고 DevTools 명령 주고받기 (파이프: 메시지마다 끝에 \0)
function launch() {
  const exe = findBrowser();
  if (!exe) throw new Error('이 컴퓨터에서 크롬이나 엣지를 못 찾았어요 (E모델하우스 캡처에 필요해요)');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vrcap-'));
  const p = spawn(exe, ['--headless=new', '--remote-debugging-pipe', '--user-data-dir=' + dir, '--no-first-run', '--no-default-browser-check',
    '--mute-audio', '--hide-scrollbars', '--window-size=1600,900', '--enable-unsafe-swiftshader', 'about:blank'], { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'] });
  const toB = p.stdio[3], fromB = p.stdio[4], wait = new Map();
  let id = 0, buf = Buffer.alloc(0), dead = null;
  fromB.on('data', (d) => {
    buf = Buffer.concat([buf, d]);
    let i;
    while ((i = buf.indexOf(0)) >= 0) {
      const raw = buf.slice(0, i).toString('utf8'); buf = buf.slice(i + 1);
      let m; try { m = JSON.parse(raw); } catch (e) { continue; }
      if (m.id && wait.has(m.id)) { const w = wait.get(m.id); wait.delete(m.id); if (m.error) w.no(new Error(m.error.message)); else w.ok(m.result || {}); }
    }
  });
  const fail = (e) => { dead = e; wait.forEach((w) => w.no(e)); wait.clear(); };
  p.on('error', (e) => fail(new Error('브라우저를 못 띄웠어요: ' + e.message)));
  p.on('exit', () => fail(new Error('브라우저가 닫혔어요')));
  const send = (method, params, sessionId) => new Promise((ok, no) => {
    if (dead) return no(dead);
    const i = ++id; wait.set(i, { ok, no });
    toB.write(JSON.stringify({ id: i, method, params: params || {}, sessionId }) + '\0');
  });
  const close = () => { try { p.kill(); } catch (e) { /* 이미 꺼짐 */ } setTimeout(() => { try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* 나중에 지워짐 */ } }, 2000); };
  return { send, close };
}

/* ---------- 장면 → 타입·방 ---------- */
const ROOMS = [['거실', /거실|living/i], ['주방', /주방|식당|부엌|kitchen|dining/i], ['침실', /침실|안방|bed|master|room\s*\d|^room/i], ['욕실', /욕실|화장실|파우더|bath|toilet|powder/i]];
function roomOf(s) { const t = (s.title || '') + ' ' + s.name.replace(/^scene_?/i, ''); const r = ROOMS.find((x) => x[1].test(t)); return r ? r[0] : ''; }
function typeKey(s) {   // 평면 지도 그림 이름(34a.png) → 장면 이름(scene_84a_living) → 앞 번호 묶음(scene_01_03)
  const m1 = String(s.map || '').split('/').pop().match(/^(\d{2,3}[a-z]{0,2}\d?)\b/i); if (m1) return m1[1].toUpperCase();
  const m3 = s.name.match(/^scene_?(\d{1,2})_\d{1,3}$/i); if (m3) return '#' + (+m3[1]);   // 번호 묶음만 (scene_01_03)
  const m2 = s.name.match(/(?:^|_)(\d{2,3}[a-z]{1,2}\d?|\d{2,3})(?=_|$)/i); if (m2 && !/^0\d$/.test(m2[1])) return m2[1].toUpperCase();
  return '#1';
}
const label = (n) => /^\d{2,3}[A-Z]{0,2}\d?$/.test(n) ? n.replace(/^(\d{2,3})/, '$1㎡') : n;
function pickScenes(scenes, form, maxTypes, domTypes) {
  const groups = [];
  scenes.forEach((s) => { const k = typeKey(s); let g = groups.find((x) => x.key === k); if (!g) groups.push(g = { key: k, list: [] }); g.list.push(s); });
  // 번호 묶음뿐이면 VR 화면의 타입 이름(34㎡A타입 …)을 차례로
  groups.forEach((g, i) => {
    if (g.key[0] === '#') { const d = domTypes[i] ? domTypes[i].replace(/\s*타입$/, '').replace(/\s+/g, '') : ''; g.name = d.replace('㎡', '') || '타입' + (i + 1); g.label = d || g.name; }
    else { g.name = g.key; g.label = label(g.key); }
  });
  const use = groups.filter((g) => g.list.some((s) => roomOf(s))).slice(0, maxTypes || 3);
  const want = form === 'slide' || use.length === 1 ? ['거실', '주방', '침실', '욕실'] : ['거실', '침실'];
  return use.map((g) => {
    const used = new Set(), usedT = new Set(), rooms = [];
    // 같은 방이 여럿이면: 미니맵에 나오는 장면(menabled) 먼저 → 침실1·욕실1·-1 처럼 앞 번호 / 거실 겸 침실(원룸)은 거실 먼저, 침실엔 이름이 다른 장면
    const score = (s) => (s.menabled === 'false' ? 2 : 0) + (/[1１]|안방|master/i.test(s.title || s.name) ? 0 : 1);
    want.forEach((room) => {
      const cand = g.list.filter((s) => !used.has(s.name) && !(s.title && usedT.has(s.title)) && (roomOf(s) === room || (room === '침실' && /침실/.test(s.title || '') && roomOf(s) === '거실')));
      cand.sort((a, b) => score(a) - score(b));
      const s = cand[0]; if (!s) return;
      used.add(s.name); if (s.title) usedT.add(s.title); rooms.push({ room, title: s.title || '', scene: s.name });
    });
    return { name: g.name, label: g.label, rooms };
  }).filter((t) => t.rooms.length);
}

let busy = Promise.resolve();
async function capture(b, core) {
  const run = busy.then(() => captureOne(b, core));
  busy = run.catch(() => {});   // 한 번에 하나씩 (브라우저가 무거움)
  return run;
}
async function captureOne(b, core) {
  let url = String(b.url || '').trim();
  if (!/^https?:\/\//i.test(url)) throw new Error('E모델하우스 주소를 넣어 주세요');
  await core.grab(url, { accept: 'text/html,*/*', max: 65536, timeout: 12000 });   // 사내망 주소 막기(core 의 주소 검사) + 열리는지
  const B = launch();
  try {
    const { targetId } = await B.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await B.send('Target.attachToTarget', { targetId, flatten: true });
    const S = (m, p) => B.send(m, p, sessionId);
    const ev = async (x) => { const r = await S('Runtime.evaluate', { expression: x, returnByValue: true, awaitPromise: true }); return r.exceptionDetails ? null : (r.result || {}).value; };
    await S('Page.enable'); await S('Runtime.enable');
    await S('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false });
    const K = "(document.getElementById('krpanoSWFObject') || window.krpano || [...document.querySelectorAll('object,embed,div')].find(e => e.get && e.call) || null)";
    const ready = async (ms) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const n = await ev(`(() => { const k = ${K}; return k && k.get ? +k.get('scene.count') || 0 : 0; })()`); if (n > 0) return n; await sleep(600); } return 0; };
    await S('Page.navigate', { url });
    let n = await ready(15000);
    if (!n) {   // VR 이 iframe 안이면 그 주소로 (분양 홈페이지의 e모델하우스 메뉴 페이지)
      const fr = (await ev("[...document.querySelectorAll('iframe')].map(f => f.src).filter(u => /^https?:/.test(u))")) || [];
      for (const u of fr.slice(0, 3)) { await S('Page.navigate', { url: u }); n = await ready(15000); if (n) { url = u; break; } }
    }
    if (!n) throw new Error('이 주소에서 E모델하우스 VR(krpano)을 못 찾았어요');
    await sleep(2500);
    const scenes = (await ev(`(() => { const k = ${K}, n = +k.get('scene.count'), out = []; for (let i = 0; i < n; i++) out.push({ name: String(k.get('scene[' + i + '].name') || ''), title: String(k.get('scene[' + i + '].title') || ''), map: String(k.get('scene[' + i + '].map') || ''), menabled: String(k.get('scene[' + i + '].menabled') || '') }); return out; })()`)) || [];
    const domTypes = (await ev("[...document.querySelectorAll('a,button,li,span,div,p')].filter(e => e.children.length === 0 && /^\\s*\\d{2,3}\\s*(㎡|m²|m2)?\\s*[A-Z]{0,2}\\d?\\s*(타입|TYPE)?\\s*$/i.test(e.textContent) && /타입|type|㎡|m²/i.test(e.textContent)).map(e => e.textContent.trim()).filter((t, i, a) => a.indexOf(t) === i)")) || [];
    const types = pickScenes(scenes, b.form === 'slide' ? 'slide' : 'rule', Math.max(1, Math.min(+b.maxTypes || 3, 6)), domTypes);
    for (const t of types) {
      for (const r of t.rooms) {
        await ev(`(() => { const k = ${K}; k.call('loadscene(' + ${JSON.stringify(r.scene)} + ', null, MERGE, BLEND(0))'); return 1; })()`);
        await sleep(3000);
        await ev(`(() => { const k = ${K}; const fm = +k.get('view.fovmax') || 120; k.set('view.fov', Math.min(fm, 120)); const n = +k.get('hotspot.count'); for (let i = 0; i < n; i++) k.set('hotspot[' + i + '].visible', false); const m = +k.get('layer.count'); for (let i = 0; i < m; i++) k.set('layer[' + i + '].visible', false); return 1; })()`);
        await sleep(1500);
        const shot = await S('Page.captureScreenshot', { format: 'jpeg', quality: 88 });
        r.img = 'data:image/jpeg;base64,' + shot.data;
      }
    }
    return { url, types, scenes: scenes.map((s) => ({ name: s.name, title: s.title, type: typeKey(s), room: roomOf(s) })) };
  } finally { B.close(); }
}

module.exports = { capture, pickScenes, findBrowser };

// 따로 실행해서 확인: node vr-capture.js <E모델하우스 주소> [rule|slide] → vr-out 폴더에 사진
if (require.main === module) {
  const core = require('./site-import-core');
  const t0 = Date.now();
  capture({ url: process.argv[2], form: process.argv[3] || 'rule' }, core).then((r) => {
    fs.mkdirSync('vr-out', { recursive: true });
    r.types.forEach((t) => t.rooms.forEach((x) => { const f = path.join('vr-out', (t.name + '_' + x.room).replace(/[^\w가-힣㎡-]+/g, '_') + '.jpg'); fs.writeFileSync(f, Buffer.from(x.img.split(',')[1], 'base64')); console.log(t.label, x.room, x.title, x.scene, '→', f); }));
    console.log('장면', r.scenes.length, '·', ((Date.now() - t0) / 1000).toFixed(1) + '초');
  }).catch((e) => { console.error('실패:', e.message); process.exit(1); });
}
