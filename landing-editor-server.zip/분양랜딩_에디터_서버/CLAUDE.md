# 분양 랜딩 에디터 — Claude 작업 안내

핏톡 '마법도구'의 분양 랜딩 에디터. 분양 현장 이미지를 올리면 리드요에 올릴 모바일 분양 랜딩 사이트를 zip으로 만들어 준다.
사람용 개발 설명은 [README.md](README.md), 운영(관리자) 설명은 [docs/인수인계서_관리자.html](docs/인수인계서_관리자.html).

## 지금 운영 상태 (2026-10-26)

- 팀은 **마법도구 하나만** 쓴다: https://fittalk-qs.github.io/itzip/landing-editor.html = 이 저장소의 `public/index.html` (깃허브 itzip 저장소에 사람이 직접 올림)
- '공식 홈페이지에서 가져오기'는 **Cloudflare Worker 중계 서버**를 거친다: https://fittalk-landing-proxy.csad.workers.dev/ (무료 계정, Worker 이름 `fittalk-landing-proxy`). 에디터의 `<meta name="site-import-remote">`(src/editor.html)에 주소가 들어 있다.
- 사내 서버(`server.js`, `서버_시작.bat`)는 선택 사항이라 지금은 안 쓴다.
- 인계 사본: `\\FITTALKMAIN\공유 폴더\00_Fittalk\06_핏톡 마법도구 에디터`

## 꼭 지킬 것

- **`public/index.html`과 `cloudflare/worker.js`는 만든 결과물이다. 직접 고치지 않는다.** 원본을 고친 뒤 `npm run build`로 다시 만든다.
  - 에디터 화면 HTML·CSS → `src/editor.html`
  - 에디터 동작 → `src/editor.js` (HTML `<script>` 안에 그대로 들어감: 글자로 `</script>`가 필요하면 `'<\/script>'`)
  - 만들어지는 분양 사이트의 틀(zip 안 css/js/fonts) → `src/template/`
  - 홈페이지 읽는 핵심 → `site-import-core.js` (사내 서버와 Worker가 같이 씀) · Worker 입구 → `cloudflare/worker-main.js`
- 고친 다음엔 **`npm run build` → `npm test`**. 빌드가 문법 오류와 `</script` 섞임을 잡아 준다. 둘 다 통과해야 끝.
- `site-import-core.js`는 Node 전용 기능(Buffer, dns, fs …)을 쓰지 않는다. Cloudflare Worker에서도 돌아야 해서 `fetch`·`URL`·`TextDecoder`·`Uint8Array`만 쓴다.
- 에디터 코드(`src/editor.js`)는 `var` + `function` 스타일(일부 `async`)이다. 주석·화면 문구는 쉬운 한국어 해요체로 짧게 (기존 문구 톤을 따른다).
- **내보낸 사이트 HTML 구조(클래스·id·data 속성)를 바꾸면 `importZip()`도 같이 고친다.** 만든 zip을 다시 불러올 때 그 HTML을 읽어서 상태를 되살린다.
- 기능·운영이 바뀌면 문서도 같이: `docs/인수인계서_관리자.html`(관리자용), `README.md`(개발자용), `실행방법.txt`·`cloudflare/설정방법.txt`(사용자용).

## 명령

```bash
npm start            # 사내 서버 = 에디터를 http://localhost:8080/ 로 (확인용)
npm run build        # src/ → public/index.html + cloudflare/worker.js
npm test             # 홈페이지 가져오기 시험: 가짜 사이트 3종 (test/fixtures.js), 인터넷 없이 1초
npm run test:live    # 위 + 진짜 예시 사이트 sd.hndapt.co.kr
node site-import.js https://공식홈페이지/ --all   # 한 사이트에서 찾은 메뉴·이미지 보기
```

설치할 패키지 없음 (Node.js 18+ 만).

## 확인하는 법

- 에디터 변경은 `npm start` 후 http://localhost:8080/ 에서 직접 확인: 이미지 올리기 → 미리보기(모바일·PC 전환) → 내보내기 전 검사 → zip 만들기 → 그 zip 다시 불러오기.
- 실제 Worker를 거친 가져오기 확인: `http://localhost:8080/?siteimport=https://fittalk-landing-proxy.csad.workers.dev/api/site-scan` (Worker가 `http://localhost:8080`을 허락해 둠). `&siteurl=<홈페이지>`를 붙이면 가져오기 칸이 채워진다.
- 자동화용 훅: `window.__editor` (`state()`, `renderPage()`, `lastZip()`, `scan()` …).
- 새로운 홈페이지 구조를 지원하게 고칠 땐 `test/fixtures.js`에 그 구조를 흉내 낸 페이지를 넣고 `test/run.js`에 기대값을 더한다.

## 구조 메모

- 에디터 상태: `state.sections`(지금 고치는 페이지), `state.mainSections`(메인), `state.menus`(대메뉴 → `children` 소메뉴, 페이지마다 `sections`, `cw` 1200·860·375).
- 이미지 섹션 `images` = 기본(휴대폰) 이미지, `pcImages` = PC 넓은 화면용 이미지. 출력 `<section class="has-pc">` 안 `figure.m-only` / `figure.pc-only`. 예전 `mimages`(`has-mo`) zip도 읽는다.
- 가져오기 API는 단계별(op: `menu` → `page` → `finish` → `probe` → `check`, 이미지는 `GET site-img`). `text` = 페이지 글자 흐름·스타일 배경·많이 쓴 색·로고 후보 (메인 원페이지 자동 구성용, Worker가 예전 코드면 '모르는 요청' → 에디터는 이미지로만 만듦). Cloudflare 무료 한도(요청당 바깥 요청 50개·CPU 10ms) 때문에 나눠져 있다. 형식은 `site-import-core.js` 맨 위 주석.
- 자동 저장은 브라우저 IndexedDB(`bunyang-editor`), 되돌리기는 `freeze`/`thaw`.
- 대지(피그마처럼 편집)와 메인 원페이지 자동 구성도 `src/editor.js` 안에 있다. 자유 레이어 = `s.fl`·`state.heroFl`(칸 폭 비율). 자동 구성 섹션 = 단색 바탕 이미지(`s.auto = {bg, h}`, 860 기준) + 자유 레이어, 타입 슬라이드는 `s.autoTypes` 로 다시 그린다.
- PDF 자료 넣기(`src/pdf.js`, auto.js 끝 `/*__PDF_JS__*/` 자리에 들어감): pdf.js 3.11(jsdelivr, 처음 쓸 때 받음, 일꾼은 blob 주소로). 페이지 글자(자리 포함) + 그림 그리는 명령에서 PDF 안 그림 자리를 읽어 타입 카드(큰 글 '34㎡A' + 실수 + 전용·공용·공급·계약면적 + 평면 그림 + 작은 동 번호 묶음 = 키맵)를 나눔 → 'card' 타입 슬라이드. 섹션마다 [+ PDF] · 첫 화면 [PDF로 섹션 만들기] · 자동 구성 창 타입안내 [PDF에서 가져오기]. 두 쪽 펼침은 반씩.
- 인테리어(`s.autoInterior` = { form: 'rule'|'slide', src: 'vr'|'home'|'empty', url, items:[{type, label, room, im}] }): rule = 팀 03_interior_m 세로(탭 '84㎡A  |  거실' + 사진 760×400), slide = 제목 섹션 + 타입마다 슬라이드(방 2×2). E모델하우스 캡처는 서버 op 'vr' → `vr-capture.js`가 이 컴퓨터의 크롬·엣지를 `--remote-debugging-pipe`로 띄워 krpano 장면(scene.map·이름·제목으로 타입·방)을 찍음. 규칙: 타입 2~3개 = 거실·침실, 1개 = 거실·주방·침실·욕실. Cloudflare 중계엔 브라우저가 없어 안 됨(에디터가 빈 칸으로).
- 스톡 사진 40장: `src/template/stock/주제_설명_번호.jpg` → `build.js` 가 `window.TEMPLATE.stock` 으로 넣는다 (프리미엄 자동 사진·대지 '스톡에서 고르기'). 강아지 등 동물 사진은 넣지 않는다.
- 타입 슬라이드 모양 2가지(`s.autoTypeForm`): 'band' = 98_type_m(874) 위 메인 색 띠 + 평면도, 'card' = 98_type_m(2871) 왼쪽 메인 색 카드(이름 Gmarket 60·세대수 26·면적 줄 20, 줄 간격 52) + 오른쪽 키맵 + 아래 평면도 (`typeSlideCard`). 평면 데이터의 통 그림(평면도 + 키맵 + 특화 설명)이면 `planParts` 가 평면도·키맵을 잘라 'card' 로. 섹션 칸에서 바꿀 수 있음. 에디터 버전 = `EDITOR_VERSION`(배포마다 올림, 위쪽 제목 옆).
- 스크립트로 그리는 홈페이지(Vue 등, 예: prugio-riverfront.com) 10/27 저녁: 서버 `readMenu` 가 같은 사이트 스크립트에서 부르는 `.json` 목록을 모아(`scriptJsons` → 결과 `data`) 메뉴가 적으면 메뉴 JSON(`getMenu.json`: krName·url·subDepth)으로 메뉴를 만든다. op `units` = 평면 데이터 JSON(`getCyber.json`: typeID·typeInfo·contents[].contentImg, 그림은 data/cyber/타입/) → 타입·면적·세대수·평면 그림(에디터 `planCrop` 이 첫 평면도만 잘라 우리 타입 띠로). 글자 흐름: `<video poster>` = 히어로 후보(크고 내용 많은 것), 한 칸 안 `tit`/`txt` 인라인은 따로 읽음. SVG 그림 허용(로고 → PNG, 흰 로고는 뺌). 첫 화면에 없으면 프리미엄·사업개요·입지·커뮤니티 하위 페이지 글을 읽음(`commFromFlow` = 구역·도면·사진+설명·시설). `make-server-project.js` 의 고침 쌍 3번째 값 = 이미 들어갔는지 보는 표시.
- 자동 구성 10/27 (수작업 더샵 송도그란테르와 비교해 고침): 히어로 = 스타일 `::after` 배경도 보고 휴대폰용(max-width) 사진을 내용 많은 쪽으로 자름(`coverCropSmart`), 문구는 첫 줄. 프리미엄 = 영문 이름 없이 [설명→제목]이 번갈아 나오는 구역도(`premiumPairs`). 타입 = 평면 페이지 탭(84A …) 다음 그림을 짝지음(`typesFromTabs`), 세로 그림이면 그대로 슬라이드(`asis`). 사업개요 = 글로 된 표(`summaryRows`, 블록이 여럿이면 줄마다 '블록 : 값'). 커뮤니티 = 구역 그림이면 `zonePlan`(reflow.js)으로 회색 띠·도면·사진+설명 띠·아이콘 목록으로 다시 짬(글은 Tesseract kor+eng). 인테리어 = E모델하우스 사진(왼쪽 흰 글자 칸은 잘라냄) + 타입 탭(팀 03_interior_m). 단지배치 = '단지/동호수' 한 페이지면 파일 이름으로 나누고, 세로 동호수 표는 쪼개지 않음. 서버 글자 흐름: 글자마다 감싼 제목('모 두 가 …')을 붙여 읽고(빈 줄 자리 = 띄어쓰기), 스타일시트 12개까지 봄.
- 오토 레이아웃(규격 섹션 = `s.auto`, `s.auto.flow === false` 면 끔): 대지에서 레이어 키가 바뀌면(사진 세로·Ctrl 자르기, 글 줄 수·크기, 지우기) `flFlow` 가 아래 레이어를 간격 그대로 옮기고 감싼 상자·키 같은 사진도 늘리고 섹션 높이(`s.auto.h`)와 바탕 그림을 다시 만든다. 기준 = 바로 위 형제들의 가장 아래(두 칸이면 긴 쪽). zip 에는 `<section data-auto="{bg,h,…}">` 로 남고, 예전 zip 은 단색 바탕 + 레이어 3개 이상이면 규격 섹션으로 알아본다. 사진 자르기 = `L.crop` [왼쪽, 위, 폭](칸 폭 비율, 출력은 img 에 position:absolute). 왼쪽 목록은 섹션마다 ▸ 접기·펼치기(`trOpen`), 고른 것만 칠함(대지 모드는 `ab.sel` 하나로).
- 대지 고르기 규칙(피그마식, `src/editor.js` 대지 부분 `abStackAt`·`abPick`): 채우기 없는 사각형(테두리 상자)은 테두리 근처에서만 골라지고 안쪽은 아래 레이어, 잠근 레이어(`L.locked`)는 대지에서 안 골라짐, Ctrl+클릭 = 겹친 레이어 차례로, 오른쪽 클릭 메뉴 = 그 자리 레이어 목록. 레이어 값: `line`(선 도구), `ratio`(비율 잠금), 사진 `strokeW`/`stroke`(`.fl-stroke::after`)·`shadow`.
- 이벤트는 팀이 직접 디자인해서 넣으므로 자동 구성은 홈페이지 이벤트 이미지를 가져오지 않고, 이미 넣어 둔 이벤트 섹션은 지우지 않는다. 타입 슬라이드 면적 줄 = 템플릿 98_type_m(874) 그대로 Pretendard 20 (마지막 줄은 2개까지: 슬라이드 번호와 안 겹치게). 사업개요 아이콘 = 회색 #787878 선 + 연한 메인 색 포인트, 피그마 아이콘 칸 100 그대로.
- 홈페이지 PC 이미지 → 휴대폰용으로 다시 짜기(`reflowPlan`, 커뮤니티 도면·단지배치·동호수 배치도): 빈 줄·빈 칸으로 나눠서 위 제목 글·맨 아래 작은 안내·사진 밑 설명은 빼고, 도면은 여백을 잘라 화면 폭으로 키우고, 한 줄에 붙은 사진(색이 많은 비슷한 크기 덩어리 2개 이상)은 2칸으로. 프리미엄은 늘 우리 템플릿 카드: 글은 메인 화면 글자 → 없으면 홈페이지 프리미엄 그림을 칸별로 글자 읽기(`premiumOcr`) → 그래도 없으면 빈 칸 4개.
- 자동 구성 섹션 모양은 팀 피그마 '★ 랜딩페이지-2026_Q4 › 복사 템플릿' 그대로(04 프리미엄 카드·05 입지 지도+설명·06 커뮤니티 도면+아이콘 목록·07 배치도·98 타입 띠·99 사업개요 아이콘 카드·00 금색 배지). 아이콘은 `src/template/icons.json`(피그마 icon_… · 사업개요 줄 아이콘 → SVG), 배지 메달 바탕은 `src/template/medal.png`. 레이어 모서리는 배열 `[왼위, 오위, 오아래, 왼아래]`도 됨, 사각형 `fill:'none'`·`shadow`.
- 분양상담사 문안 → 분양안내(인트로): `copyIntro`(줄 고르기: 평면·입지·교통·커뮤니티·프리미엄·이벤트·연락처는 뺌) → `introBoxes`(첫 문장·조건·★·특장점·규모·마무리, 6개까지) → `introLayers`. 원문은 `s.autoCopy`. 글 레이어의 `**글자**` = 강조(굵게 + `L.em` 색, 출력 `<b>`).

## 배포 (사람이 하는 일 — 대신 하지 말고 안내만)

1. 마법도구: 새 `public/index.html`을 `landing-editor.html`로 이름 바꿔 깃허브 itzip 저장소에 올림.
2. 중계 서버: `site-import-core.js`나 `cloudflare/worker-main.js`가 바뀌었으면 새 `cloudflare/worker.js` 내용을 Cloudflare Worker → Edit code에 붙여 넣고 Deploy (계정 접근 필요).
3. 공유 폴더 06번 사본 갱신: 덮어쓰기 전에 공유 폴더 쪽에 다른 사람이 고친 파일이 없는지 먼저 확인한다.
