// ★ 이 파일은 make-worker.js 가 만든 거예요. 고칠 땐 ../site-import-core.js 나 worker-main.js 를 고치고 node make-worker.js
// Cloudflare Worker 화면(Edit code)에 이 파일 내용을 통째로 붙여 넣고 Deploy 하면 돼요. 방법은 설정방법.txt

// 공식 홈페이지 읽기 핵심 — 사내 서버(site-import.js)와 Cloudflare Worker(cloudflare/worker.js)가 똑같이 씀
//
// 둘 다에서 도는 것만 씀: fetch · URL · TextDecoder · Uint8Array (Buffer·dns 같은 Node 전용은 안 씀)
// ※ 이 파일을 고치면 cloudflare 폴더에서  node make-worker.js  로 worker.js 를 다시 만들어 Cloudflare에 다시 붙여 넣어야 해요.
//
// 에디터는 한 번에 다 읽지 않고 단계별로 부름 (Cloudflare 무료 요금제는 요청 한 번에 바깥 요청 50개·CPU 10ms까지라서)
//   POST …/api/site-scan  본문(JSON 글자, Content-Type: text/plain)
//     {"op":"menu","url":"https://공식홈페이지/"}
//        → {"site":{"url","title","phone"}, "menus":[{"name","url","children":[{"name","url"}]}],
//           "mo":{"url":모바일 사이트 주소|null,"byName":{"메뉴이름":"주소"}}, "pages":[{"url","name"}], "skipped":안 읽은 페이지 수}
//     {"op":"page","url":페이지 주소,"name":메뉴 이름,"mo":위의 mo}   → {"pc":[이미지…],"mo":[이미지…],"how":"class|ua|"} 또는 {"err"}
//     {"op":"finish","pages":{"<페이지 주소>":page 결과}}            → {"pages", "how", "samples":[파일명 규칙을 찔러 볼 이미지…]}
//        공통 장식(거의 모든 페이지에 나오는 이미지)을 빼고, mo가 pc와 같으면 비움(= 휴대폰에서도 PC 이미지)
//     {"op":"probe","url":샘플 이미지,"ref":홈페이지}                → {"k":규칙 번호(-1 = 없음),"name":규칙 이름}
//     {"op":"check","k":규칙 번호,"urls":[PC 이미지… 40개까지],"ref"} → {"found":[모바일 이미지 주소 또는 ""…]}
//     {"op":"text","url":페이지 주소}  → {"url", "flow":[본문 순서대로 {t:'s'구역|'x'글|'i'이미지 …}], "bgs":[{s:선택자,u:배경 이미지,m:media}], "colors":[[색,횟수]…], "logos":[로고 후보…]}
//        메인 원페이지 자동 구성용 (첫 화면 문구·프리미엄·커뮤니티 설명, 타입 면적, 첫 화면 배경, 로고)
//   GET  …/api/site-img?u=<이미지 주소>&ref=<홈페이지>   → 이미지를 대신 받아 줌
//
// 모바일 이미지 찾는 순서
//   1) 한 페이지 안에 PC용·모바일용이 따로 있음: class(pc / mo / m_img / pc_only / hide-mobile …), <picture> media, data-pc·data-mo 속성
//   2) 휴대폰으로 열면 다른 페이지(m.도메인 등)가 나옴 → 그 페이지 이미지
//   3) 둘 다 아니면 파일명 규칙을 찔러 봄: m_파일, 파일_m, m/파일, /pc/→/m/ … (화면 폭에 따라 JS로 바꿔 끼우는 사이트)

var SiteImportCore = (function () {
  'use strict';
  const UA_PC = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';
  const UA_MO = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1';
  const HTML_ACCEPT = 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8';
  const MAX_PAGES = 60;     // 한 번에 읽는 메뉴 페이지 수
  const CHECK_MAX = 40;     // check 한 번에 확인하는 이미지 수

  /* ---------- 주소 검사 · 받아 오기 ---------- */
  function privateIp(ip) {
    ip = String(ip || '').toLowerCase().replace(/^\[|\]$/g, '');
    const m = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(ip);
    if (m) {
      const a = +m[1], b = +m[2];
      return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 100 && b >= 64 && b < 128) ||
        (a === 169 && b === 254) || (a === 172 && b >= 16 && b < 32) || (a === 192 && b === 168);
    }
    if (ip.indexOf(':') < 0) return false;
    if (ip.startsWith('::ffff:')) return privateIp(ip.slice(7));
    return ip === '::' || ip === '::1' || /^f[cd]/.test(ip) || /^fe[89ab]/.test(ip);
  }
  // 기본 검사: http·https만, localhost·사내망 숫자 주소는 막음. 사내 서버는 DNS까지 보는 걸로 바꿔 끼움(setGuard)
  let guard = async (u) => {
    if (!/^https?:$/.test(u.protocol)) throw new Error('http·https 주소만 읽을 수 있어요');
    const h = u.hostname.toLowerCase();
    if (h === 'localhost' || /\.(localhost|local|internal|lan)$/.test(h) || privateIp(h)) throw new Error('사내망·내 컴퓨터 주소는 읽지 않아요');
  };
  const setGuard = (fn) => { guard = fn; };

  function timeoutSignal(ms) {
    if (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) return AbortSignal.timeout(ms);
    const c = new AbortController(), e = new Error('timeout');
    e.name = 'TimeoutError';
    setTimeout(() => c.abort(e), ms);
    return c.signal;
  }
  const drop = (res) => { if (res && res.body) res.body.cancel().catch(() => {}); };
  async function readMax(res, max) {
    if (+res.headers.get('content-length') > max) { drop(res); throw new Error('파일이 너무 커요'); }
    if (!res.body) return new Uint8Array(0);
    const reader = res.body.getReader(), chunks = [];
    let n = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      n += value.length;
      if (n > max) { reader.cancel().catch(() => {}); throw new Error('파일이 너무 커요'); }
      chunks.push(value);
    }
    const out = new Uint8Array(n);
    let o = 0;
    chunks.forEach((c) => { out.set(c, o); o += c.length; });
    return out;
  }
  // 주소가 넘어갈 때마다(리다이렉트) 다시 검사. o.head: 머리만 보고 끊음, o.stream: 본문은 안 읽고 res 그대로
  async function grab(url, o = {}) {
    let u = new URL(url);
    for (let hop = 0; hop < 6; hop++) {
      await guard(u);
      const headers = { 'User-Agent': o.ua || UA_PC, Accept: o.accept || '*/*', 'Accept-Language': 'ko-KR,ko;q=0.9,en;q=0.5' };
      if (o.referer) headers.Referer = o.referer;
      const res = await fetch(u.href, { redirect: 'manual', headers, signal: timeoutSignal(o.timeout || 15000) });
      const loc = res.headers.get('location');
      if (res.status >= 300 && res.status < 400 && loc) { drop(res); u = new URL(loc, u); continue; }
      const type = res.headers.get('content-type') || '';
      if (o.head) { drop(res); return { url: u.href, status: res.status, type }; }
      if (o.stream) return { url: u.href, status: res.status, type, res };
      return { url: u.href, status: res.status, type, buf: await readMax(res, o.max || 5 * 1048576) };
    }
    throw new Error('주소가 계속 다른 데로 넘어가요');
  }
  // 한국 사이트는 euc-kr 인 곳이 아직 있음
  function decodeHtml(bytes, type) {
    let cs = (/charset=["']?([\w-]+)/i.exec(type) || [])[1];
    if (!cs) {
      let head = '';
      for (let i = 0, n = Math.min(bytes.length, 4096); i < n; i++) head += String.fromCharCode(bytes[i]);
      cs = (/<meta[^>]+charset=["']?([\w-]+)/i.exec(head) || [])[1];
    }
    try { return new TextDecoder((cs || 'utf-8').toLowerCase()).decode(bytes); } catch (e) { return new TextDecoder('utf-8').decode(bytes); }
  }
  // 이미지 파일인지 앞부분으로 확인
  function sniff(b) {
    const s = (i, n) => String.fromCharCode.apply(null, b.subarray(i, i + n));
    if (b.length < 12) return '';
    if (b[0] === 0xff && b[1] === 0xd8) return 'image/jpeg';
    if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'image/png';
    if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return 'image/gif';
    if (s(0, 4) === 'RIFF' && s(8, 4) === 'WEBP') return 'image/webp';
    if (s(4, 4) === 'ftyp' && /avi[fs]/.test(s(8, 4))) return 'image/avif';
    if (b[0] === 0x42 && b[1] === 0x4d) return 'image/bmp';
    return '';
  }
  // 오류를 알아듣기 쉬운 말로
  function why(e) {
    const c = (e && (e.code || (e.cause && e.cause.code))) || '';
    if (c === 'ENOTFOUND' || c === 'EAI_AGAIN') return '주소를 찾을 수 없어요 (오타가 없는지 확인해 주세요)';
    if (e && (e.name === 'TimeoutError' || e.name === 'AbortError')) return '홈페이지가 응답하지 않아요';
    if (/fetch failed|network connection lost|dns/i.test(e && e.message)) return '홈페이지에 연결이 안 돼요' + (c ? ' (' + c + ')' : '');
    return (e && e.message) || String(e);
  }
  async function pool(list, n, fn) {
    const out = new Array(list.length);
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(n, list.length) }, async () => {
      while (next < list.length) { const i = next++; out[i] = await fn(list[i], i); }
    }));
    return out;
  }

  /* ---------- HTML 읽기 (설치 없이 쓰려고 만든 작은 파서. 틀린 HTML도 대충 읽음) ---------- */
  const VOID = new Set('area base br col embed hr img input link meta param source track wbr'.split(' '));
  const RAW = new Set(['script', 'style', 'textarea', 'title', 'noscript', 'xmp']);
  const AUTO_CLOSE = { li: ['ul', 'ol'], dt: ['dl'], dd: ['dl'], option: ['select', 'datalist'], tr: ['table'], td: ['tr', 'table'], th: ['tr', 'table'] };
  const SAME_GROUP = { li: ['li'], dt: ['dt', 'dd'], dd: ['dt', 'dd'], option: ['option'], tr: ['tr'], td: ['td', 'th'], th: ['td', 'th'] };
  const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', middot: '·', raquo: '»', laquo: '«', rsaquo: '›', lsaquo: '‹', hellip: '…', copy: '©' };
  const unent = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] !== '#') return ENT[e.toLowerCase()] != null ? ENT[e.toLowerCase()] : m;
    const n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1);
    return n > 0 && n < 0x110000 ? String.fromCodePoint(n) : m;
  });
  function attrs(s) {
    const a = {}, re = /([^\s"'<>\/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
    let m;
    while ((m = re.exec(s))) {
      const k = m[1].toLowerCase();
      if (!(k in a)) a[k] = unent(m[2] != null ? m[2] : m[3] != null ? m[3] : m[4] != null ? m[4] : '');
    }
    return a;
  }
  function parseHtml(s) {
    const root = { tag: '#root', a: {}, kids: [], up: null };
    let cur = root, last = 0, m;
    let gap = 0;   // 빈 줄(줄바꿈 두 번)·&nbsp; 만 있던 자리 → 다음 요소에 gap (글자마다 감싼 제목의 띄어쓰기, 자동 구성 글자 흐름용)
    const text = (t) => { if (t.trim()) { cur.kids.push({ tag: '#text', text: unent(t), kids: [], up: cur }); gap = 0; } else if ((t.match(/\n/g) || []).length >= 2 || /&nbsp;|\u00a0/.test(t)) gap = 1; };
    const close = (tag) => { for (let n = cur; n && n !== root; n = n.up) if (n.tag === tag) { cur = n.up; return; } };
    const re = /<!--[\s\S]*?-->|<![^>]*>|<\?[^>]*>|<\/([a-zA-Z][\w:-]*)[^>]*>|<([a-zA-Z][\w:-]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/g;
    while ((m = re.exec(s))) {
      if (m.index > last) text(s.slice(last, m.index));
      last = re.lastIndex;
      if (m[1]) { close(m[1].toLowerCase()); continue; }
      if (!m[2]) continue;   // 주석·doctype
      const tag = m[2].toLowerCase();
      if (AUTO_CLOSE[tag]) {   // <li> 앞의 안 닫힌 <li> 닫기 등
        for (let n = cur; n && n !== root && AUTO_CLOSE[tag].indexOf(n.tag) < 0; n = n.up) if (SAME_GROUP[tag].indexOf(n.tag) >= 0) { cur = n.up; break; }
      }
      const node = { tag, a: attrs(m[3]), kids: [], up: cur };
      if (gap) { node.gap = 1; gap = 0; }
      cur.kids.push(node);
      if (VOID.has(tag) || /\/\s*$/.test(m[3])) continue;
      if (RAW.has(tag)) {   // 스크립트·스타일 안쪽은 글자 그대로
        const endRe = new RegExp('</' + tag + '\\s*>', 'ig');
        endRe.lastIndex = last;
        const em = endRe.exec(s);
        node.raw = s.slice(last, em ? em.index : s.length);
        last = re.lastIndex = em ? endRe.lastIndex : s.length;
        continue;
      }
      cur = node;
    }
    if (last < s.length) text(s.slice(last));
    return root;
  }
  // fn이 false를 돌려주면 그 안쪽은 안 봄
  function walk(n, fn) { for (const k of n.kids) { if (k.tag[0] === '#') continue; if (fn(k) !== false && k.kids.length) walk(k, fn); } }
  const els = (n) => n.kids.filter((k) => k.tag[0] !== '#');
  function textOf(n) {
    let t = '';
    const go = (x) => { for (const k of x.kids) { if (k.tag === '#text') t += k.text + ' '; else if (k.tag === 'img' && k.a.alt) t += k.a.alt + ' '; else if (k.tag[0] !== '#') go(k); } };
    go(n);
    return t.replace(/\s+/g, ' ').trim();
  }
  const tokens = (n) => ((n.a.class || '') + ' ' + (n.a.id || '')).toLowerCase().split(/\s+/).filter(Boolean);
  const find = (n, pred) => { let hit = null; walk(n, (k) => { if (hit) return false; if (pred(k)) { hit = k; return false; } }); return hit; };

  /* ---------- 메뉴 찾기 ---------- */
  const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } };
  const FILE_LINK = /\.(pdf|hwp|hwpx|docx?|xlsx?|pptx?|zip|jpe?g|png|gif|webp|mp4)(?=$|[?#])/i;
  function pageLink(a, base, home) {
    const h = (a.a.href || '').trim();
    if (!h || /^(#|javascript:|tel:|mailto:|sms:|data:)/i.test(h)) return null;
    let u;
    try { u = new URL(h, base); } catch (e) { return null; }
    if (!/^https?:$/.test(u.protocol) || hostOf(u.href) !== hostOf(home) || FILE_LINK.test(u.pathname)) return null;
    u.hash = '';
    return u.href;
  }
  const sameDoc = (a, b) => a.replace(/\/(index\.(html?|php|asp|jsp))?$/i, '/') === b.replace(/\/(index\.(html?|php|asp|jsp))?$/i, '/');
  const nameOf = (s) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 30);

  // <li> 하나: 맨 앞 링크 = 대메뉴, 그 뒤 링크들 = 소메뉴
  function menuItem(li, base, home) {
    const links = [];
    walk(li, (n) => { if (n.tag === 'a') { links.push(n); return false; } });
    let name = '', url = null;
    const first = links[0];
    if (first && !find(li, (n) => (n.tag === 'ul' || n.tag === 'ol') && !!find(n, (x) => x === first))) { name = nameOf(textOf(first)); url = pageLink(first, base, home); links.shift(); }
    else { const t = find(li, (n) => n.tag !== 'ul' && n.tag !== 'ol' && n.kids.some((k) => k.tag === '#text')); name = nameOf(t ? t.kids.filter((k) => k.tag === '#text').map((k) => k.text).join(' ') : ''); }
    const children = [], seen = new Set();
    links.forEach((a) => {
      const cu = pageLink(a, base, home), cn = nameOf(textOf(a));
      if (cu && cn && !seen.has(cu) && !sameDoc(cu, home)) { seen.add(cu); children.push({ name: cn, url: cu }); }
    });
    if (!name || (!url && !children.length) || (url && sameDoc(url, home) && !children.length)) return null;
    return { name, url: url && !sameDoc(url, home) ? url : null, children };
  }
  function findMenu(doc, base, home) {
    let best = null;
    walk(doc, (n) => {
      if (n.tag !== 'ul' && n.tag !== 'ol') return;
      const lis = els(n).filter((k) => k.tag === 'li');
      if (lis.length < 2 || lis.length > 14) return;
      const items = lis.map((li) => menuItem(li, base, home)).filter(Boolean);
      if (items.length < 2) return;
      let score = items.reduce((t, p) => t + (p.url ? 1 : 0) + p.children.length + (p.children.length ? 2 : 0), 0);
      for (let up = n; up; up = up.up) {
        if (up.tag === 'footer' || tokens(up).some((t) => /^(footer|ft|foot)/.test(t))) { score -= 30; break; }
        if (up.tag === 'header' || up.tag === 'nav' || tokens(up).some((t) => /gnb|nav|menu|depth|header/.test(t))) { score += 6; break; }
      }
      if (!best || score > best.score) best = { score, items };
    });
    if (best && best.score >= 4) return best.items;
    // 목록 모양 메뉴가 없으면: 같은 사이트 링크를 한 줄로 (꼬리 부분 빼고)
    const out = [], seen = new Set();
    walk(doc, (n) => {
      if (n.tag === 'footer') return false;
      if (n.tag !== 'a') return;
      const u = pageLink(n, base, home), nm = nameOf(textOf(n));
      if (u && nm && !seen.has(u) && !sameDoc(u, home) && out.length < 30) { seen.add(u); out.push({ name: nm, url: u, children: [] }); }
      return false;
    });
    return out;
  }

  /* ---------- 페이지 안 이미지 ---------- */
  // 머리·꼬리·메뉴·팝업·서브 상단 비주얼 같은 공통 부분은 안 봄
  const SKIP_TAGS = new Set(['head', 'header', 'footer', 'nav', 'script', 'style', 'noscript', 'template', 'svg', 'iframe', 'button', 'select', 'video', 'audio', 'object']);
  const CHROME = /^(header|footer|hd|ft|gnb|lnb|snb|nav|navi|navigation|menu|menus|allmenu|all[-_]?menu.*|full[-_]?menu.*|site[-_]?map|sitemap|.*[-_]gnb|gnb[-_].*|header[-_].*|footer[-_].*|top[-_]?btn|btn[-_]?top|go[-_]?top|quick.*|.*popup.*|pop|pop[-_].*|.*[-_]pop|layer[-_]?pop.*|modal.*|floating.*|fixed[-_].*|sub[-_]?visual.*|sub[-_]?top|s[-_]?menu|sub[-_]?menu.*|lnb[-_].*|snb[-_].*|breadcrumb.*|tab[-_]?menu.*|copyright|side[-_]?(menu|bar|nav).*|util.*|sns.*|bottom[-_]?(bar|menu|fix|btn).*|m[-_]?menu.*|mo[-_]?menu.*|mobile[-_]?menu.*|loading|loader|intro[-_]?pop.*)$/;
  // PC에서만 / 모바일에서만 보이는 표시 (class·id 낱말)
  const PC_TOK = /^(?:(?:pc|web|desktop)(?:[-_]?(?:only|img|image|ver|view|show|block|area|wrap|box|con|cont|visual|bg|pic|in))?|(?:only|show|view|img|for)[-_]?(?:pc|web|desktop)|(?:hide|hidden|no)[-_]?(?:m|mo|mob|mobile|sp)|(?:m|mo|mob|mobile|sp)[-_]?(?:hide|hidden|none|no)|hidden-(?:xs|sm)|visible-(?:md|lg|xl)|d-(?:md|lg|xl)-(?:block|flex|inline|inline-block|grid))$/;
  const MO_TOK = /^(?:(?:m|mo|mob|mobile|sp)(?:[-_]?(?:only|img|image|ver|view|show|block|area|wrap|box|con|cont|visual|bg|pic|in))?|(?:only|show|view|img|for)[-_]?(?:m|mo|mob|mobile|sp)|(?:hide|hidden|no)[-_]?(?:pc|web|desktop)|(?:pc|web|desktop)[-_]?(?:hide|hidden|none|no)|visible-(?:xs|sm)|hidden-(?:md|lg|xl)|d-(?:md|lg|xl)-none|(?:md|lg|xl):hidden)$/;
  function devOf(n) {
    for (let x = n; x && x.tag !== '#root'; x = x.up) {
      const t = tokens(x);
      if (t.some((v) => PC_TOK.test(v)) || (t.indexOf('hidden') >= 0 && t.some((v) => /^(md|lg|xl):(block|flex|inline|inline-block|grid)$/.test(v)))) return 'pc';
      if (t.some((v) => MO_TOK.test(v))) return 'mo';
    }
    return 'both';
  }
  const NOT_IMG = /\.(svg|ico|cur)(?=$|[?#])/i;
  const IMG_EXT = /\.(jpe?g|png|webp|gif|avif|bmp)(?=$|[?#])/i;
  const looksImg = (v) => !!v && !/^\s*(data:|javascript:|#)/i.test(v) && !NOT_IMG.test(v);
  const JUNK_WORD = new Set('logo ico icon icons btn button arrow bullet blank spacer close sns kakao kakaotalk naver facebook fb insta instagram youtube blog quick gnb loading loader spinner favicon'.split(' '));
  function junkName(u) {
    let f = u;
    try { f = decodeURIComponent(new URL(u).pathname.split('/').pop()); } catch (e) { /* 그대로 */ }
    return f.toLowerCase().replace(/\.[a-z0-9]+$/, '').split(/[^a-z]+/).some((w) => JUNK_WORD.has(w));
  }
  function bestSrcset(v) {
    let best = '', bw = -1;
    String(v || '').split(',').forEach((part) => {
      const [u, d] = part.trim().split(/\s+/);
      const w = parseFloat(d) || 1;
      if (u && looksImg(u) && w > bw) { best = u; bw = w; }
    });
    return best;
  }
  const LAZY = ['data-src', 'data-original', 'data-lazy-src', 'data-lazy', 'data-echo', 'data-url', 'data-img', 'data-image', 'data-full', 'data-zoom-image'];
  function srcOf(n) {
    for (const k of LAZY) if (looksImg(n.a[k])) return n.a[k];
    const ss = bestSrcset(n.a['data-srcset'] || n.a.srcset);
    if (ss) return ss;
    const s = n.a.src || '';
    return looksImg(s) && !/blank|spacer|placeholder|transparent|loading|1x1/i.test(s) ? s : '';
  }
  // data-pc / data-mo / data-src-m / data-mobile-src … 처럼 속성에 따로 적어 둔 PC·모바일 이미지
  function altSrcs(n) {
    let pc = '', mo = '';
    Object.keys(n.a).forEach((k) => {
      if (k.indexOf('data-') || LAZY.indexOf(k) >= 0 || !looksImg(n.a[k]) || !IMG_EXT.test(n.a[k])) return;
      const parts = k.slice(5).split(/[-_]/);
      if (parts.some((p) => /^(m|mo|mob|mobile|sp|msrc|mosrc|mobilesrc|msrcset)$/.test(p))) mo = mo || n.a[k];
      else if (parts.some((p) => /^(pc|web|desktop|pcsrc)$/.test(p))) pc = pc || n.a[k];
    });
    return { pc, mo };
  }
  function pageImages(doc, base) {
    const recs = [];
    const abs = (v) => { try { return new URL(v.trim(), base).href; } catch (e) { return ''; } };
    const add = (pc, mo) => {
      pc = pc ? abs(pc) : ''; mo = mo ? abs(mo) : '';
      if (pc && junkName(pc)) pc = '';
      if (mo && junkName(mo)) mo = '';
      if (pc || mo) recs.push({ pc, mo });
    };
    walk(doc, (n) => {
      if (SKIP_TAGS.has(n.tag) || tokens(n).some((t) => CHROME.test(t))) return false;
      if (n.tag === 'picture') {
        let pc = '', mo = '', plain = '';
        els(n).forEach((s) => {
          if (s.tag !== 'source') return;
          const v = bestSrcset(s.a.srcset || s.a['data-srcset']);
          if (!v) return;
          const media = String(s.a.media || '').toLowerCase(), mx = /max-width\s*:\s*(\d+)/.exec(media), mn = /min-width\s*:\s*(\d+)/.exec(media);
          if (mx && +mx[1] <= 1280) mo = mo || v; else if (mn) pc = pc || v; else plain = plain || v;
        });
        const img = find(n, (x) => x.tag === 'img'), is = img ? srcOf(img) : '';
        const fb = is || plain;
        if (mo && !pc) pc = fb; else if (pc && !mo) mo = fb; else if (!pc && !mo) pc = mo = fb;
        const d = devOf(n);
        add(d === 'mo' ? '' : pc, d === 'pc' ? '' : mo);
        return false;
      }
      if (n.tag !== 'img') return;
      const w = parseInt(n.a.width, 10), h = parseInt(n.a.height, 10);
      if ((w && w <= 40) || (h && h <= 40)) return;
      let s = srcOf(n);
      const a = n.up && n.up.tag === 'a' && IMG_EXT.test(n.up.a.href || '') && !NOT_IMG.test(n.up.a.href) ? n.up.a.href : '';
      if (a) s = a;   // 눌러서 크게 보는 이미지면 큰 쪽
      const alt = altSrcs(n), d = devOf(n);
      let pc = alt.pc || s, mo = alt.mo || s;
      if (d === 'pc') mo = alt.mo || '';
      if (d === 'mo') pc = alt.pc || '';
      add(pc, mo);
    });
    return recs;
  }
  const uniq = (list) => list.filter((v, i) => v && list.indexOf(v) === i);
  const listsOf = (recs) => ({ pc: uniq(recs.map((r) => r.pc)), mo: uniq(recs.map((r) => r.mo)) });
  const same = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
  const strs = (v, n) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string' && x.length < 2048).slice(0, n || 300) : []);

  /* ---------- 파일명 규칙으로 모바일 이미지 찾기 (화면 폭 보고 JS로 바꿔 끼우는 사이트) ---------- */
  const split = (u) => { const p = u.pathname, i = p.lastIndexOf('/') + 1, f = p.slice(i), dot = f.lastIndexOf('.'); return { dir: p.slice(0, i), base: dot > 0 ? f.slice(0, dot) : f, ext: dot > 0 ? f.slice(dot) : '' }; };
  const PATTERNS = [
    ['파일명 앞에 m_', (f) => f.dir + 'm_' + f.base + f.ext],
    ['파일명 앞에 mo_', (f) => f.dir + 'mo_' + f.base + f.ext],
    ['파일명 앞에 m-', (f) => f.dir + 'm-' + f.base + f.ext],
    ['파일명 뒤에 _m', (f) => f.dir + f.base + '_m' + f.ext],
    ['파일명 뒤에 _mo', (f) => f.dir + f.base + '_mo' + f.ext],
    ['파일명 뒤에 -m', (f) => f.dir + f.base + '-m' + f.ext],
    ['파일명 뒤에 _mobile', (f) => f.dir + f.base + '_mobile' + f.ext],
    ['m 폴더', (f) => f.dir + 'm/' + f.base + f.ext],
    ['mo 폴더', (f) => f.dir + 'mo/' + f.base + f.ext],
    ['mobile 폴더', (f) => f.dir + 'mobile/' + f.base + f.ext],
    ['pc 폴더 → m 폴더', (f, p) => /\/pc\//i.test(p) ? p.replace(/\/pc\//i, '/m/') : ''],
    ['pc 폴더 → mo 폴더', (f, p) => /\/pc\//i.test(p) ? p.replace(/\/pc\//i, '/mo/') : ''],
    ['pc 폴더 → mobile 폴더', (f, p) => /\/pc\//i.test(p) ? p.replace(/\/pc\//i, '/mobile/') : ''],
    ['파일명 _pc → _m', (f) => /[-_]pc$/i.test(f.base) ? f.dir + f.base.replace(/([-_])pc$/i, '$1m') + f.ext : ''],
    ['파일명 _pc → _mo', (f) => /[-_]pc$/i.test(f.base) ? f.dir + f.base.replace(/([-_])pc$/i, '$1mo') + f.ext : ''],
    ['파일명 pc_ → m_', (f) => /^pc[-_]/i.test(f.base) ? f.dir + f.base.replace(/^pc([-_])/i, 'm$1') + f.ext : ''],
    ['파일명 pc_ → mo_', (f) => /^pc[-_]/i.test(f.base) ? f.dir + f.base.replace(/^pc([-_])/i, 'mo$1') + f.ext : '']
  ];
  function candidate(k, url) {
    try {
      const u = new URL(url), path = PATTERNS[k][1](split(u), u.pathname);
      if (!path || path === u.pathname) return '';
      u.pathname = path;
      return u.href;
    } catch (e) { return ''; }
  }
  async function isImage(url, referer) {
    try {
      const r = await grab(url, { head: true, referer, timeout: 8000, accept: 'image/*' });
      return r.status >= 200 && r.status < 300 && /^image\//i.test(r.type);
    } catch (e) { return false; }
  }

  /* ---------- 단계별로 읽기 ---------- */
  async function loadDoc(url, ua) { return docOf(await grab(url, { ua, accept: HTML_ACCEPT })); }
  function docOf(r) {
    if (r.status >= 400) throw new Error('HTTP ' + r.status);
    if (r.type && !/html|xml/i.test(r.type)) throw new Error('웹페이지가 아니에요 (' + r.type.split(';')[0] + ')');
    const doc = parseHtml(decodeHtml(r.buf, r.type));
    let base = r.url;
    const b = find(doc, (n) => n.tag === 'base' && !!n.a.href);
    if (b) { try { base = new URL(b.a.href, r.url).href; } catch (e) { /* 그대로 */ } }
    return { url: r.url, doc, base };
  }
  function siteInfo(doc) {
    const meta = (k) => { const n = find(doc, (x) => x.tag === 'meta' && (x.a.property === k || x.a.name === k)); return n ? String(n.a.content || '').trim() : ''; };
    const t = find(doc, (n) => n.tag === 'title');
    // '메인 | 단지명' 같은 제목에서 '메인'·'공식 홈페이지' 같은 말은 건너뜀
    const parts = (meta('og:site_name') || meta('og:title') || (t ? unent(t.raw || '').trim() : '')).split(/\s+[|\-–—:]\s+/).map((v) => v.trim()).filter(Boolean);
    const title = parts.find((v) => !/^(메인|홈|main|home|index|welcome|공식\s*홈페이지|홈페이지|분양\s*홈페이지)$/i.test(v)) || parts[0] || '';
    const tel = find(doc, (n) => n.tag === 'a' && /^tel:/i.test(n.a.href || ''));
    const phone = tel ? (textOf(tel).match(/\d{2,4}-\d{3,4}(-\d{4})?/) || [tel.a.href.replace(/^tel:/i, '')])[0] : '';
    return { title: title.slice(0, 40), phone };
  }

  // 1) 첫 화면: 메뉴 구조 + 휴대폰이면 다른 사이트로 가는지
  async function readMenu(input) {
    let url = String(input || '').trim();
    if (!url) throw new Error('홈페이지 주소를 넣어 주세요');
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url.replace(/^\/+/, '');
    const home = await loadDoc(url, UA_PC);
    const site = Object.assign({ url: home.url }, siteInfo(home.doc));
    let menus = findMenu(home.doc, home.base, home.url);
    const mo = { url: null, byName: {} };
    // 휴대폰 첫 화면은 주소만 먼저 보고, 다른 사이트(m.도메인 등)거나 PC에서 메뉴를 못 찾았을 때만 읽음 (CPU 아끼려고)
    const mr = await grab(home.url, { ua: UA_MO, accept: HTML_ACCEPT }).catch(() => null);
    const other = mr && mr.status < 400 && hostOf(mr.url) !== hostOf(home.url);
    if (mr && mr.status < 400 && (other || !menus.length)) {
      let md = null;
      try { md = docOf(mr); } catch (e) { md = null; }
      if (md) {
        const mm = findMenu(md.doc, md.base, md.url);
        if (other) { mo.url = md.url; mm.forEach((m) => [m].concat(m.children).forEach((x) => { if (x.url) mo.byName[x.name.replace(/\s/g, '')] = x.url; })); }
        if (!menus.length) menus = mm;
      }
    }
    if (!menus.length) throw new Error('메뉴를 못 찾았어요. 메뉴가 그림이나 스크립트로만 된 사이트일 수 있어요');
    const list = [];
    menus.forEach((m) => (m.children.length ? m.children : [m]).forEach((p) => { if (p.url && !list.some((x) => x.url === p.url)) list.push({ url: p.url, name: p.name }); }));
    return { site, menus, mo, pages: list.slice(0, MAX_PAGES), skipped: Math.max(0, list.length - MAX_PAGES) };
  }
  // 2) 페이지 하나: PC로 열었을 때와 휴대폰으로 열었을 때 이미지
  async function readOnePage(url, name, mo) {
    try {
      const pc = await loadDoc(url, UA_PC);
      let md = await loadDoc(url, UA_MO).catch(() => null);
      if (md && mo && typeof mo.url === 'string' && sameDoc(md.url, mo.url)) {   // 모바일 사이트 첫 화면으로 튕김 → 메뉴 이름으로 찾기
        const alt = mo.byName && mo.byName[String(name || '').replace(/\s/g, '')];
        md = typeof alt === 'string' ? await loadDoc(alt, UA_MO).catch(() => null) : null;
      }
      const a = listsOf(pageImages(pc.doc, pc.base));
      let how = same(a.pc, a.mo) ? '' : 'class';
      if (md) {
        const b = listsOf(pageImages(md.doc, md.base));
        if (b.mo.length && !same(b.mo, a.mo)) { a.mo = b.mo; how = 'ua'; }
      }
      return { pc: a.pc, mo: a.mo, how };
    } catch (e) { return { pc: [], mo: [], err: why(e) }; }
  }
  // 3) 다 모아서: 공통 장식 빼기, 같은 건 비우기, 모바일을 못 찾았으면 규칙 찔러 볼 샘플
  function finishPages(input) {
    const pages = {};
    Object.keys(input || {}).slice(0, MAX_PAGES + 20).forEach((u) => {
      const P = input[u] || {};
      pages[u] = { pc: strs(P.pc), mo: strs(P.mo), how: typeof P.how === 'string' ? P.how : '' };
      if (typeof P.err === 'string') pages[u].err = P.err;
    });
    const urls = Object.keys(pages), cnt = new Map();
    urls.forEach((u) => new Set(pages[u].pc.concat(pages[u].mo)).forEach((v) => cnt.set(v, (cnt.get(v) || 0) + 1)));
    const lim = Math.max(3, Math.ceil(urls.length * 0.5));
    if (urls.length >= 4) urls.forEach((u) => { const P = pages[u]; P.pc = P.pc.filter((v) => cnt.get(v) < lim); P.mo = P.mo.filter((v) => cnt.get(v) < lim); });
    urls.forEach((u) => {
      const P = pages[u];
      if (!P.pc.length) { P.pc = P.mo; P.mo = []; }
      if (same(P.pc, P.mo)) P.mo = [];
    });
    const found = (k) => urls.some((u) => pages[u].how === k && pages[u].mo.length);
    const how = [found('class') ? '페이지 안에 PC용·모바일용 이미지가 따로 있어요' : '', found('ua') ? '휴대폰으로 열면 나오는 모바일 페이지에서 찾았어요' : ''].filter(Boolean).join(' · ');
    urls.forEach((u) => { delete pages[u].how; });
    const samples = how ? [] : uniq(urls.map((u) => pages[u].pc[0]).concat(urls.map((u) => pages[u].pc[1]))).slice(0, 6);
    return { pages, how, samples };
  }
  // 4) 샘플 이미지 하나에 파일명 규칙을 전부 찔러 봄 (요청 17개)
  async function probeSample(sample, ref) {
    const hits = await pool(PATTERNS.map((p, k) => k), 6, async (k) => { const c = candidate(k, sample); return !!c && (await isImage(c, ref)); });
    const k = hits.indexOf(true);
    return { k, name: k >= 0 ? PATTERNS[k][0] : '' };
  }
  // 5) 찾은 규칙으로 이미지마다 모바일 짝이 있는지 (요청 이미지 수만큼)
  async function checkPattern(k, urls, ref) {
    k = +k;
    if (!(k >= 0 && k < PATTERNS.length)) throw new Error('규칙 번호가 이상해요');
    return pool(strs(urls, CHECK_MAX), 6, async (v) => { const c = candidate(k, v); return c && (await isImage(c, ref)) ? c : ''; });
  }
  /* ---------- 글자 흐름 (메인 원페이지 자동 구성용) ---------- */
  // 본문을 위에서부터: {t:'s', id, c} 구역 시작 · {t:'x', v:글(줄바꿈 \n), g:감싼 태그, c:class, h:1 굵은 글} · {t:'i', v:이미지 주소, a:alt, bg:1 배경}
  const INLINE = new Set('a abbr b bdi bdo br cite code data dfn em font i kbd mark q s samp small span strong sub sup time u var wbr label'.split(' '));
  const BOLDISH = new Set(['strong', 'b', 'em']);
  const FLOW_MAX = 1500;
  function textFlow(doc, base) {
    const out = [];
    const abs = (v) => { try { return new URL(String(v).trim(), base).href; } catch (e) { return ''; } };
    const skip = (n) => SKIP_TAGS.has(n.tag) || tokens(n).some((t) => CHROME.test(t));
    const push = (o) => { if (out.length < FLOW_MAX) out.push(o); };
    const bgOf = (n) => { const m = /url\(\s*['"]?([^'")]+)['"]?\s*\)/i.exec(n.a.style || ''); return m && IMG_EXT.test(m[1]) ? abs(m[1]) : ''; };
    const visit = (n) => {
      if (skip(n)) return;
      if (n.tag === 'img') { const s = srcOf(n), u = s ? abs(s) : ''; if (u && !junkName(u)) push({ t: 'i', v: u, a: String(n.a.alt || '').slice(0, 80) }); return; }
      if (n.tag === 'section' || n.tag === 'article' || /^(section|sec|cont|content)[-_]?[a-z]*\d*$/i.test(n.a.id || '')) push({ t: 's', id: String(n.a.id || '').slice(0, 40), c: String(n.a.class || '').slice(0, 60) });
      const bg = bgOf(n);
      if (bg && !junkName(bg)) push({ t: 'i', v: bg, bg: 1 });
      let run = '', bold = 0;
      const flush = () => {
        let v = run;
        const parts = v.split(/([\u0001\u0002\u0003])/), toks = parts.filter((p) => !/^[\u0001\u0002\u0003]$/.test(p)).map((p) => p.replace(/\s+/g, '')).filter(Boolean);
        if (toks.length >= 6 && toks.filter((p) => p.length === 1).length / toks.length >= 0.8) {   // 글자마다 감싼 제목: 붙이고 띄어쓰기 자리만 띄움
          let o = '', sp = false;
          parts.forEach((p) => {
            if (p === '\u0002') sp = true;
            else if (p === '\u0003') { o += '\n'; sp = false; }
            else if (p !== '\u0001') { const q = p.replace(/\s+/g, ''); if (q) { if (sp && o && !/\n$/.test(o)) o += ' '; o += q; sp = false; } }
          });
          v = o;
        } else v = v.replace(/[\u0001\u0002]/g, ' ').replace(/\u0003/g, '\n');
        v = v.replace(/[ \t\f\r ]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{2,}/g, '\n').trim();
        if (v) push({ t: 'x', v: v.slice(0, 400), g: n.tag, c: String(n.a.class || '').slice(0, 60), h: bold });
        run = ''; bold = 0;
      };
      const inl = (k) => {
        for (const c of k.kids) {
          if (c.gap) run += '\u0002';
          if (c.tag === '#text') run += c.text;
          else if (c.tag === 'br') run += '\u0003';
          else if (c.tag[0] === '#') continue;
          else if (INLINE.has(c.tag) && !skip(c)) { if (BOLDISH.has(c.tag)) bold = 1; inl(c); run += /spac/i.test(c.a.class || '') ? '\u0002' : '\u0001'; }
          else { flush(); visit(c); }
        }
      };
      inl(n);
      flush();
    };
    visit(find(doc, (n) => n.tag === 'body') || doc);
    return out;
  }
  // 스타일(<style> + 같은 사이트 스타일시트 6개까지)에서 배경 이미지와 많이 쓴 색
  async function cssInfo(doc, base) {
    const bgs = [], colors = new Map(), links = [];
    const scan = (css, from) => {
      css = css.replace(/\/\*[\s\S]*?\*\//g, '');
      (css.match(/#[0-9a-f]{6}\b|#[0-9a-f]{3}\b/gi) || []).forEach((c) => {
        c = c.toLowerCase(); if (c.length === 4) c = '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3];
        colors.set(c, (colors.get(c) || 0) + 1);
      });
      const rule = (sel, decl, media) => {
        const u = /url\(\s*['"]?([^'")]+?)['"]?\s*\)/i.exec(decl);
        if (!u || /^data:/i.test(u[1]) || !IMG_EXT.test(u[1]) || bgs.length >= 300) return;
        let href = ''; try { href = new URL(u[1], from).href; } catch (e) { return; }
        if (!junkName(href)) bgs.push({ s: sel.trim().replace(/\s+/g, ' ').slice(0, 120), u: href, m: media.slice(0, 80) });
      };
      const re = /@media([^{]+)\{((?:[^{}]*\{[^{}]*\})*[^{}]*)\}|([^{}@]+)\{([^{}]*)\}/g;
      let m;
      while ((m = re.exec(css))) {
        if (m[1]) { const r2 = /([^{}]+)\{([^{}]*)\}/g; let k; while ((k = r2.exec(m[2]))) rule(k[1], k[2], m[1].trim()); }
        else rule(m[3], m[4], '');
      }
    };
    walk(doc, (n) => {
      if (n.tag === 'style' && n.raw) scan(n.raw, base);
      if (n.tag === 'link' && /stylesheet/i.test(n.a.rel || '') && n.a.href) {
        try { const h = new URL(n.a.href, base).href; if (hostOf(h) === hostOf(base) && links.indexOf(h) < 0) links.push(h); } catch (e) { /* 건너뜀 */ }
      }
    });
    await pool(links.slice(0, 12), 3, async (h) => {
      try {
        const r = await grab(h, { accept: 'text/css,*/*;q=0.1', max: 800 * 1024, timeout: 12000 });
        if (r.status < 400) scan(new TextDecoder('utf-8').decode(r.buf), r.url);
      } catch (e) { /* 못 받은 스타일은 건너뜀 */ }
    });
    return { bgs, colors: Array.from(colors.entries()).sort((a, b) => b[1] - a[1]).slice(0, 24) };
  }
  // 로고 후보: 머리·꼬리까지 다 보고 파일 이름·alt·감싼 class 에 logo 가 있는 이미지 (6개까지)
  function logosOf(doc, base) {
    const out = [];
    walk(doc, (n) => {
      if (n.tag !== 'img' || out.length >= 6) return;
      const s = srcOf(n) || n.a.src || '';
      let hit = /logo|로고|ci[_-]|bi[_-]/i.test(s.split('/').pop() + ' ' + (n.a.alt || ''));
      for (let x = n.up, k = 0; x && k < 3 && !hit; x = x.up, k++) if (tokens(x).some((t) => /logo/.test(t))) hit = true;
      if (!hit || !s || /^data:/i.test(s)) return;
      try { const u = new URL(s.trim(), base).href; if (out.indexOf(u) < 0) out.push(u); } catch (e) { /* 건너뜀 */ }
    });
    return out;
  }
  // 6) 페이지 글자 흐름 + 배경 이미지 + 색 + 로고 후보
  async function readText(url) {
    const pc = await loadDoc(url, UA_PC);
    const ci = await cssInfo(pc.doc, pc.base);
    return { url: pc.url, flow: textFlow(pc.doc, pc.base), bgs: ci.bgs, colors: ci.colors, logos: logosOf(pc.doc, pc.base) };
  }
  // 에디터·서버가 부르는 곳: {op, …} → 결과
  async function run(b) {
    b = b || {};
    switch (b.op) {
      case 'menu': return readMenu(b.url);
      case 'page':
        if (typeof b.url !== 'string') throw new Error('페이지 주소가 없어요');
        return readOnePage(b.url, b.name, b.mo && typeof b.mo === 'object' ? b.mo : null);
      case 'finish': return finishPages(b.pages);
      case 'probe':
        if (typeof b.url !== 'string') throw new Error('이미지 주소가 없어요');
        return probeSample(b.url, typeof b.ref === 'string' ? b.ref : '');
      case 'check': return { found: await checkPattern(b.k, b.urls, typeof b.ref === 'string' ? b.ref : '') };
      case 'text':
        if (typeof b.url !== 'string') throw new Error('페이지 주소가 없어요');
        return readText(b.url);
      default: throw new Error('모르는 요청이에요 (op: ' + String(b.op).slice(0, 20) + ')');
    }
  }
  // 한 번에 전부 (사내 서버에서 node site-import.js 로 확인할 때)
  async function scanAll(url) {
    const m = await readMenu(url);
    const raw = {};
    await pool(m.pages, 4, async (p) => { raw[p.url] = await readOnePage(p.url, p.name, m.mo); });
    const f = finishPages(raw);
    let how = f.how;
    if (!how) {
      let pat = { k: -1 };
      for (const s of f.samples) { pat = await probeSample(s, m.site.url); if (pat.k >= 0) break; }
      if (pat.k >= 0) {
        const all = uniq([].concat.apply([], Object.keys(f.pages).map((u) => f.pages[u].pc))), found = {};
        for (let i = 0; i < all.length; i += CHECK_MAX) {
          const part = all.slice(i, i + CHECK_MAX), r = await checkPattern(pat.k, part, m.site.url);
          part.forEach((v, j) => { if (r[j]) found[v] = r[j]; });
        }
        Object.keys(f.pages).forEach((u) => { const P = f.pages[u], mo = P.pc.map((v) => found[v] || v); if (!same(mo, P.pc)) P.mo = mo; });
        how = '모바일 이미지 파일명 규칙: ' + pat.name;
      } else how = '모바일용 이미지를 따로 못 찾았어요 (휴대폰에서도 PC 이미지를 써요)';
    }
    return { site: m.site, menus: m.menus, pages: f.pages, how, skipped: m.skipped };
  }

  return { UA_PC, UA_MO, CHECK_MAX, privateIp, setGuard, grab, readMax, sniff, why, pool, parseHtml, findMenu, pageImages, readMenu, readOnePage, finishPages, probeSample, checkPattern, readText, run, scanAll };
})();

/* =========================================================
   Cloudflare Worker 입구 — 깃허브 Pages(마법도구) 에디터의 '공식 홈페이지에서 가져오기' 중계 서버
   - 읽는 방법(SiteImportCore)은 바로 위에 붙은 site-import-core.js 와 같음 (사내 서버와 똑같이 동작)
   - 허락한 에디터 주소에서 온 요청만 받음: Worker 설정 → 변수 ALLOWED_ORIGINS (쉼표로 여러 개, * = 아무 데나)
     안 넣으면 아래 DEFAULT_ORIGINS
   - 이 파일을 고치면  node make-worker.js  로 worker.js 를 다시 만들어 Cloudflare에 붙여 넣기
   ========================================================= */
const DEFAULT_ORIGINS = 'https://fittalk-qs.github.io,http://localhost:8080,http://127.0.0.1:8080';
const IMG_MAX = 30 * 1048576;

export default {
  async fetch(req, env) {
    const core = SiteImportCore;
    const url = new URL(req.url);
    const allow = String((env && env.ALLOWED_ORIGINS) || DEFAULT_ORIGINS).split(',').map((s) => s.trim().replace(/\/+$/, '')).filter(Boolean);
    // 에디터의 fetch 는 Origin, 썸네일 <img> 는 Referer 로 어디서 왔는지 알 수 있음
    const origin = req.headers.get('Origin') || '';
    let from = origin;
    if (!from) { try { from = new URL(req.headers.get('Referer') || '').origin; } catch (e) { from = ''; } }
    const ok = allow.indexOf('*') >= 0 || (!!from && allow.indexOf(from) >= 0);
    // 거절할 때도 보낸 곳을 그대로 돌려줘야 에디터가 '허락되지 않은 주소' 안내를 읽을 수 있음 (실제 일은 ok일 때만)
    const cors = {
      'Access-Control-Allow-Origin': origin || '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400', Vary: 'Origin'
    };
    const json = (code, body) => new Response(JSON.stringify(body), { status: code, headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, cors) });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    const isScan = /site-scan\/?$/.test(url.pathname), isImg = /site-img\/?$/.test(url.pathname);
    if (!isScan && !isImg) {
      return new Response('분양 랜딩 에디터 중계 서버가 켜져 있어요.\n에디터에는 이 주소를 넣으면 돼요: ' + url.origin + '/api/site-scan\n허락된 에디터 주소: ' + allow.join(', ') + '\n',
        { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    }
    if (!ok) return json(403, { error: '허락되지 않은 에디터 주소예요 (' + (from || '주소 없음') + '). Cloudflare Worker 설정의 ALLOWED_ORIGINS 에 넣어 주세요' });

    if (isScan) {
      if (req.method !== 'POST') return json(405, { error: 'POST only' });
      let b;
      try { b = JSON.parse(await req.text()); } catch (e) { return json(400, { error: '요청이 이상해요' }); }
      try { return json(200, await core.run(b)); } catch (e) { return json(502, { error: core.why(e) }); }
    }

    // 이미지 대신 받기: 이미지라고 오면 그대로 흘려보내고(CPU 거의 안 씀), 아니면 앞부분을 보고 이미지인지 확인
    if (req.method !== 'GET') return json(405, { error: 'GET only' });
    const u = url.searchParams.get('u') || '', ref = url.searchParams.get('ref') || '';
    try {
      const r = await core.grab(u, { referer: ref || u, accept: 'image/avif,image/webp,image/*,*/*;q=0.8', stream: true, timeout: 30000 });
      if (r.status >= 400) { if (r.res.body) r.res.body.cancel().catch(() => {}); return json(502, { error: 'HTTP ' + r.status }); }
      const head = Object.assign({ 'Cache-Control': 'public, max-age=3600' }, cors);
      const type = r.type.split(';')[0].trim().toLowerCase();
      if (/^image\/(jpeg|jpg|png|gif|webp|avif|bmp)$/.test(type)) return new Response(r.res.body, { headers: Object.assign({ 'Content-Type': type }, head) });
      const buf = await core.readMax(r.res, IMG_MAX), sniffed = core.sniff(buf);
      if (!sniffed) return json(415, { error: '이미지가 아니에요' });
      return new Response(buf, { headers: Object.assign({ 'Content-Type': sniffed }, head) });
    } catch (e) { return json(502, { error: core.why(e) }); }
  }
};
