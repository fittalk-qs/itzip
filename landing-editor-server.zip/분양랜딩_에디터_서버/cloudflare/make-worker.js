// worker.js 다시 만들기:  node make-worker.js
// ../site-import-core.js (사내 서버와 같은 읽기 코드) + worker-main.js (Worker 입구) → worker.js 한 파일
// Cloudflare 화면에서 붙여 넣기 편하게 한 파일로 합침
const fs = require('fs');
const path = require('path');

// 맨 끝 Node용 module.exports 줄은 Worker엔 필요 없어서 뺌
const core = fs.readFileSync(path.join(__dirname, '..', 'site-import-core.js'), 'utf8').replace(/\nif \(typeof module !== 'undefined'[^\n]*\n?\s*$/, '\n');
const main = fs.readFileSync(path.join(__dirname, 'worker-main.js'), 'utf8');
const out = '// ★ 이 파일은 make-worker.js 가 만든 거예요. 고칠 땐 ../site-import-core.js 나 worker-main.js 를 고치고 node make-worker.js\n' +
  '// Cloudflare Worker 화면(Edit code)에 이 파일 내용을 통째로 붙여 넣고 Deploy 하면 돼요. 방법은 설정방법.txt\n\n' +
  core.trim() + '\n\n' + main.trim() + '\n';
fs.writeFileSync(path.join(__dirname, 'worker.js'), out);
console.log('worker.js 만들었어요 (' + Math.round(out.length / 1024) + 'KB)');
