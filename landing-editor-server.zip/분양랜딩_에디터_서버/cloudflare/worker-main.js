/* =========================================================
   Cloudflare Worker 입구 — 깃허브 Pages(마법도구) 에디터의 '공식 홈페이지에서 가져오기' 중계 서버
   - 읽는 방법(SiteImportCore)은 바로 위에 붙은 site-import-core.js 와 같음 (사내 서버와 똑같이 동작)
   - 허락한 에디터 주소에서 온 요청만 받음: Worker 설정 → 변수 ALLOWED_ORIGINS (쉼표로 여러 개, * = 아무 데나)
     안 넣으면 아래 DEFAULT_ORIGINS
   - 이 파일을 고치면  node make-worker.js  로 worker.js 를 다시 만들어 Cloudflare에 붙여 넣기
   ========================================================= */
const DEFAULT_ORIGINS = 'https://fittalk-qs.github.io,http://localhost:8080,http://127.0.0.1:8080';
const IMG_MAX = 30 * 1048576;

export default {
  async fetch(req, env) {
    const core = SiteImportCore;
    const url = new URL(req.url);
    const allow = String((env && env.ALLOWED_ORIGINS) || DEFAULT_ORIGINS).split(',').map((s) => s.trim().replace(/\/+$/, '')).filter(Boolean);
    // 에디터의 fetch 는 Origin, 썸네일 <img> 는 Referer 로 어디서 왔는지 알 수 있음
    const origin = req.headers.get('Origin') || '';
    let from = origin;
    if (!from) { try { from = new URL(req.headers.get('Referer') || '').origin; } catch (e) { from = ''; } }
    const ok = allow.indexOf('*') >= 0 || (!!from && allow.indexOf(from) >= 0);
    // 거절할 때도 보낸 곳을 그대로 돌려줘야 에디터가 '허락되지 않은 주소' 안내를 읽을 수 있음 (실제 일은 ok일 때만)
    const cors = {
      'Access-Control-Allow-Origin': origin || '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400', Vary: 'Origin'
    };
    const json = (code, body) => new Response(JSON.stringify(body), { status: code, headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, cors) });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    const isScan = /site-scan\/?$/.test(url.pathname), isImg = /site-img\/?$/.test(url.pathname);
    if (!isScan && !isImg) {
      return new Response('분양 랜딩 에디터 중계 서버가 켜져 있어요.\n에디터에는 이 주소를 넣으면 돼요: ' + url.origin + '/api/site-scan\n허락된 에디터 주소: ' + allow.join(', ') + '\n',
        { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    }
    if (!ok) return json(403, { error: '허락되지 않은 에디터 주소예요 (' + (from || '주소 없음') + '). Cloudflare Worker 설정의 ALLOWED_ORIGINS 에 넣어 주세요' });

    if (isScan) {
      if (req.method !== 'POST') return json(405, { error: 'POST only' });
      let b;
      try { b = JSON.parse(await req.text()); } catch (e) { return json(400, { error: '요청이 이상해요' }); }
      try { return json(200, await core.run(b)); } catch (e) { return json(502, { error: core.why(e) }); }
    }

    // 이미지 대신 받기: 이미지라고 오면 그대로 흘려보내고(CPU 거의 안 씀), 아니면 앞부분을 보고 이미지인지 확인
    if (req.method !== 'GET') return json(405, { error: 'GET only' });
    const u = url.searchParams.get('u') || '', ref = url.searchParams.get('ref') || '';
    try {
      const r = await core.grab(u, { referer: ref || u, accept: 'image/avif,image/webp,image/*,*/*;q=0.8', stream: true, timeout: 30000 });
      if (r.status >= 400) { if (r.res.body) r.res.body.cancel().catch(() => {}); return json(502, { error: 'HTTP ' + r.status }); }
      const head = Object.assign({ 'Cache-Control': 'public, max-age=3600' }, cors);
      const type = r.type.split(';')[0].trim().toLowerCase();
      if (/^image\/(jpeg|jpg|png|gif|webp|avif|bmp)$/.test(type)) return new Response(r.res.body, { headers: Object.assign({ 'Content-Type': type }, head) });
      const buf = await core.readMax(r.res, IMG_MAX), sniffed = core.sniff(buf);
      if (!sniffed) return json(415, { error: '이미지가 아니에요' });
      return new Response(buf, { headers: Object.assign({ 'Content-Type': sniffed }, head) });
    } catch (e) { return json(502, { error: core.why(e) }); }
  }
};
