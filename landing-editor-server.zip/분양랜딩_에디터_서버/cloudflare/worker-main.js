/* =========================================================
   Cloudflare Worker 입구 — 깃허브 Pages(마법도구) 에디터의 '공식 홈페이지에서 가져오기' 중계 서버
   - 읽는 방법(SiteImportCore)은 바로 위에 붙은 site-import-core.js 와 같음 (사내 서버와 똑같이 동작)
   - 허락한 에디터 주소에서 온 요청만 받음: Worker 설정 → 변수 ALLOWED_ORIGINS (쉼표로 여러 개, * = 아무 데나)
     안 넣으면 아래 DEFAULT_ORIGINS
   - 이 파일을 고치면  node make-worker.js  로 worker.js 를 다시 만들어 Cloudflare에 붙여 넣기
   ========================================================= */
const DEFAULT_ORIGINS = 'https://fittalk-qs.github.io,http://localhost:8080,http://127.0.0.1:8080';
const IMG_MAX = 30 * 1048576;

/* ===== VR-CORE 시작 — 여기부터 'VR-CORE 끝'까지는 브라우저(CDP)만 있으면 되는 부분. Cloudflare Worker(클라우드 브라우저)도 그대로 씀 (make-server-project 가 잘라 붙임) ===== */
const vrSleep = (ms) => new Promise((r) => setTimeout(r, ms));
/* ---------- 장면 → 타입·방 ---------- */
const ROOMS = [['거실', /거실|living/i], ['주방', /주방|식당|부엌|kitchen|dining/i], ['침실', /침실|안방|bed|master|room\s*\d|^room/i], ['욕실', /욕실|화장실|파우더|bath|toilet|powder/i]];
function roomOf(s) { const t = (s.title || '') + ' ' + s.name.replace(/^scene_?/i, ''); const r = ROOMS.find((x) => x[1].test(t)); return r ? r[0] : ''; }
function typeKey(s) {   // 평면 지도 그림 이름(34a.png) → 장면 이름(scene_84a_living) → 앞 번호 묶음(scene_01_03)
  const m1 = String(s.map || '').split('/').pop().match(/^(\d{2,3}[a-z]{0,2}\d?)\b/i); if (m1) return m1[1].toUpperCase();
  const m3 = s.name.match(/^scene_?(\d{1,2})_\d{1,3}$/i); if (m3) return '#' + (+m3[1]);   // 번호 묶음만 (scene_01_03)
  const m2 = s.name.match(/(?:^|_)(\d{2,3}[a-z]{1,2}\d?|\d{2,3})(?=_|$)/i); if (m2 && !/^0\d$/.test(m2[1])) return m2[1].toUpperCase();
  return '#1';
}
const vrLabel = (n) => /^\d{2,3}[A-Z]{0,2}\d?$/.test(n) ? n.replace(/^(\d{2,3})/, '$1㎡') : n;
function pickScenes(scenes, form, maxTypes, domTypes) {
  const groups = [];
  scenes.forEach((s) => { const k = typeKey(s); let g = groups.find((x) => x.key === k); if (!g) groups.push(g = { key: k, list: [] }); g.list.push(s); });
  // 번호 묶음뿐이면 VR 화면의 타입 이름(34㎡A타입 …)을 차례로
  groups.forEach((g, i) => {
    if (g.key[0] === '#') { const d = domTypes[i] ? domTypes[i].replace(/\s*타입$/, '').replace(/\s+/g, '') : ''; g.name = d.replace('㎡', '') || '타입' + (i + 1); g.label = d || g.name; }
    else { g.name = g.key; g.label = vrLabel(g.key); }
  });
  const use = groups.filter((g) => g.list.some((s) => roomOf(s))).slice(0, maxTypes || 3);
  const want = form === 'slide' || use.length === 1 ? ['거실', '주방', '침실', '욕실'] : ['거실', '침실'];
  return use.map((g) => {
    const used = new Set(), usedT = new Set(), rooms = [];
    // 같은 방이 여럿이면: 미니맵에 나오는 장면(menabled) 먼저 → 침실1·욕실1·-1 처럼 앞 번호 / 거실 겸 침실(원룸)은 거실 먼저, 침실엔 이름이 다른 장면
    const score = (s) => (s.menabled === 'false' ? 2 : 0) + (/[1１]|안방|master/i.test(s.title || s.name) ? 0 : 1);
    want.forEach((room) => {
      const cand = g.list.filter((s) => !used.has(s.name) && !(s.title && usedT.has(s.title)) && (roomOf(s) === room || (room === '침실' && /침실/.test(s.title || '') && roomOf(s) === '거실')));
      cand.sort((a, b) => score(a) - score(b));
      const s = cand[0]; if (!s) return;
      used.add(s.name); if (s.title) usedT.add(s.title); rooms.push({ room, title: s.title || '', scene: s.name });
    });
    return { name: g.name, label: g.label, rooms };
  }).filter((t) => t.rooms.length);
}

/* ---------- 찍기 (S = 그 페이지에 CDP 명령 보내기) ---------- */
const VR_K = "(document.getElementById('krpanoSWFObject') || window.krpano || [...document.querySelectorAll('object,embed,div')].find(e => e.get && e.call) || null)";
const vrEv = (S) => async (x) => { const r = await S('Runtime.evaluate', { expression: x, returnByValue: true, awaitPromise: true }); return r.exceptionDetails ? null : (r.result || {}).value; };
async function vrPlan(S, url, b) {   // VR 페이지를 열고 장면 목록 → 타입별로 찍을 장면 고르기 (사진은 vrShot)
  const ev = vrEv(S), K = VR_K;
  await S('Page.enable'); await S('Runtime.enable');
  await S('Emulation.setDeviceMetricsOverride', { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false });
  const ready = async (ms) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const n = await ev(`(() => { const k = ${K}; return k && k.get ? +k.get('scene.count') || 0 : 0; })()`); if (n > 0) return n; await vrSleep(600); } return 0; };
  await S('Page.navigate', { url });
  let n = await ready(15000);
  if (!n) {   // VR 이 iframe 안이면 그 주소로 (분양 홈페이지의 e모델하우스 메뉴 페이지)
    const fr = (await ev("[...document.querySelectorAll('iframe')].map(f => f.src).filter(u => /^https?:/.test(u))")) || [];
    for (const u of fr.slice(0, 3)) { await S('Page.navigate', { url: u }); n = await ready(15000); if (n) { url = u; break; } }
  }
  if (!n) throw new Error('이 주소에서 E모델하우스 VR(krpano)을 못 찾았어요');
  await vrSleep(2500);
  const scenes = (await ev(`(() => { const k = ${K}, n = +k.get('scene.count'), out = []; for (let i = 0; i < n; i++) out.push({ name: String(k.get('scene[' + i + '].name') || ''), title: String(k.get('scene[' + i + '].title') || ''), map: String(k.get('scene[' + i + '].map') || ''), menabled: String(k.get('scene[' + i + '].menabled') || '') }); return out; })()`)) || [];
  const domTypes = (await ev("[...document.querySelectorAll('a,button,li,span,div,p')].filter(e => e.children.length === 0 && /^\\s*\\d{2,3}\\s*(㎡|m²|m2)?\\s*[A-Z]{0,2}\\d?\\s*(타입|TYPE)?\\s*$/i.test(e.textContent) && /타입|type|㎡|m²/i.test(e.textContent)).map(e => e.textContent.trim()).filter((t, i, a) => a.indexOf(t) === i)")) || [];
  const types = pickScenes(scenes, b.form === 'slide' ? 'slide' : 'rule', Math.max(1, Math.min(+b.maxTypes || 3, 6)), domTypes);
  return { url, types, scenes: scenes.map((s) => ({ name: s.name, title: s.title, type: typeKey(s), room: roomOf(s) })) };
}
async function vrShot(S, r) {   // 고른 장면 하나 → 화살표·버튼 숨기고 넓게(fov 120) → data:image/jpeg
  const ev = vrEv(S), K = VR_K;
  await ev(`(() => { const k = ${K}; k.call('loadscene(' + ${JSON.stringify(r.scene)} + ', null, MERGE, BLEND(0))'); return 1; })()`);
  await vrSleep(3000);
  await ev(`(() => { const k = ${K}; const fm = +k.get('view.fovmax') || 120; k.set('view.fov', Math.min(fm, 120)); const n = +k.get('hotspot.count'); for (let i = 0; i < n; i++) k.set('hotspot[' + i + '].visible', false); const m = +k.get('layer.count'); for (let i = 0; i < m; i++) k.set('layer[' + i + '].visible', false); return 1; })()`);
  await vrSleep(1500);
  const shot = await S('Page.captureScreenshot', { format: 'jpeg', quality: 88 });
  return 'data:image/jpeg;base64,' + shot.data;
}
/* ===== VR-CORE 끝 ===== */


/* ---------- E모델하우스 캡처 (클라우드 브라우저) ----------
   사내 서버는 그 컴퓨터의 크롬으로 찍고, 여기선 Cloudflare 클라우드 브라우저(Browser Rendering)로 위와 똑같은 순서로 찍어요.
   켜려면 Worker 설정에 변수 CF_ACCOUNT_ID(계정 ID) · 비밀 CF_BR_TOKEN(API 토큰, 권한 'Browser Rendering - Edit') — 설정방법.txt
   한 번에 다 찍으면 오래 걸려서 나눠 부름: op 'vr' = 열고 장면 고르기(브라우저는 3분 켜 둠) → 'vr-shot' 장면마다 → 'vr-end' 끄기 */
const BR_KEEP = 180000;
const VR_OPS = /^vr(-shot|-end)?$/;
const brBase = (env) => 'https://api.cloudflare.com/client/v4/accounts/' + env.CF_ACCOUNT_ID + '/browser-run/devtools/browser';
const brAuth = (env) => ({ Authorization: 'Bearer ' + env.CF_BR_TOKEN });
const brEnd = (env, id) => fetch(brBase(env) + '/' + encodeURIComponent(id), { method: 'DELETE', headers: brAuth(env) }).catch(() => {});
async function brConnect(env, id) {
  const r = await fetch(brBase(env) + '/' + encodeURIComponent(id), { headers: Object.assign({ Upgrade: 'websocket' }, brAuth(env)) });
  const ws = r.webSocket;
  if (!ws) throw new Error('클라우드 브라우저에 연결이 안 돼요 (HTTP ' + r.status + ')');
  ws.accept();
  const wait = new Map(); let n = 0, dead = null;
  ws.addEventListener('message', (ev) => {
    let m; try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : new TextDecoder().decode(ev.data)); } catch (e) { return; }
    const w = m.id && wait.get(m.id); if (!w) return;
    wait.delete(m.id); if (m.error) w.no(new Error(m.error.message)); else w.ok(m.result || {});
  });
  const fail = (e) => { dead = e; wait.forEach((w) => w.no(e)); wait.clear(); };
  ws.addEventListener('close', () => fail(new Error('클라우드 브라우저 연결이 끊겼어요')));
  ws.addEventListener('error', () => fail(new Error('클라우드 브라우저 연결 오류')));
  const send = (method, params, sessionId) => new Promise((ok, no) => {
    if (dead) return no(dead);
    const i = ++n; wait.set(i, { ok, no });
    ws.send(JSON.stringify(sessionId ? { id: i, method, params: params || {}, sessionId } : { id: i, method, params: params || {} }));
  });
  return { send, close: () => { try { ws.close(1000, 'done'); } catch (e) { /* 이미 닫힘 */ } } };
}
async function vrOp(env, core, b) {
  if (!env || !env.CF_ACCOUNT_ID || !env.CF_BR_TOKEN) throw new Error('E모델하우스 자동 캡처는 사내 서버 에디터에서만 돼요 (Cloudflare 클라우드 브라우저를 켜면 여기서도 돼요 — cloudflare/설정방법.txt)');
  if (b.op === 'vr-end') { await brEnd(env, String(b.session || '')); return { ok: true }; }
  if (b.op === 'vr-shot') {
    const B = await brConnect(env, String(b.session || ''));
    try {
      const { sessionId } = await B.send('Target.attachToTarget', { targetId: String(b.target || ''), flatten: true });
      return { img: await vrShot((m, p) => B.send(m, p, sessionId), { scene: String(b.scene || '') }) };
    } finally { B.close(); }
  }
  const url = String(b.url || '').trim();
  if (!/^https?:\/\//i.test(url)) throw new Error('E모델하우스 주소를 넣어 주세요');
  await core.grab(url, { accept: 'text/html,*/*', max: 65536, timeout: 12000 });   // 사내망 주소 막기(core 의 주소 검사) + 열리는지
  const r = await fetch(brBase(env) + '?keep_alive=' + BR_KEEP, { method: 'POST', headers: brAuth(env) });
  const t = await r.text(); let j = {};
  try { j = JSON.parse(t); } catch (e) { j = {}; }
  const id = j.sessionId || j.session_id || (j.result && (j.result.sessionId || j.result.session_id || j.result.id)) || j.id;
  if (!r.ok || !id) throw new Error('클라우드 브라우저를 못 빌렸어요 (HTTP ' + r.status + ') ' + t.slice(0, 160));
  const B = await brConnect(env, id);
  try {
    const { targetId } = await B.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await B.send('Target.attachToTarget', { targetId, flatten: true });
    const plan = await vrPlan((m, p) => B.send(m, p, sessionId), url, b);
    return Object.assign(plan, { session: id, target: targetId });
  } catch (e) { brEnd(env, id); throw e; } finally { B.close(); }
}


/* ---------- MCP 입구 (claude.ai 연결 도구) ----------
   아티팩트(claude.ai) 안의 에디터는 보안상 다른 주소를 직접 못 불러요. 그래서 claude.ai 의 '커넥터'로 이 중계 서버를 불러요.
   - 주소: https://<이 Worker>/mcp   (변수 MCP_KEY 를 넣었으면 https://<이 Worker>/mcp/<MCP_KEY>)
   - 도구 site_scan  = 위 /api/site-scan 과 같은 일 (입력도 에디터가 보내는 요청 그대로)
   - 도구 site_image = 위 /api/site-img 과 같은 일, 다만 base64 글로 나눠서 줌 (한 번에 IMG_CHUNK 바이트씩)
   - 로그인 없음 (MCP_KEY 로 주소를 아는 사람만 쓰게 할 수 있음) */
const MCP_VERSIONS = ['2025-06-18', '2025-03-26', '2024-11-05'];
const IMG_CHUNK = 512 * 1024;
const MCP_TOOLS = [
  { name: 'site_scan', title: '분양 홈페이지 읽기',
    description: '분양 공식 홈페이지를 읽어요 (메뉴 · 페이지 이미지 · 글자 · 평면 데이터). 입력은 에디터가 보내는 요청 그대로 {op, url, ...}. op: menu · page · finish · probe · check · text · units',
    inputSchema: { type: 'object', properties: { op: { type: 'string', description: 'menu | page | finish | probe | check | text | units' }, url: { type: 'string', description: '읽을 주소' } }, required: ['op'], additionalProperties: true },
    annotations: { readOnlyHint: true, openWorldHint: true } },
  { name: 'site_image', title: '홈페이지 이미지 받기',
    description: '홈페이지 이미지 하나를 대신 받아 base64 로 나눠서 줘요. 답: {type, size, offset, next, b64} — next 가 있으면 offset=next 로 다시 부르면 이어서 줌',
    inputSchema: { type: 'object', properties: { u: { type: 'string', description: '이미지 주소' }, ref: { type: 'string', description: '그 이미지가 있던 홈페이지 주소' }, offset: { type: 'integer', minimum: 0 } }, required: ['u'], additionalProperties: false },
    annotations: { readOnlyHint: true, openWorldHint: true } }
];
function b64Of(b) {
  let s = '';
  for (let i = 0; i < b.length; i += 8192) s += String.fromCharCode.apply(null, b.subarray(i, i + 8192));
  return btoa(s);
}
async function mcpImage(core, a) {
  const u = String(a.u || ''), ref = String(a.ref || ''), off = Math.max(0, Math.floor(+a.offset || 0));
  if (!/^https?:\/\//i.test(u)) throw new Error('이미지 주소가 이상해요');
  const r = await core.grab(u, { referer: ref || u, accept: 'image/avif,image/webp,image/*,*/*;q=0.8', stream: true, timeout: 30000 });
  if (r.status >= 400) { if (r.res.body) r.res.body.cancel().catch(() => {}); throw new Error('HTTP ' + r.status); }
  const buf = await core.readMax(r.res, IMG_MAX);
  let type = r.type.split(';')[0].trim().toLowerCase();
  if (!/^image\/(jpeg|jpg|png|gif|webp|avif|bmp)$/.test(type)) { type = core.sniff(buf); if (!type) throw new Error('이미지가 아니에요'); }
  const end = Math.min(buf.length, off + IMG_CHUNK);
  return { type, size: buf.length, offset: off, next: end < buf.length ? end : null, b64: b64Of(buf.subarray(off, end)) };
}
async function mcpHandle(req, env, core, url) {
  const key = String((env && env.MCP_KEY) || '').trim();
  if (key && url.pathname.replace(/\/+$/, '') !== '/mcp/' + key) return new Response('', { status: 404 });
  const H = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' };
  if (req.method !== 'POST') return new Response('MCP: POST 로 불러 주세요', { status: 405, headers: { Allow: 'POST' } });
  let msg;
  try { msg = JSON.parse(await req.text()); } catch (e) { return new Response(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }), { status: 400, headers: H }); }
  const one = async (m) => {
    if (!m || typeof m !== 'object' || typeof m.method !== 'string') return m && m.id != null ? { jsonrpc: '2.0', id: m.id, error: { code: -32600, message: 'Invalid Request' } } : null;
    if (m.id == null) return null;   // 알림 (notifications/initialized 등) → 답 없음
    const ok = (result) => ({ jsonrpc: '2.0', id: m.id, result });
    const p = m.params || {};
    if (m.method === 'initialize') {
      const v = MCP_VERSIONS.indexOf(p.protocolVersion) >= 0 ? p.protocolVersion : MCP_VERSIONS[0];
      return ok({ protocolVersion: v, capabilities: { tools: { listChanged: false } }, serverInfo: { name: 'fittalk-site', title: '핏톡 홈페이지 읽기', version: '1.0.0' },
        instructions: '핏톡 분양 랜딩 에디터가 공식 홈페이지를 읽을 때 쓰는 도구예요. site_scan 으로 메뉴·페이지를 읽고, site_image 로 이미지를 받아요.' });
    }
    if (m.method === 'ping') return ok({});
    if (m.method === 'tools/list') return ok({ tools: MCP_TOOLS });
    if (m.method === 'tools/call') {
      const a = p.arguments || {};
      if (p.name !== 'site_scan' && p.name !== 'site_image') return { jsonrpc: '2.0', id: m.id, error: { code: -32602, message: 'Unknown tool: ' + p.name } };
      try {
        const out = p.name === 'site_scan' ? await (VR_OPS.test(a.op) ? vrOp(env, core, a) : core.run(a)) : await mcpImage(core, a);
        return ok({ content: [{ type: 'text', text: JSON.stringify(out) }] });
      } catch (e) { return ok({ content: [{ type: 'text', text: JSON.stringify({ error: core.why(e) }) }], isError: true }); }
    }
    return { jsonrpc: '2.0', id: m.id, error: { code: -32601, message: 'Method not found: ' + m.method } };
  };
  if (Array.isArray(msg)) {
    const outs = (await Promise.all(msg.map(one))).filter(Boolean);
    return outs.length ? new Response(JSON.stringify(outs), { headers: H }) : new Response(null, { status: 202 });
  }
  const out = await one(msg);
  return out ? new Response(JSON.stringify(out), { headers: H }) : new Response(null, { status: 202 });
}

export default {
  async fetch(req, env) {
    const core = SiteImportCore;
    const url = new URL(req.url);
    if (url.pathname.indexOf('/.well-known/') === 0) return new Response('', { status: 404 });   // claude.ai 커넥터가 로그인(OAuth) 있는지 물어봄 → 없음
    if (/^\/mcp(\/|$)/.test(url.pathname)) return mcpHandle(req, env, core, url);   // claude.ai 연결 도구 (아래 MCP 입구)
    const allow = String((env && env.ALLOWED_ORIGINS) || DEFAULT_ORIGINS).split(',').map((s) => s.trim().replace(/\/+$/, '')).filter(Boolean);
    // 에디터의 fetch 는 Origin, 썸네일 <img> 는 Referer 로 어디서 왔는지 알 수 있음
    const origin = req.headers.get('Origin') || '';
    let from = origin;
    if (!from) { try { from = new URL(req.headers.get('Referer') || '').origin; } catch (e) { from = ''; } }
    const ok = allow.indexOf('*') >= 0 || (!!from && allow.indexOf(from) >= 0);
    // 거절할 때도 보낸 곳을 그대로 돌려줘야 에디터가 '허락되지 않은 주소' 안내를 읽을 수 있음 (실제 일은 ok일 때만)
    const cors = {
      'Access-Control-Allow-Origin': origin || '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400', Vary: 'Origin'
    };
    const json = (code, body) => new Response(JSON.stringify(body), { status: code, headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, cors) });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    const isScan = /site-scan\/?$/.test(url.pathname), isImg = /site-img\/?$/.test(url.pathname);
    if (!isScan && !isImg) {
      return new Response('분양 랜딩 에디터 중계 서버가 켜져 있어요.\n에디터에는 이 주소를 넣으면 돼요: ' + url.origin + '/api/site-scan\n허락된 에디터 주소: ' + allow.join(', ') + '\n' + 'claude.ai 연결 도구(MCP) 주소: ' + url.origin + '/mcp' + ((env && env.MCP_KEY) ? '/(MCP_KEY)' : '') + '\n',
        { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    }
    if (!ok) return json(403, { error: '허락되지 않은 에디터 주소예요 (' + (from || '주소 없음') + '). Cloudflare Worker 설정의 ALLOWED_ORIGINS 에 넣어 주세요' });

    if (isScan) {
      if (req.method !== 'POST') return json(405, { error: 'POST only' });
      let b;
      try { b = JSON.parse(await req.text()); } catch (e) { return json(400, { error: '요청이 이상해요' }); }
      try { return json(200, await (VR_OPS.test(b.op) ? vrOp(env, core, b) : core.run(b))); } catch (e) { return json(502, { error: core.why(e) }); }
    }

    // 이미지 대신 받기: 이미지라고 오면 그대로 흘려보내고(CPU 거의 안 씀), 아니면 앞부분을 보고 이미지인지 확인
    if (req.method !== 'GET') return json(405, { error: 'GET only' });
    const u = url.searchParams.get('u') || '', ref = url.searchParams.get('ref') || '';
    try {
      const r = await core.grab(u, { referer: ref || u, accept: 'image/avif,image/webp,image/*,*/*;q=0.8', stream: true, timeout: 30000 });
      if (r.status >= 400) { if (r.res.body) r.res.body.cancel().catch(() => {}); return json(502, { error: 'HTTP ' + r.status }); }
      const head = Object.assign({ 'Cache-Control': 'public, max-age=3600' }, cors);
      const type = r.type.split(';')[0].trim().toLowerCase();
      if (/^image\/(jpeg|jpg|png|gif|webp|avif|bmp)$/.test(type)) return new Response(r.res.body, { headers: Object.assign({ 'Content-Type': type }, head) });
      const buf = await core.readMax(r.res, IMG_MAX), sniffed = core.sniff(buf);
      if (!sniffed) return json(415, { error: '이미지가 아니에요' });
      return new Response(buf, { headers: Object.assign({ 'Content-Type': sniffed }, head) });
    } catch (e) { return json(502, { error: core.why(e) }); }
  }
};
