# 분양 랜딩 에디터

분양 현장 이미지를 올리면 모바일 분양 랜딩 사이트(원페이지 + 메뉴 페이지)를 만들어 **zip으로 내보내는 브라우저 에디터**와, 그 에디터를 사내에서 띄우는 작은 서버예요.
설치할 패키지가 없어요 (Node.js 18 이상만).

- 사용자용 설명: [실행방법.txt](실행방법.txt) · Cloudflare 중계 서버 만들기: [cloudflare/설정방법.txt](cloudflare/설정방법.txt)
- 이 문서는 **이어서 개발하는 사람용**이에요.

## 어디서 돌아가나

| 곳 | 주소 | 무엇을 올리나 | 되는 것 |
|---|---|---|---|
| 사내 서버 | `http://<서버 IP>:8080/` | 이 폴더 통째로, `node server.js` | 편집·zip, 팀원 동시 접속 알림, 공식 홈페이지 가져오기 |
| 마법도구 (깃허브 Pages) | https://fittalk-qs.github.io/itzip/landing-editor.html | `public/index.html` 을 `landing-editor.html` 로 이름만 바꿔서 | 편집·zip, 가져오기(Cloudflare 중계 서버를 거쳐서) |
| Cloudflare Worker | `https://….workers.dev` | `cloudflare/worker.js` 내용을 Cloudflare 화면에 붙여 넣기 | 마법도구용 홈페이지 가져오기 중계 |

## 바로 시작

```bash
npm start            # = node server.js → http://localhost:8080/
npm run build        # src/ 를 고친 뒤 → public/index.html (+ cloudflare/worker.js)
npm test             # 홈페이지 가져오기 시험 (가짜 사이트 3개, 인터넷 없이 1초)
npm run test:live    # 위 + 진짜 예시 사이트 sd.hndapt.co.kr
```

## 폴더 구조

```
build.js                 src/ → public/index.html 합치기 (+ Worker 다시 만들기)
server.js                사내 서버: public/ 보여 주기 + api/presence(동시 접속) + api/site-scan·site-img(가져오기)
site-import.js           사내 서버용 가져오기 입구 (DNS로 사내망 주소 막기, 읽은 이미지만 대신 받기)
site-import-core.js      ★ 홈페이지 읽는 핵심 — 사내 서버와 Worker가 똑같이 씀
public/index.html        ※ 만든 결과물 (직접 고치지 말기). 사내 서버가 보여 주고 마법도구에 올리는 파일
src/
  editor.html            에디터 화면 HTML·CSS
  editor.js              에디터 동작 전부 (상태·미리보기·내보내기·불러오기·자동 저장·가져오기)
  template/              만들어지는 분양 사이트의 틀 — zip 안에 그대로 들어가는 css/js/fonts
    css/landing-style.css  사이트 CSS. /*@SITE*/ … /*@END*/ 블록을 에디터가 현장 값(색·크기)으로 바꿔 넣음
    css/pretendard.css     글꼴 CSS
    js/main.js             사이트 동작 (인트로·메뉴·슬라이드·폼 자리 등)
    fonts/                 woff2 글꼴 (에디터 안에 base64로 들어감)
  vendor/jszip.min.js    zip 라이브러리 (JSZip 3.10.1, 손대지 않음)
cloudflare/
  worker-main.js         Worker 입구 (허락한 에디터 주소만 받기, 이미지 흘려보내기)
  make-worker.js         site-import-core.js + worker-main.js → worker.js (build.js 가 같이 부름)
  worker.js              ※ 만든 결과물 — Cloudflare에 붙여 넣는 파일
  설정방법.txt
test/
  run.js · fixtures.js   가짜 분양 홈페이지를 띄워서 가져오기 시험
```

## 에디터 고치는 법

1. `src/` 를 고쳐요. (`public/index.html` 을 직접 고치면 다음 빌드 때 덮어써져요)
2. `npm run build` — 에디터·사이트 스크립트 문법 오류와 `</script` 가 섞였는지 미리 잡아 줘요.
3. `npm start` 후 http://localhost:8080/ 새로고침해서 확인. 서버는 안 꺼도 돼요 (`server.js`·`site-import*.js` 를 고쳤을 때만 재시작).

주의할 점
- `src/editor.js` 는 HTML의 `<script>` 안에 그대로 들어가요. 글자로 `</script>` 를 써야 하면 `'<\/script>'` 로.
- 에디터 코드는 `var` + `function` 스타일(일부 `async`)이에요. 맞춰 주세요.
- **내보낸 사이트 HTML 구조를 바꾸면 `importZip()` 도 같이 고쳐야 해요.** 만든 zip을 다시 불러올 때 그 HTML(클래스·id·data 속성)을 읽어서 상태를 되살려요.
- 사이트 틀(`src/template`)을 고치면 앞으로 만드는 zip에만 반영돼요. 이미 만든 사이트는 그대로.

### src/editor.js 지도

맨 위 IIFE 하나. `/* ===== 제목 ===== */` 로 나뉘어 있어요.

| 부분 | 하는 일 |
|---|---|
| 상태 (`freshState`) | 현장 하나 = `state` 객체 하나. `siteMode` = `single`(모바일형) · `menu`(모바일+메뉴형) · `pc`(PC 최적화). `sections` = 지금 고치는 페이지의 섹션 목록, `mainSections` = 메인 원페이지, `menus` = 메뉴 페이지(대메뉴 → `children` 소메뉴, 페이지마다 `sections`, `cw` 1200·860·375). `privacyText`·`thirdPartyText` = 개인정보 동의문 |
| 섹션 종류 | `kind`: `images`(`images` 기본 이미지, `header` 제목 이미지, `pcImages` PC 넓은 화면용 이미지, `mode` stack/slide) · `text` · `video` · `form`(리드요 폼 자리, `fields` 추가 항목). 공통: `anim` 애니메이션, `join` 앞 섹션에 붙은 묶음 |
| 이미지 불러오기·파일명 분류 | `addFiles` → `classify`(파일명 규칙 00_hero·02 intro …) → 섹션에 자리 잡기 |
| 페이지 생성 `renderPage(page, o)` | 미리보기와 내보내기가 같이 쓰는 HTML 생성. `o.src/o.dims` 만 다름 |
| 내보내기 `exportZip` / 불러오기 `importZip` | zip 만들기(이미지 다시 압축: 메인 860px, 메뉴 페이지 1600px) / 만든 zip 되살리기 |
| 되돌리기 | 상태를 JSON으로 찍어 둠 (`freeze`/`thaw`, 이미지 blob은 그대로 가리킴) |
| 자동 저장·작업 내역 | IndexedDB `bunyang-editor` (`snapshot`/`loadSnap`). 브라우저마다 따로라 서버엔 안 올라감 |
| 팀원 동시 접속 | `api/presence` 에 10초마다 신호 (`<meta name="presence-url">`) |
| 공식 홈페이지 가져오기 | `siteScan` → `openScan`(고르기 창) → `importScan`(이미지 받아서 메뉴 페이지 만들기) |

자동화·확인용으로 `window.__editor` 가 열려 있어요 (`state()`, `renderPage()`, `lastZip()`, `scan()` 등).

### 휴대폰용·PC용 이미지가 따로인 섹션 (`pcImages`)

- 이미지 섹션의 `images` 는 기본 이미지, `pcImages` 는 PC 넓은 화면(가로 768px 이상)에서 대신 나오는 이미지. 쓰는 곳은 `pcSplitOk(sub)`: PC 최적화는 모든 페이지, 모바일+메뉴형은 메뉴 페이지만.
- 출력: `<section class="has-pc">` 안에 기본 이미지는 `figure.m-only`, PC 이미지는 `figure.pc-only`. 사이트 CSS의 `html[data-pc]` · `html[data-wide] .has-pc` 규칙이 화면 폭으로 골라 보여 줌.
- 비어 있으면 기본 이미지 하나로 둘 다. 슬라이드 모드에선 기본 이미지만.
- zip에선 PC 이미지가 `img/<키>_pc_NN.jpg`. PC 이미지가 있는 메뉴 페이지 섹션의 기본 이미지는 휴대폰용이라 860px까지. `importZip` 이 `pc-only` 를 다시 읽음.
- 공식 홈페이지 가져오기에서 휴대폰용 이미지를 찾으면: 기본 이미지 = 휴대폰용, PC 이미지 = PC용.
- (2026-10-22 팀원 버전의 `mimages`·`has-mo` 는 이걸로 합쳤어요. 그 버전으로 만든 zip(`has-mo`)을 불러오면 `mo-pic` → 기본 이미지, `pc-pic` → PC 이미지로 바꿔 읽어요)

## 공식 홈페이지 가져오기

에디터에서 공식 홈페이지 주소를 넣으면 메뉴 구조와 페이지마다 PC·모바일 이미지를 찾아 메뉴 페이지로 넣어 줘요.
브라우저는 보안상 다른 사이트를 직접 못 읽어서 서버가 대신 읽어요.

- **핵심은 `site-import-core.js` 하나**예요. 사내 서버(`site-import.js`)와 Cloudflare Worker(`cloudflare/worker-main.js`)는 입구만 달라요.
  Node 전용 기능(Buffer·dns)은 쓰지 말고 `fetch`·`URL`·`TextDecoder`·`Uint8Array` 만 쓰세요 (Worker에서도 돌아야 해서).
- **단계별 API**: Cloudflare 무료 요금제가 요청 한 번에 바깥 요청 50개·CPU 10ms 까지라 나눠서 불러요. 형식은 `site-import-core.js` 맨 위 주석.
  `menu`(메뉴) → `page`(페이지마다, 에디터가 4개씩 동시에) → `finish`(공통 장식 빼기) → 모바일을 못 찾았으면 `probe`(파일명 규칙 찾기) → `check`(이미지마다 짝 확인), 그리고 이미지는 `GET site-img`.
- **모바일 이미지 찾는 순서**
  1. 한 페이지 안에 PC용·모바일용이 따로: class(`pc`/`mo`/`pc_img`/`hide-mobile`/Tailwind·Bootstrap), `<picture media>`, `data-pc`·`data-mo`
  2. 휴대폰 User-Agent로 열면 다른 HTML·다른 사이트(m.도메인) — 첫 화면으로 튕기면 메뉴 이름으로 짝 찾기
  3. 둘 다 없으면 파일명 규칙 17가지(`m_파일`, `파일_m`, `m/` 폴더, `/pc/→/m/` …)를 찔러 봄 — JS로 바꿔 끼우는 사이트
- **이미지 고르기 규칙**: 머리·꼬리·메뉴·팝업·서브 비주얼 영역은 안 봄(`SKIP_TAGS`·`CHROME`), 로고·아이콘 같은 파일명 빼기(`JUNK_WORD`), 페이지 절반 이상에 나오는 이미지는 공통 장식으로 빼기. 에디터는 가로 400px 안 되는 이미지를 기본으로 빼요.
- **보안**: 사내망·내 컴퓨터 주소는 안 읽어요 (사내 서버는 DNS까지 확인). 이미지 대신 받기는 사내 서버는 방금 읽은 이미지만, Worker는 허락한 에디터 주소(`ALLOWED_ORIGINS`)에서 온 요청만.
- **에디터가 어디로 부르나**: 사내 서버로 열면 같은 서버 `api/site-scan`. 깃허브 Pages로 열면(또는 같은 서버에 API가 없으면) 중계 서버 — 브라우저에 저장한 주소 → 없으면 `<meta name="site-import-remote">`. 주소 뒤 `?siteimport=…` 로 바꿀 수도 있어요.

### 고친 다음 확인

```bash
npm test                                        # 반드시. 가짜 사이트 3종(여러 방식 섞인 euc-kr 사이트 / m.사이트로 튕기는 사이트 / m_ 규칙 사이트)
node site-import.js https://공식홈페이지/        # 진짜 사이트에서 찾은 메뉴·이미지 수 (--all 이면 주소까지)
```

새로운 홈페이지 구조를 지원하게 고칠 땐 `test/fixtures.js` 에 그 구조를 흉내 낸 페이지를 넣고 `test/run.js` 에 기대값을 더해 주세요.

Worker를 Cloudflare 런타임 그대로 내 컴퓨터에서 돌려 보려면 (선택, 계정 필요 없음):

```bash
# 저장소 밖 아무 빈 폴더에 cloudflare/worker.js 를 복사해 두고 그 폴더에서
npm install wrangler          # workerd·esbuild 설치 스크립트를 허락하라고 하면 npm approve-scripts workerd esbuild
# wrangler.toml:  name = "test" / main = "worker.js" / compatibility_date = "2025-06-01"
#                 [vars] ALLOWED_ORIGINS = "http://localhost:8080"     (--var 옵션은 안 먹었어요)
npx wrangler dev --local --port 8787
# 에디터를 http://localhost:8080/?siteimport=http://127.0.0.1:8787/api/site-scan 으로 열면 그 Worker로 가져와요
```

## 내보내기 전 체크리스트 (배포)

1. `npm run build` → `npm test`
2. 사내 서버: 폴더를 서버 PC에 복사. `server.js`·`site-import*.js` 가 바뀌었으면 서버 재시작, `public/index.html` 만 바뀌었으면 새로고침만
3. 마법도구: `public/index.html` → `landing-editor.html` 로 이름 바꿔 itzip 저장소에 올리기
4. `site-import-core.js`·`cloudflare/worker-main.js` 가 바뀌었으면 `cloudflare/worker.js` 를 Cloudflare에 다시 붙여 넣고 Deploy

## 알려진 한계 · 다음에 할 만한 것

- 메뉴를 그림이나 스크립트(React 등)로만 그리는 사이트는 메뉴·이미지를 못 찾아요. HTML을 그대로 읽기 때문 (헤드리스 브라우저가 있어야 함).
- CSS `background-image` 로만 넣은 이미지, iframe 안 내용(e모델하우스·지도)은 안 읽어요.
- 진짜 공식 홈페이지는 sd.hndapt.co.kr 하나로만 확인했어요. 다른 대행사 사이트에서 빠지는 이미지가 있으면 `test/fixtures.js` 에 흉내 내서 고치기.
- Cloudflare 무료 요금제의 CPU 10ms 한도는 내 컴퓨터 측정(페이지당 1ms 안팎)으로만 확인했어요. 아주 큰 사이트에서 'Exceeded CPU' 가 나면 Workers Paid로.
- 에디터 화면 자체의 자동 테스트는 없어요. 에디터를 바꾸면 http://localhost:8080/ 에서 이미지 올리기 → 미리보기(모바일·PC) → zip 만들기 → 그 zip 다시 불러오기까지 손으로 확인하세요.

## 변경 기록

- 2026-10-22: 공식 홈페이지에서 가져오기(메뉴 + 페이지별 PC·모바일 이미지), 메뉴 페이지 섹션의 모바일 이미지(`mimages`), Cloudflare Worker 중계 서버, `src/` 분리·`build.js`·시험(`test/`)
- 2026-10-22 (합침): 최신 에디터(PC 최적화·애니메이션·폼 추가 항목·개인정보 동의문·핏톡식 상담신청 원)에 가져오기를 합침. 메뉴 페이지 모바일 이미지는 `pcImages`(기본 이미지 = 휴대폰용)로 통일
