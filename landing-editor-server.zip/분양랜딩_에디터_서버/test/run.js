// 공식 홈페이지 가져오기 시험:  node test/run.js        (인터넷 없이, 1초쯤)
//                              node test/run.js --live (진짜 예시 사이트 sd.hndapt.co.kr 까지, 인터넷 필요)
// 가짜 홈페이지(test/fixtures.js)를 띄워서 site-import-core.js 가 메뉴와 PC·모바일 이미지를 제대로 찾는지 확인해요.
// site-import-core.js 를 고친 다음엔 꼭 돌려 보세요. 실패하면 무엇이 달라졌는지 보여 줘요.
const assert = require('assert');
const core = require('../site-import-core');
const { siteA, siteB, siteC, listen } = require('./fixtures');

core.setGuard(async () => {});   // 시험은 내 컴퓨터 주소를 읽어야 해서 사내망 주소 막기를 끔

let fail = 0;
function check(name, fn) {
  try { fn(); console.log('  ✓ ' + name); } catch (e) { fail++; console.log('  ✗ ' + name + '\n      ' + String(e.message).split('\n').join('\n      ')); }
}
const names = (list) => list.map((u) => decodeURIComponent(u.split('/').pop()));
const menuText = (menus) => menus.map((m) => m.name + (m.children.length ? '(' + m.children.map((c) => c.name).join(',') + ')' : ''));

async function main() {
  // A: 여러 방식이 섞인 사이트
  const a = await listen(siteA()), A0 = 'http://127.0.0.1:' + a.address().port;
  const A = await core.scanAll(A0 + '/');
  const PA = (p) => A.pages[A0 + p];
  console.log('A: 여러 PC·모바일 방식이 섞인 사이트 (euc-kr)');
  check('현장명·대표번호', () => { assert.strictEqual(A.site.title, '테스트 더샵 센트럴'); assert.strictEqual(A.site.phone, '1588-0000'); });
  check('메뉴 (메가메뉴·안 닫힌 <li>·외부 링크 빼기)', () => assert.deepStrictEqual(menuText(A.menus), ['사업개요(사업개요,입지환경)', '프리미엄', '단지정보(단지배치,평면안내)', '공지사항']));
  check('class pc_img / mo_img', () => { assert.deepStrictEqual(names(PA('/sub/sub01.php').pc), ['biz_pc.jpg', 'biz_common.jpg']); assert.deepStrictEqual(names(PA('/sub/sub01.php').mo), ['biz_mo.jpg', 'biz_common.jpg']); });
  check('<picture>·data-src·크게 보기 링크·아이콘 빼기', () => {
    assert.deepStrictEqual(names(PA('/sub/sub02.php').pc), ['loc.jpg', 'loc2.jpg', 'loc3_big.jpg']);
    assert.deepStrictEqual(names(PA('/sub/sub02.php').mo), ['loc_m@2x.jpg', 'loc2.jpg', 'loc3_big.jpg']);
  });
  check('휴대폰으로 열면 다른 HTML', () => { assert.deepStrictEqual(names(PA('/sub/sub03.php').pc), ['premium.jpg']); assert.deepStrictEqual(names(PA('/sub/sub03.php').mo), ['premium_01.jpg', 'premium_02.jpg']); });
  check('Tailwind hidden md:block / md:hidden', () => { assert.deepStrictEqual(names(PA('/sub/sub04.php?no=1').pc), ['site.jpg']); assert.deepStrictEqual(names(PA('/sub/sub04.php?no=1').mo), ['site_m.jpg']); });
  check('Bootstrap d-none d-md-block · data-mobile', () => { assert.deepStrictEqual(names(PA('/sub/sub04.php?no=2').pc), ['unit59.png', 'unit84.png']); assert.deepStrictEqual(names(PA('/sub/sub04.php?no=2').mo), ['unit59_m.png', 'unit84_mobile.png']); });
  check('공통 배너·로고·퀵메뉴·서브 비주얼 빼기', () => {
    const all = [].concat(...Object.values(A.pages).map((P) => P.pc.concat(P.mo))).join(' ');
    ['common_banner', 'logo', 'quick_tel', 'subvisual01', 'icon_arrow', 'main_visual'].forEach((w) => assert.ok(all.indexOf(w) < 0, w + ' 가 들어감'));
  });
  check('이미지 없는 페이지', () => assert.strictEqual(PA('/board/news.php').pc.length, 0));
  check('찾은 방법 안내', () => assert.match(A.how, /따로 있어요.*모바일 페이지/));
  a.close();

  // B: 휴대폰이면 모바일 사이트(다른 주소) 첫 화면으로 튕기는 사이트
  const b = await listen(siteB()), B0 = 'http://127.0.0.1:' + b.address().port;
  const B = await core.scanAll(B0 + '/');
  console.log('B: 휴대폰이면 모바일 사이트로 튕기는 사이트');
  check('메뉴 이름으로 모바일 페이지 짝 찾기 ("사업 안내" = "사업안내")', () => {
    assert.deepStrictEqual(names(B.pages[B0 + '/sub/business.html'].mo), ['biz_01.jpg', 'biz_02.jpg']);
    assert.deepStrictEqual(names(B.pages[B0 + '/sub/location.html'].mo), ['loc_01.jpg']);
    assert.deepStrictEqual(B.pages[B0 + '/sub/unit.html'].mo, []);   // 모바일 메뉴에 없으면 PC 이미지 그대로
  });
  b.close();

  // C: JS로 m_파일명 을 바꿔 끼우는 사이트
  const c = await listen(siteC()), C0 = 'http://127.0.0.1:' + c.address().port;
  const C = await core.scanAll(C0 + '/');
  console.log('C: 화면 폭 보고 JS로 m_파일명 으로 바꾸는 사이트');
  check('파일명 규칙 m_ 찾기', () => assert.match(C.how, /m_/));
  check('짝이 있는 이미지만 모바일로', () => {
    assert.deepStrictEqual(names(C.pages[C0 + '/a.html'].mo), ['m_planning.jpg']);
    assert.deepStrictEqual(names(C.pages[C0 + '/c.html'].mo), ['m_location.png']);
    assert.deepStrictEqual(C.pages[C0 + '/b.html'].mo, []);
  });
  c.close();

  if (process.argv.includes('--live')) {
    console.log('진짜 사이트: sd.hndapt.co.kr');
    const L = await core.scanAll('https://sd.hndapt.co.kr/');
    check('메뉴 26페이지 · 규칙 m_', () => { assert.strictEqual(Object.keys(L.pages).length, 26); assert.match(L.how, /m_/); });
    check('입지환경 PC 3 · 모바일 3', () => assert.deepStrictEqual(names(L.pages['https://sd.hndapt.co.kr/location.html'].mo), ['m_location_top.jpg', 'm_location.png', 'm_location_bottom.jpg']));
  }

  console.log(fail ? '\n실패 ' + fail + '개' : '\n모두 통과');
  process.exit(fail ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
