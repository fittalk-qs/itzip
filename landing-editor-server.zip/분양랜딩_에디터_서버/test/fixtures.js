// 테스트용 가짜 분양 홈페이지 두 개 (test/run.js 가 띄움)
//   A: 여러 PC·모바일 방식을 섞은 사이트 — euc-kr, 메가메뉴·안 닫힌 <li>, class(pc_img/mo_img·Tailwind·Bootstrap),
//      <picture>, data-src·data-mobile, 크게 보기 링크, 휴대폰이면 다른 HTML, 모든 페이지 공통 배너·로고·아이콘
//   B: 휴대폰으로 열면 어느 페이지든 모바일 사이트(다른 주소) 첫 화면으로 보내는 사이트 → 메뉴 이름으로 짝 찾기
const http = require('http');

// 1x1 PNG (이미지 주소는 전부 이걸 돌려줌)
const PNG = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000154a24f5d0000000049454e44ae426082', 'hex');
const isMobile = (req) => /iPhone|Android/.test(req.headers['user-agent'] || '');

// euc-kr(CP949) 인코더: Node엔 없어서 TextDecoder로 거꾸로 표를 만듦
let eucMap = null;
function eucKr(s) {
  if (!eucMap) {
    eucMap = new Map();
    const dec = new TextDecoder('euc-kr');
    for (let a = 0x81; a <= 0xfe; a++) for (let b = 0x41; b <= 0xfe; b++) {
      const ch = dec.decode(Uint8Array.from([a, b]));
      if (ch.length === 1 && ch !== '�' && !eucMap.has(ch)) eucMap.set(ch, [a, b]);
    }
  }
  const out = [];
  for (const ch of s) { const c = ch.codePointAt(0); if (c < 0x80) out.push(c); else out.push(...(eucMap.get(ch) || [0x3f])); }
  return Buffer.from(out);
}

function siteA() {
  const head = (title) => `<!doctype html><html><head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr"><title>${title} | 테스트 더샵 센트럴</title></head><body>`;
  const gnb = `<div id="header"><h1><a href="/"><img src="/img/logo.png" alt="테스트 더샵"></a></h1>
<div id="gnb"><ul class="gnb_list">
 <li><a href="/sub/sub01.php">사업개요</a><div class="sub"><a href="/sub/sub01.php">사업개요</a><a href="/sub/sub02.php">입지환경</a></div></li>
 <li><a href="/sub/sub03.php">프리미엄</a>
 <li><span>단지정보</span><ul><li><a href="/sub/sub04.php?no=1">단지배치</a><li><a href="/sub/sub04.php?no=2">평면안내</a></ul>
 <li><a href="https://www.youtube.com/xxx" target="_blank">홍보영상</a></li>
 <li><a href="/board/news.php">공지사항</a></li>
</ul></div><a href="tel:1588-0000">1588-0000</a></div>`;
  const chrome = `<div class="quick_menu"><a href="#"><img src="/img/quick_tel.png"></a></div>
<div class="common_banner"><img src="/img/common_banner.jpg"></div>
<div id="footer"><img src="/img/footer_logo.png"><p>시행 : 테스트</p></div><noscript><img src="https://px.example/1x1" width="1" height="1"></noscript></body></html>`;
  const pages = {
    '/': () => head('메인') + gnb + '<div id="main"><img src="/img/main_visual.jpg"></div>' + chrome,
    '/sub/sub01.php': () => head('사업개요') + gnb + `<div class="sub_visual"><img src="/img/subvisual01.jpg"></div>
      <div class="contents"><img src="/img/biz_pc.jpg" class="pc_img" alt=""><img src="/img/biz_mo.jpg" class="mo_img"><img src="/img/biz_common.jpg"></div>` + chrome,
    '/sub/sub02.php': () => head('입지환경') + gnb + `<div class="contents">
      <picture><source media="(max-width: 768px)" srcset="/img/loc_m.jpg 1x, /img/loc_m@2x.jpg 2x"><img src="/img/loc.jpg" alt="입지"></picture>
      <img data-src="/img/loc2.jpg" src="/img/blank.gif" class="lazy">
      <a href="/img/loc3_big.jpg" class="lightbox"><img src="/img/loc3_thumb.jpg"></a>
      <img src="/img/icon_arrow.png"></div>` + chrome,
    '/sub/sub03.php': (mo) => head('프리미엄') + gnb + `<div class="contents">${mo ? '<img src="/m/img/premium_01.jpg"><img src="/m/img/premium_02.jpg">' : '<img src="/img/premium.jpg">'}</div>` + chrome,
    '/sub/sub04.php?no=1': () => head('단지배치') + gnb + '<div class="contents"><img class="hidden md:block" src="/img/site.jpg"><img class="md:hidden" src="/img/site_m.jpg"></div>' + chrome,
    '/sub/sub04.php?no=2': () => head('평면안내') + gnb + `<div class="contents"><div class="d-none d-md-block"><img src="/img/unit59.png"></div><div class="d-md-none"><img src="/img/unit59_m.png"></div>
      <img src="/img/unit84.png" data-mobile="/img/unit84_mobile.png"></div>` + chrome,
    '/board/news.php': () => head('공지사항') + gnb + '<div class="contents"><table><tr><td>공지</td></tr></table></div>' + chrome
  };
  return http.createServer((req, res) => {
    if (/\.(png|jpe?g|gif)$/.test(req.url.split('?')[0])) { res.writeHead(200, { 'Content-Type': 'image/png' }); return res.end(PNG); }
    const p = pages[req.url];
    if (!p) { res.writeHead(404, { 'Content-Type': 'text/html' }); return res.end('<h1>404</h1>'); }
    res.writeHead(200, { 'Content-Type': 'text/html' });   // charset은 HTML 안 meta에만 (euc-kr)
    res.end(eucKr(p(isMobile(req))));
  });
}

// PC: http://127.0.0.1:<port>/  ·  모바일: http://localhost:<port>/m/
function siteB() {
  const pc = {
    '/': '<title>테스트 자이</title><header><nav><ul class="depth1"><li><a href="/sub/business.html">사업안내</a></li><li><a href="/sub/location.html">입지환경</a></li><li><a href="/sub/unit.html">평면안내</a></li></ul></nav></header><main><img src="/img/main.jpg"></main>',
    '/sub/business.html': '<header></header><div class="cont"><img src="/img/business.jpg"></div>',
    '/sub/location.html': '<header></header><div class="cont"><img src="/img/location.jpg"></div>',
    '/sub/unit.html': '<header></header><div class="cont"><img src="/img/unit.jpg"></div>'
  };
  const mo = {
    '/m/': '<title>테스트 자이 모바일</title><div id="m_gnb"><ul><li><a href="/m/biz.html">사업 안내</a></li><li><a href="/m/loc.html">입지환경</a></li></ul></div>',
    '/m/biz.html': '<div class="m_cont"><img src="/m/img/biz_01.jpg"><img src="/m/img/biz_02.jpg"></div>',
    '/m/loc.html': '<div class="m_cont"><img src="/m/img/loc_01.jpg"></div>'
  };
  const srv = http.createServer((req, res) => {
    const host = (req.headers.host || '').split(':')[0];
    if (/\.(png|jpe?g)$/.test(req.url)) { res.writeHead(200, { 'Content-Type': 'image/png' }); return res.end(PNG); }
    if (host === '127.0.0.1' && isMobile(req)) { res.writeHead(302, { Location: 'http://localhost:' + srv.address().port + '/m/' }); return res.end(); }
    const page = (host === 'localhost' ? mo : pc)[req.url];
    if (!page) { res.writeHead(404); return res.end('nf'); }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end('<!doctype html><html><body>' + page + '</body></html>');
  });
  return srv;
}

// C: 모바일 이미지가 HTML엔 없고, 화면 폭 보고 JS로 m_파일명 으로 바꿔 끼우는 사이트 (sd.hndapt.co.kr 방식)
//    m_ 짝이 있는 이미지만 진짜로 있음 → 파일명 규칙을 찾아서 짝 있는 것만 모바일로
function siteC() {
  const files = new Set(['/img/planning.jpg', '/img/m_planning.jpg', '/img/premium.jpg', '/img/location.png', '/img/m_location.png']);
  const nav = '<header><nav><ul class="gnb"><li><a href="/a.html">사업안내</a></li><li><a href="/b.html">프리미엄</a></li><li><a href="/c.html">입지환경</a></li></ul></nav></header>';
  const pages = {
    '/': nav + '<div class="main"><img src="/img/main.jpg"></div>',
    '/a.html': nav + '<div class="sub_content"><img src="/img/planning.jpg" class="response_img"></div>',
    '/b.html': nav + '<div class="sub_content"><img src="/img/premium.jpg"></div>',
    '/c.html': nav + '<div class="sub_content"><img src="/img/location.png" class="response_img"></div>'
  };
  return http.createServer((req, res) => {
    if (files.has(req.url)) { res.writeHead(200, { 'Content-Type': 'image/png' }); return res.end(PNG); }
    const p = pages[req.url];
    if (!p) { res.writeHead(404, { 'Content-Type': 'text/html' }); return res.end('<h1>404</h1>'); }   // 없는 파일은 HTML 404 (흔한 서버처럼)
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end('<!doctype html><html><head><title>테스트 한내들</title></head><body>' + p + '</body></html>');
  });
}

// localhost 가 ::1 로 가도 받게 주소를 안 정하고 띄움
const listen = (srv) => new Promise((ok) => srv.listen(0, () => ok(srv)));
module.exports = { siteA, siteB, siteC, listen };
