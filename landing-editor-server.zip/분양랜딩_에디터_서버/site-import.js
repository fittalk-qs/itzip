// 공식 홈페이지에서 메뉴·이미지 가져오기 — server.js가 씀 (설치할 것 없음, Node.js 18 이상)
//
// 읽는 방법(핵심)은 site-import-core.js 에 있고, 깃허브 Pages용 Cloudflare Worker(cloudflare/worker.js)도 같은 걸 씀.
// 여기는 사내 서버에 맞춘 부분만:
//   - 주소 검사: DNS까지 봐서 사내망(192.168.x.x 등)으로 가는 주소는 막음 (테스트용으로 풀려면 SCAN_ALLOW_PRIVATE=1)
//   - 이미지 대신 받기: 방금 읽은 홈페이지에서 나온 이미지만 받아 줌 (아무 주소나 받아 주는 통로가 되지 않게)
//
// API (자세한 형식은 site-import-core.js 맨 위)
//   POST <에디터 주소>/api/site-scan   {"op":"menu"|"page"|"finish"|"probe"|"check", …}
//   GET  <에디터 주소>/api/site-img?u=<이미지 주소>
//
// 따로 실행해서 확인:  node site-import.js https://sd.hndapt.co.kr/   (--all 을 붙이면 이미지 주소까지)

const dns = require('dns').promises;
const net = require('net');
const core = require('./site-import-core');

const IMG_TTL = 2 * 60 * 60 * 1000;   // 읽은 뒤 이 시간 동안만 이미지 대신 받기 허용
const IMG_MAX = 30 * 1048576;
const allowed = new Map();   // 이미지 주소 → { exp, ref }
let working = 0;

core.setGuard(async (u) => {
  if (!/^https?:$/.test(u.protocol)) throw new Error('http·https 주소만 읽을 수 있어요');
  if (process.env.SCAN_ALLOW_PRIVATE === '1') return;
  const host = u.hostname.replace(/^\[|\]$/g, '');
  const ips = net.isIP(host) ? [host] : (await dns.lookup(host, { all: true })).map((x) => x.address);
  if (!ips.length || ips.some(core.privateIp)) throw new Error('사내망·내 컴퓨터 주소는 읽지 않아요');
});

function remember(list, ref) {
  const exp = Date.now() + IMG_TTL;
  list.forEach((v) => { if (v) allowed.set(v, { exp, ref }); });
  if (allowed.size > 20000) for (const k of allowed.keys()) { allowed.delete(k); if (allowed.size <= 15000) break; }
}

/* ---------- server.js 에서 부르는 곳 ---------- */
const stamp = () => new Date().toLocaleTimeString('ko-KR', { hour12: false });
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
function json(res, code, body) {
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, CORS));
  res.end(JSON.stringify(body));
}

function scanApi(req, res) {
  if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
  if (req.method !== 'POST') return json(res, 405, { error: 'POST only' });
  let raw = '';
  req.setEncoding('utf8');
  req.on('data', (c) => { raw += c; if (raw.length > 1048576) req.destroy(); });
  req.on('end', async () => {
    let b;
    try { b = JSON.parse(raw || '{}'); } catch (e) { return json(res, 400, { error: '요청이 이상해요' }); }
    if (working >= 24) return json(res, 429, { error: '다른 팀원이 홈페이지를 읽는 중이에요. 잠깐 뒤에 다시 해 주세요' });
    working++;
    try {
      const out = await core.run(b);
      if (b.op === 'page') remember(out.pc.concat(out.mo), b.url);
      if (b.op === 'check') remember(out.found, b.ref);
      if (b.op === 'menu') console.log(`[${stamp()}] 홈페이지 읽기 ${out.site.url} · 메뉴 페이지 ${out.pages.length}개`);
      json(res, 200, out);
    } catch (e) {
      if (b.op === 'menu') console.log(`[${stamp()}] 홈페이지 못 읽음 ${String(b.url).slice(0, 200)} · ${core.why(e)}`);
      json(res, 502, { error: core.why(e) });
    } finally { working--; }
  });
}

async function imgApi(req, res, query) {
  if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
  if (req.method !== 'GET') return json(res, 405, { error: 'GET only' });
  const u = query.get('u') || '', ok = allowed.get(u);
  if (!ok || ok.exp < Date.now()) return json(res, 403, { error: '홈페이지를 다시 읽은 다음 가져와 주세요' });
  try {
    const r = await core.grab(u, { referer: ok.ref, accept: 'image/avif,image/webp,image/*,*/*;q=0.8', max: IMG_MAX, timeout: 30000 });
    if (r.status >= 400) return json(res, 502, { error: 'HTTP ' + r.status });
    const type = core.sniff(r.buf);
    if (!type) return json(res, 415, { error: '이미지가 아니에요' });
    res.writeHead(200, Object.assign({ 'Content-Type': type, 'Content-Length': r.buf.length, 'Cache-Control': 'private, max-age=3600' }, CORS));
    res.end(Buffer.from(r.buf.buffer, r.buf.byteOffset, r.buf.length));
  } catch (e) { json(res, 502, { error: core.why(e) }); }
}

module.exports = { scanApi, imgApi };

// node site-import.js <주소> → 찾은 메뉴와 페이지별 이미지 개수만 보여 줌
if (require.main === module) {
  const t0 = Date.now();
  core.scanAll(process.argv[2] || '').then((out) => {
    console.log(out.site, '\n' + out.how + (out.skipped ? ` · ${out.skipped}페이지는 너무 많아서 안 읽음` : ''));
    out.menus.forEach((m) => {
      const line = (p, pre) => { const P = out.pages[p.url] || { pc: [], mo: [] }; console.log(pre + p.name.padEnd(12) + ` PC ${P.pc.length} · 모바일 ${P.mo.length || '같음'}${P.err ? ' · ' + P.err : ''}  ${p.url || ''}`); };
      if (m.children.length) { console.log('■ ' + m.name); m.children.forEach((c) => line(c, '   - ')); } else line(m, '■ ');
    });
    if (process.argv.includes('--all')) console.log(JSON.stringify(out.pages, null, 1));
    console.log(((Date.now() - t0) / 1000).toFixed(1) + '초');
  }).catch((e) => { console.error('실패:', core.why(e)); process.exit(1); });
}
