// 분양 랜딩 에디터 서버 — 설치할 것 없음 (Node.js 18 이상)
//
// 실행:   node server.js            → http://서버주소:8080/
//         PORT=9000 node server.js  → 포트 바꾸기 (윈도우: set PORT=9000 && node server.js)
//
// 하는 일
//   1) public/ 폴더의 에디터(index.html)를 팀원들에게 보여 줌
//   2) 팀원 동시 접속 알림 API — 누가 어떤 현장을 열고 있는지 메모리에만 들고 있음
//      (디스크에 아무것도 안 남김, 90초 동안 신호가 없으면 목록에서 빠짐)
//
// 마법도구 같은 다른 서버에 에디터를 올릴 때는 아래 API 하나만 똑같이 만들면 돼요.
//   POST <에디터 주소>/api/presence
//     보내는 것(본문은 JSON 글자, Content-Type: text/plain): {"sid":"창 id","name":"김종민","site":"두정역 푸르지오 그랑피크","since":1760000000000}
//     창을 닫을 때:                                          {"sid":"창 id","leave":true}
//     돌려주는 것: {"users":[{"sid","name","site","since","t"}, ...], "now": 1760000000000}   ← 지금 접속 중인 사람 전부 (나 포함)
//   에디터가 10초마다 보냄. API 주소가 다르면 에디터 html의 <meta name="presence-url"> 만 바꾸면 됨.

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = +process.env.PORT || 8080;
const ROOT = path.join(__dirname, 'public');
const TTL = 90 * 1000;          // 이 시간 동안 신호가 없으면 나간 걸로 봄
const MAX_USERS = 300;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };

const users = new Map();   // sid → { sid, name, site, since, t }
const str = (v, n) => (typeof v === 'string' ? v.trim().slice(0, n) : '');
const now = () => Date.now();
const stamp = () => new Date().toLocaleTimeString('ko-KR', { hour12: false });

function prune() {
  const t = now();
  for (const [sid, u] of users) if (t - u.t > TTL) { users.delete(sid); console.log(`[${stamp()}] 나감(시간 초과) ${u.name || '이름 없음'} · ${u.site || '-'}`); }
  while (users.size > MAX_USERS) users.delete(users.keys().next().value);
}

function send(res, code, body, type) {
  res.writeHead(code, {
    'Content-Type': type || 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

function presence(req, res) {
  if (req.method === 'OPTIONS') return send(res, 204, '');
  if (req.method !== 'POST') return send(res, 405, { error: 'POST only' });
  let raw = '';
  req.setEncoding('utf8');
  req.on('data', (c) => { raw += c; if (raw.length > 4096) req.destroy(); });
  req.on('end', () => {
    let b;
    try { b = JSON.parse(raw || '{}'); } catch (e) { return send(res, 400, { error: 'bad json' }); }
    const sid = str(b.sid, 32);
    if (!sid) return send(res, 400, { error: 'sid required' });
    const before = users.get(sid);
    if (b.leave) {
      if (before) console.log(`[${stamp()}] 나감 ${before.name || '이름 없음'} · ${before.site || '-'}`);
      users.delete(sid);
    } else {
      const u = { sid, name: str(b.name, 20), site: str(b.site, 80), since: Number(b.since) || now(), t: now() };
      if (!before || before.site !== u.site || before.name !== u.name) console.log(`[${stamp()}] ${before ? '바뀜' : '접속'} ${u.name || '이름 없음'} · ${u.site || '현장명 없음'}`);
      users.set(sid, u);
    }
    prune();
    send(res, 200, { users: [...users.values()], now: now() });
  });
}

function staticFile(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'GET only', 'text/plain; charset=utf-8');
  let rel = decodeURIComponent(pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(ROOT, rel));
  if (!file.startsWith(ROOT + path.sep)) return send(res, 403, 'forbidden', 'text/plain; charset=utf-8');
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'not found', 'text/plain; charset=utf-8');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

const server = http.createServer((req, res) => {
  const { pathname } = new URL(req.url, 'http://x');
  // 에디터를 하위 경로(/editor/ 등)에 둬도 되게: 끝이 /api/presence 면 다 받음
  if (process.env.PRESENCE !== '0' && /\/api\/presence\/?$/.test(pathname)) return presence(req, res);
  staticFile(req, res, pathname);
});
setInterval(prune, 15000).unref();
server.listen(PORT, () => {
  console.log(`분양 랜딩 에디터: http://localhost:${PORT}/  (같은 망의 팀원은 http://<이 컴퓨터 IP>:${PORT}/)`);
  if (process.env.PRESENCE === '0') console.log('팀원 동시 접속 알림 꺼짐 (PRESENCE=0)');
});
